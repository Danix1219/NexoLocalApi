# Referencia docente y adaptación

Revisión local: 2026-11-02. Se localizaron API_SDD y WebSDD en C:/Users/kevin/ (la referencia wevSDD del pedido corresponde a WebSDD). Repositorios del profesor solo leídos; no se ejecutaron sus scripts, tests ni aplicaciones.

HEAD observado: API_SDD `03480aee0d761b10c64655de10bfd236ed233ced`; WebSDD `269e525a06eeea68ea3d449af6fc89a1ecf2646a`. Los hashes de archivos identifican el contenido realmente leído, ya que HEAD no demuestra ausencia de cambios locales. No se copiaron resultados, firmas ni secretos.

## Coincidencias que se replican

Constitución rectora; AGENTS operativo; Memoria por fase; spec/plan/tarea(s)/checklist; siete secciones y aprobación; FR/NFR y tareas trazables; docs vivos; pruebas por suite, gates, CHECKLIST_PR y revisor; roles IA con límites.

## Variantes que realmente usa cada ejemplo

| Aspecto | API_SDD | WebSDD | Nexo |
|---|---|---|---|
| Constitución | .specify/memory/constitution.md; raíz enlace | constitution.md raíz | Mantener ambas convenciones en contextos API/App |
| Spec | specs/nv-XX | specs/NNN-slug | API nv-XX; app NNN-slug |
| Tareas | task.md | tasks.md | Respetar singular/plural |
| Checklist fase | checklists/gates.md | checklist.md | Mismo lugar por contexto |
| Plantillas | .specify/templates | specs/templates | Igual |
| Formato spec | Objetivo, alcance, API, datos, seguridad, tests, entrega | Contexto, objetivo, alcance, FR/NFR, contratos, aceptación, riesgos | Preservar siete secciones y aprobación correspondiente |

## Diferencias necesarias de producto

SQL Server/EF y naming legacy son decisiones del ejemplo; Nexo requiere NoSQL y contratos propios. Razor/Bootstrap/cookie/antiforgery no sustituyen Flutter/JWT. Una instancia, blacklist en memoria, ausencia de Redis o aplazar CD no cumplen por sí solos Móvil v2: Nexo mantiene dos instancias HTTP, Redis distribuido, caché, nube, observabilidad, moderación, push, ML/GenAI y entrega Play/landing. El grafo se conserva opcional según ensayo/costo; no introduce amigos/seguidores.

Hexagonal/MVVM siguen siendo propuestas técnicas de Nexo. La petición de copiar el flujo SDD no las ratifica ni obliga a reemplazarlas por controllers/service del ejemplo. Las diferencias están explícitas para poder explicarlas al profesor y validarlas; no se presume aprobación docente.

Umbrales 45% global y 80% delta advisory proceden de las constituciones revisadas. Se registran como base propuesta, no como medición o garantía suficiente. Revisiones/estados ejecutados de nv-05/007-login pertenecen al profesor y no se heredan.

## Evidencia de fuentes locales

| Archivo leído | SHA-256 |
|---|---|
| `C:/Users/kevin/API_SDD/.specify/memory/constitution.md` | `efdfb9ee2f2cf6ae3a6ceefe3624d44b7bdd55b98f94c0512857ac3b0e473c0f` |
| `C:/Users/kevin/API_SDD/AGENTS.md` | `1b27d5e437106f768d6bbe9e523030d4e81cdda8facb964c63c0b3636ef8de10` |
| `C:/Users/kevin/API_SDD/.specify/templates/spec-template.md` | `613815007fdefe0213f312e6ef49d688d675bc482e58bb82eb033871e5e38fe2` |
| `C:/Users/kevin/API_SDD/.specify/templates/plan-template.md` | `ee25f9dcfdbb14559642d5b2569af728d7bffb687b00a6e9b732de7474750389` |
| `C:/Users/kevin/API_SDD/.specify/templates/tasks-template.md` | `29ca949affdfa089c5628658e5639dca1fbcc756324e5ad8415643b8b7f90da8` |
| `C:/Users/kevin/API_SDD/scripts/check_sdd.ps1` | `c861c33cd65cd492563e343373f730da0e2b247c690a685f15711ea497601928` |
| `C:/Users/kevin/WebSDD/constitution.md` | `6e4b51821837741e176fbccc2191180b50e281344813ebd83e33d6fcfef61b72` |
| `C:/Users/kevin/WebSDD/AGENTS.md` | `12be6078dbcb9536d27bbbf7617b35c21e65b5b12f37fbb29359b5d8a1eaaa27` |
| `C:/Users/kevin/WebSDD/specs/templates/spec-template.md` | `7f728b12cd45c079175255f347fdd28129e0e43be1e73f65e4cf148c05e5ad85` |
| `C:/Users/kevin/WebSDD/specs/templates/plan-template.md` | `3c85318ea67e75a9a7b4c5ab3cf9314d2536b0391e8545a68af005b9d6cece01` |
| `C:/Users/kevin/WebSDD/specs/templates/tasks-template.md` | `39676e8665841319d71858071e0b0a020c12e0c2442e64174935f56bf5e7f221` |
| `C:/Users/kevin/WebSDD/specs/templates/memoria-entry-template.md` | `1b9a077154c3544888e0e9a76399f77373cd61a917f92ff19f59581fa28447d5` |
| `C:/Users/kevin/WebSDD/specs/007-login/spec.md` | `cd334f71369586b31c5239b12d08f57375d91a754cb269f48c2a29c41c95296c` |
| `C:/Users/kevin/WebSDD/scripts/check_sdd.ps1` | `59b0559f5f912feb9f453f5e143ca0811469fd40fee69673793d331513cb085b` |
