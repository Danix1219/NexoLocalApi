> REFERENCIA HISTÓRICA: esta propuesta se conserva para consulta. El flujo vigente usa API_NexoLocal y App_NexoLocal; ver [migración](../../../docs/MIGRACION_SDD.md). No ejecutar estas tareas como una fase paralela.

# Primer incremento: cuenta y sesión conectadas

Estado: REFINAMIENTO DOCUMENTAL. No cumple todavía Ready: proveedor SMS, stack/versiones, contrato OpenAPI y responsables están pendientes. Este archivo acota el primer desarrollo y reemplaza el plan genérico únicamente para esta historia; el resto de 001 conserva sus incrementos posteriores.

## Resultado para la persona

Un visitante registra cuenta con teléfono confirmado y consentimiento, inicia sesión, consulta su cuenta, reabre la app manteniendo sesión válida y cierra sesión. La misma sesión revocada deja de funcionar en dos instancias. El cambio de usuario no muestra información del anterior.

## Subset de contratos

EP-001 POST /auth/otp; EP-002 POST /auth/otp/verify; EP-003 POST /auth/register; EP-004 POST /auth/login; EP-005 POST /auth/refresh; EP-007 POST /auth/logout; EP-008 GET /me. Verificar ids contra inventario.json antes de formalizar. El prefijo público propuesto es /api/v1. No se incluyen todavía recuperación de contraseña, listado de dispositivos ni saga completa de borrado.

## Semántica que el OpenAPI debe concretar

- Teléfono: E.164 normalizado; UI mexicana puede capturar diez dígitos y mostrar +52. Mensajes neutrales para no enumerar cuentas.
- Desafío: challengeId opaco, propósito registration, expiresAt y retryAfter. Código nunca en response/log. Propuesta vigente: seis dígitos, cinco minutos, cinco intentos y reenvío tras sesenta segundos; fijar y validar con proveedor antes de Ready.
- Verificación: proofToken opaco de un uso, ligado al teléfono y propósito, con expiración. TTL de base limpia, pero la aplicación verifica tiempo e intentos en la operación atómica.
- Registro: consume prueba válida una vez; nombre y consentVersions de documentos vigentes; contraseña con hash adaptativo y sal. Moderación de nombre requiere contrato interno S06 o limitar el DTO público hasta habilitarla; no aprobar automáticamente contenido público con un doble.
- Login: cuenta activa, comparación segura de hash, límites por IP/teléfono y respuesta neutral. accessToken/refreshToken/sid/expiresAt con campos exactos en esquema; no devolver hashes.
- Refresh: rotación atómica y familia; reutilizar token gastado revoca familia. Reintentos concurrentes desde Flutter se serializan con un coordinador para no producir replay accidental.
- /me: DTO privado mínimo id/displayName/capacidades/consentVersions y sessionId donde sea necesario. No expone secreto, refreshHash o permisos derivados del modo visual.
- Logout: sid del JWT, revocación durable y Redis; idempotente, sin confiar en userId arbitrario del body. Flutter borra credenciales, datos privados y conexiones al confirmar o al registrar cierre local pendiente si no hay red; no afirmar que el servidor revocó cuando está offline.

## Casos de aceptación del incremento

| ID | Dado | Cuando | Entonces |
|---|---|---|---|
| AC-001-I01 | Teléfono sin prueba válida | Se solicita registro | Se rechaza sin crear cuenta/sesión |
| AC-001-I02 | Desafío vencido o con intentos agotados | Se verifica código | No emite proof ni reinicia contador; respuesta y reintento controlados |
| AC-001-I03 | Prueba válida y consentimiento vigente | Se registra dos veces con reintento | Una cuenta; efecto idempotente o conflicto definido, nunca dos identidades |
| AC-001-I04 | Credencial incorrecta o cuenta inexistente | Se inicia sesión | Error neutral y límites; no revela existencia |
| AC-001-I05 | Refresh activo | Se renueva y luego se reusa el gastado | Nueva generación funciona y replay se trata según familia, sin sesiones duplicadas |
| AC-001-I06 | Sesión aceptada en instancias A y B | Logout en A y GET /me en B | B rechaza token revocado; se conserva evidencia de ambas instancias |
| AC-001-I07 | Cuenta Ana con datos locales privados | Ana sale y Carlos entra | Ninguna pantalla, borrador, repo o query devuelve datos privados de Ana |
| AC-001-I08 | Redis de seguridad inaccesible | Se accede con token sin estado comprobable | Consulta fuente durable o rechaza; no autoriza por omisión |
| AC-001-I09 | Sesión válida y refresh protegido | Se reinicia Flutter | Recupera sesión con control de expiración, sin mostrar datos antes de identificar cuenta |
| AC-001-I10 | Usuario sin red | Pulsa salir | Cierra acceso local; informa límite remoto y procesa revocación pendiente con política definida al recuperar conexión |

## Orden de tareas concretas

1. Ratificar stack y valores de seguridad, definir proveedor SMS/moderación de nombre y responsables; registrar versión Ready.
2. Escribir OpenAPI S01 para las siete operaciones, DTO/errores/ejemplos; validar esquemas y permitir únicamente referencias locales del proyecto. Revisar cliente y provider sobre el mismo contrato.
3. Diseñar accounts, otp_challenges y sessions, unicidad phoneE164, expiración lógica e índices TTL; estrategia transaccional de consumo de prueba/registro y refresh. Roles MongoDB propios.
4. Implementar invariantes y casos de uso: desafío, verificación, registro, login, refresh, cuenta y logout; puertos para SMS, hash, tiempo, tokens y repositorio.
5. Implementar adaptadores configurables y middleware; integrar Redis con política de seguridad; métricas sin PII; smoke de dos instancias.
6. Implementar pantallas Flutter y repositorios derivados del contrato, almacenamiento seguro de credenciales y namespace de cuenta; serializar refresh.
7. Ejecutar AC-001-I01..I10 con resultados por caso y entorno; distinguir dobles de proveedores reales; revisar contrato y cerrar solo lo comprobado.

## Evidencia mínima y riesgos

Contrato validado, pruebas dominio/integración, recorrido Android, traza de revocación en A/B sin tokens, verificación de aislamiento y escenarios de dependencia caída. Si SMS usa doble en desarrollo, la historia puede verificarse parcialmente pero la aceptación de OTP productivo sigue pendiente. No crear repositorio, pipeline o nube por este documento: las tareas describen el siguiente encargo de implementación.
