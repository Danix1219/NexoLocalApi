# Cobertura funcional y endpoints — 0.4.0

**Resultado vigente:** 26 specs API y 25 móviles. Validación documental aplicada: ambos scripts/check_sdd.ps1 terminaron con exit 0; revisión adicional sin fallos de asignación, referencias, cobertura o ciclos locales de tareas. Los 101 contratos formales permanecen pendientes. Ver resultados y límites al final.

Fecha: 2026-11-02. Diseño propuesto; ninguna operación implementada o aprobada por este documento. La revisión anterior acreditaba estructura, no cobertura individual de todas las operaciones.

## Mapa de las 101 operaciones

Una spec primaria por EP; se conserva método/ruta/propietario y se modifica solo asignación de capacidad. API: requisito/tarea/AC propios. App: intención de consumo propia o exclusión expresa por superficie. [Fichas de diseño](../API_NexoLocal/docs/contracts/fichas-operaciones.md) enlazan autoridad única, sin reemplazar OpenAPI pendiente.

| EP | Método/ruta | Propietario | Spec API y traza local | Consumidor móvil primario o exclusión | Estado de alcance |
|---|---|---|---|---|---|
| EP-001 | POST `/auth/otp` | S01 | [nv-04](../API_NexoLocal/specs/nv-04/spec.md) / FR-201/T-201/AC-201 | [004-identidad-sesion](../App_NexoLocal/specs/004-identidad-sesion/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-002 | POST `/auth/otp/verify` | S01 | [nv-04](../API_NexoLocal/specs/nv-04/spec.md) / FR-202/T-202/AC-202 | [004-identidad-sesion](../App_NexoLocal/specs/004-identidad-sesion/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-003 | POST `/auth/register` | S01 | [nv-04](../API_NexoLocal/specs/nv-04/spec.md) / FR-203/T-203/AC-203 | [004-identidad-sesion](../App_NexoLocal/specs/004-identidad-sesion/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-004 | POST `/auth/login` | S01 | [nv-04](../API_NexoLocal/specs/nv-04/spec.md) / FR-204/T-204/AC-204 | [004-identidad-sesion](../App_NexoLocal/specs/004-identidad-sesion/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-005 | POST `/auth/refresh` | S01 | [nv-04](../API_NexoLocal/specs/nv-04/spec.md) / FR-205/T-205/AC-205 | [004-identidad-sesion](../App_NexoLocal/specs/004-identidad-sesion/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-006 | POST `/auth/password-reset` | S01 | [nv-16](../API_NexoLocal/specs/nv-16/spec.md) / FR-206/T-206/AC-206 | [017-cuenta-recuperacion-sesiones](../App_NexoLocal/specs/017-cuenta-recuperacion-sesiones/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-007 | POST `/auth/logout` | S01 | [nv-04](../API_NexoLocal/specs/nv-04/spec.md) / FR-207/T-207/AC-207 | [004-identidad-sesion](../App_NexoLocal/specs/004-identidad-sesion/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-008 | GET `/me` | S01 | [nv-04](../API_NexoLocal/specs/nv-04/spec.md) / FR-208/T-208/AC-208 | [004-identidad-sesion](../App_NexoLocal/specs/004-identidad-sesion/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-009 | PATCH `/me` | S01 | [nv-16](../API_NexoLocal/specs/nv-16/spec.md) / FR-209/T-209/AC-209 | [017-cuenta-recuperacion-sesiones](../App_NexoLocal/specs/017-cuenta-recuperacion-sesiones/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-010 | GET `/me/sessions` | S01 | [nv-16](../API_NexoLocal/specs/nv-16/spec.md) / FR-210/T-210/AC-210 | [017-cuenta-recuperacion-sesiones](../App_NexoLocal/specs/017-cuenta-recuperacion-sesiones/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-011 | DELETE `/me/sessions/{sid}` | S01 | [nv-16](../API_NexoLocal/specs/nv-16/spec.md) / FR-211/T-211/AC-211 | [017-cuenta-recuperacion-sesiones](../App_NexoLocal/specs/017-cuenta-recuperacion-sesiones/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-012 | POST `/me/deletion` | S01 | [nv-12](../API_NexoLocal/specs/nv-12/spec.md) / FR-212/T-212/AC-212 | [012-notificaciones-borrado](../App_NexoLocal/specs/012-notificaciones-borrado/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-013 | GET `/me/deletion/{id}` | S01 | [nv-12](../API_NexoLocal/specs/nv-12/spec.md) / FR-213/T-213/AC-213 | [012-notificaciones-borrado](../App_NexoLocal/specs/012-notificaciones-borrado/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-014 | GET `/catalog/categories` | S02 | [nv-17](../API_NexoLocal/specs/nv-17/spec.md) / FR-214/T-214/AC-214 | [018-catalogo-seleccion](../App_NexoLocal/specs/018-catalogo-seleccion/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-015 | PUT `/admin/catalog/categories/{id}` | S02 | [nv-17](../API_NexoLocal/specs/nv-17/spec.md) / FR-215/T-215/AC-215 | Sin consumo directo: administrativa | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-016 | POST `/providers` | S02 | [nv-06](../API_NexoLocal/specs/nv-06/spec.md) / FR-216/T-216/AC-216 | [006-perfiles](../App_NexoLocal/specs/006-perfiles/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-017 | GET `/providers/{id}` | S02 | [nv-06](../API_NexoLocal/specs/nv-06/spec.md) / FR-217/T-217/AC-217 | [006-perfiles](../App_NexoLocal/specs/006-perfiles/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-018 | GET `/me/provider` | S02 | [nv-06](../API_NexoLocal/specs/nv-06/spec.md) / FR-218/T-218/AC-218 | [006-perfiles](../App_NexoLocal/specs/006-perfiles/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-019 | PATCH `/me/provider` | S02 | [nv-06](../API_NexoLocal/specs/nv-06/spec.md) / FR-219/T-219/AC-219 | [006-perfiles](../App_NexoLocal/specs/006-perfiles/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-020 | PATCH `/me/provider/coverage` | S02 | [nv-06](../API_NexoLocal/specs/nv-06/spec.md) / FR-220/T-220/AC-220 | [006-perfiles](../App_NexoLocal/specs/006-perfiles/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-021 | PATCH `/me/provider/schedule` | S02 | [nv-06](../API_NexoLocal/specs/nv-06/spec.md) / FR-221/T-221/AC-221 | [006-perfiles](../App_NexoLocal/specs/006-perfiles/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-022 | PATCH `/me/provider/prices` | S02 | [nv-06](../API_NexoLocal/specs/nv-06/spec.md) / FR-222/T-222/AC-222 | [006-perfiles](../App_NexoLocal/specs/006-perfiles/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-023 | POST `/me/provider/refresh` | S02 | [nv-06](../API_NexoLocal/specs/nv-06/spec.md) / FR-223/T-223/AC-223 | [006-perfiles](../App_NexoLocal/specs/006-perfiles/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-024 | DELETE `/me/provider` | S02 | [nv-06](../API_NexoLocal/specs/nv-06/spec.md) / FR-224/T-224/AC-224 | [006-perfiles](../App_NexoLocal/specs/006-perfiles/spec.md) | Complemento de diseño; condición/UX y alcance se ratifican antes de Ready, sin pantalla inventada. |
| EP-025 | GET `/providers` | S02 | [nv-07](../API_NexoLocal/specs/nv-07/spec.md) / FR-225/T-225/AC-225 | [007-descubrimiento](../App_NexoLocal/specs/007-descubrimiento/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-026 | GET `/search/suggestions` | S02 | [nv-07](../API_NexoLocal/specs/nv-07/spec.md) / FR-226/T-226/AC-226 | [007-descubrimiento](../App_NexoLocal/specs/007-descubrimiento/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-027 | GET `/providers/compare` | S02 | [nv-07](../API_NexoLocal/specs/nv-07/spec.md) / FR-227/T-227/AC-227 | [007-descubrimiento](../App_NexoLocal/specs/007-descubrimiento/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-028 | GET `/geo/search` | S02 | [nv-07](../API_NexoLocal/specs/nv-07/spec.md) / FR-228/T-228/AC-228 | [007-descubrimiento](../App_NexoLocal/specs/007-descubrimiento/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-029 | GET `/geo/reverse` | S02 | [nv-07](../API_NexoLocal/specs/nv-07/spec.md) / FR-229/T-229/AC-229 | [007-descubrimiento](../App_NexoLocal/specs/007-descubrimiento/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-030 | GET `/feed` | S03 | [nv-07](../API_NexoLocal/specs/nv-07/spec.md) / FR-230/T-230/AC-230 | [007-descubrimiento](../App_NexoLocal/specs/007-descubrimiento/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-031 | POST `/posts` | S03 | [nv-08](../API_NexoLocal/specs/nv-08/spec.md) / FR-231/T-231/AC-231 | [008-comunidad](../App_NexoLocal/specs/008-comunidad/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-032 | GET `/posts` | S03 | [nv-08](../API_NexoLocal/specs/nv-08/spec.md) / FR-232/T-232/AC-232 | [008-comunidad](../App_NexoLocal/specs/008-comunidad/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-033 | GET `/posts/{id}` | S03 | [nv-08](../API_NexoLocal/specs/nv-08/spec.md) / FR-233/T-233/AC-233 | [008-comunidad](../App_NexoLocal/specs/008-comunidad/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-034 | PATCH `/posts/{id}` | S03 | [nv-08](../API_NexoLocal/specs/nv-08/spec.md) / FR-234/T-234/AC-234 | [008-comunidad](../App_NexoLocal/specs/008-comunidad/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-035 | DELETE `/posts/{id}` | S03 | [nv-08](../API_NexoLocal/specs/nv-08/spec.md) / FR-235/T-235/AC-235 | [008-comunidad](../App_NexoLocal/specs/008-comunidad/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-036 | PUT `/reactions/{type}/{id}` | S03 | [nv-18](../API_NexoLocal/specs/nv-18/spec.md) / FR-236/T-236/AC-236 | [019-guardados-indicadores](../App_NexoLocal/specs/019-guardados-indicadores/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-037 | DELETE `/reactions/{type}/{id}` | S03 | [nv-18](../API_NexoLocal/specs/nv-18/spec.md) / FR-237/T-237/AC-237 | [019-guardados-indicadores](../App_NexoLocal/specs/019-guardados-indicadores/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-038 | GET `/me/saved` | S03 | [nv-18](../API_NexoLocal/specs/nv-18/spec.md) / FR-238/T-238/AC-238 | [019-guardados-indicadores](../App_NexoLocal/specs/019-guardados-indicadores/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-039 | PUT `/me/saved/{type}/{id}` | S03 | [nv-18](../API_NexoLocal/specs/nv-18/spec.md) / FR-239/T-239/AC-239 | [019-guardados-indicadores](../App_NexoLocal/specs/019-guardados-indicadores/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-040 | DELETE `/me/saved/{type}/{id}` | S03 | [nv-18](../API_NexoLocal/specs/nv-18/spec.md) / FR-240/T-240/AC-240 | [019-guardados-indicadores](../App_NexoLocal/specs/019-guardados-indicadores/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-041 | POST `/reviews` | S03 | [nv-19](../API_NexoLocal/specs/nv-19/spec.md) / FR-241/T-241/AC-241 | [020-experiencias-reputacion](../App_NexoLocal/specs/020-experiencias-reputacion/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-042 | GET `/providers/{id}/reviews` | S03 | [nv-19](../API_NexoLocal/specs/nv-19/spec.md) / FR-242/T-242/AC-242 | [020-experiencias-reputacion](../App_NexoLocal/specs/020-experiencias-reputacion/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-043 | PATCH `/reviews/{id}` | S03 | [nv-19](../API_NexoLocal/specs/nv-19/spec.md) / FR-243/T-243/AC-243 | [020-experiencias-reputacion](../App_NexoLocal/specs/020-experiencias-reputacion/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-044 | DELETE `/reviews/{id}` | S03 | [nv-19](../API_NexoLocal/specs/nv-19/spec.md) / FR-244/T-244/AC-244 | [020-experiencias-reputacion](../App_NexoLocal/specs/020-experiencias-reputacion/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-045 | POST `/interactions` | S03 | [nv-18](../API_NexoLocal/specs/nv-18/spec.md) / FR-245/T-245/AC-245 | [019-guardados-indicadores](../App_NexoLocal/specs/019-guardados-indicadores/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-046 | GET `/me/provider/metrics` | S03 | [nv-18](../API_NexoLocal/specs/nv-18/spec.md) / FR-246/T-246/AC-246 | [019-guardados-indicadores](../App_NexoLocal/specs/019-guardados-indicadores/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-047 | POST `/requests` | S04 | [nv-09](../API_NexoLocal/specs/nv-09/spec.md) / FR-247/T-247/AC-247 | [009-solicitudes](../App_NexoLocal/specs/009-solicitudes/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-048 | GET `/requests` | S04 | [nv-09](../API_NexoLocal/specs/nv-09/spec.md) / FR-248/T-248/AC-248 | [009-solicitudes](../App_NexoLocal/specs/009-solicitudes/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-049 | GET `/requests/{id}` | S04 | [nv-09](../API_NexoLocal/specs/nv-09/spec.md) / FR-249/T-249/AC-249 | [009-solicitudes](../App_NexoLocal/specs/009-solicitudes/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-050 | PATCH `/requests/{id}` | S04 | [nv-09](../API_NexoLocal/specs/nv-09/spec.md) / FR-250/T-250/AC-250 | [009-solicitudes](../App_NexoLocal/specs/009-solicitudes/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-051 | POST `/requests/{id}/close` | S04 | [nv-09](../API_NexoLocal/specs/nv-09/spec.md) / FR-251/T-251/AC-251 | [009-solicitudes](../App_NexoLocal/specs/009-solicitudes/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-052 | DELETE `/requests/{id}` | S04 | [nv-09](../API_NexoLocal/specs/nv-09/spec.md) / FR-252/T-252/AC-252 | [009-solicitudes](../App_NexoLocal/specs/009-solicitudes/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-053 | PUT `/requests/{id}/interest` | S04 | [nv-20](../API_NexoLocal/specs/nv-20/spec.md) / FR-253/T-253/AC-253 | [021-interesados-candidatos](../App_NexoLocal/specs/021-interesados-candidatos/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-054 | DELETE `/requests/{id}/interest` | S04 | [nv-20](../API_NexoLocal/specs/nv-20/spec.md) / FR-254/T-254/AC-254 | [021-interesados-candidatos](../App_NexoLocal/specs/021-interesados-candidatos/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-055 | GET `/requests/{id}/interests` | S04 | [nv-20](../API_NexoLocal/specs/nv-20/spec.md) / FR-255/T-255/AC-255 | [021-interesados-candidatos](../App_NexoLocal/specs/021-interesados-candidatos/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-056 | PUT `/requests/{id}/shortlist/{providerId}` | S04 | [nv-20](../API_NexoLocal/specs/nv-20/spec.md) / FR-256/T-256/AC-256 | [021-interesados-candidatos](../App_NexoLocal/specs/021-interesados-candidatos/spec.md) | Opcional; no bloquea alcance obligatorio si no se habilita. |
| EP-057 | DELETE `/requests/{id}/shortlist/{providerId}` | S04 | [nv-20](../API_NexoLocal/specs/nv-20/spec.md) / FR-257/T-257/AC-257 | [021-interesados-candidatos](../App_NexoLocal/specs/021-interesados-candidatos/spec.md) | Opcional; no bloquea alcance obligatorio si no se habilita. |
| EP-058 | POST `/orders` | S04 | [nv-10](../API_NexoLocal/specs/nv-10/spec.md) / FR-258/T-258/AC-258 | [010-pedidos](../App_NexoLocal/specs/010-pedidos/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-059 | GET `/me/orders` | S04 | [nv-10](../API_NexoLocal/specs/nv-10/spec.md) / FR-259/T-259/AC-259 | [010-pedidos](../App_NexoLocal/specs/010-pedidos/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-060 | GET `/orders/{id}` | S04 | [nv-10](../API_NexoLocal/specs/nv-10/spec.md) / FR-260/T-260/AC-260 | [010-pedidos](../App_NexoLocal/specs/010-pedidos/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-061 | POST `/orders/{id}/accept` | S04 | [nv-10](../API_NexoLocal/specs/nv-10/spec.md) / FR-261/T-261/AC-261 | [010-pedidos](../App_NexoLocal/specs/010-pedidos/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-062 | POST `/orders/{id}/reject` | S04 | [nv-10](../API_NexoLocal/specs/nv-10/spec.md) / FR-262/T-262/AC-262 | [010-pedidos](../App_NexoLocal/specs/010-pedidos/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-063 | POST `/orders/{id}/cancel` | S04 | [nv-10](../API_NexoLocal/specs/nv-10/spec.md) / FR-263/T-263/AC-263 | [010-pedidos](../App_NexoLocal/specs/010-pedidos/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-064 | POST `/orders/{id}/complete` | S04 | [nv-10](../API_NexoLocal/specs/nv-10/spec.md) / FR-264/T-264/AC-264 | [010-pedidos](../App_NexoLocal/specs/010-pedidos/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-065 | PATCH `/orders/{id}/address` | S04 | [nv-10](../API_NexoLocal/specs/nv-10/spec.md) / FR-265/T-265/AC-265 | [010-pedidos](../App_NexoLocal/specs/010-pedidos/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-066 | POST `/conversations` | S05 | [nv-11](../API_NexoLocal/specs/nv-11/spec.md) / FR-266/T-266/AC-266 | [011-mensajeria](../App_NexoLocal/specs/011-mensajeria/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-067 | GET `/me/conversations` | S05 | [nv-11](../API_NexoLocal/specs/nv-11/spec.md) / FR-267/T-267/AC-267 | [011-mensajeria](../App_NexoLocal/specs/011-mensajeria/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-068 | GET `/conversations/{id}/messages` | S05 | [nv-11](../API_NexoLocal/specs/nv-11/spec.md) / FR-268/T-268/AC-268 | [011-mensajeria](../App_NexoLocal/specs/011-mensajeria/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-069 | POST `/conversations/{id}/messages` | S05 | [nv-11](../API_NexoLocal/specs/nv-11/spec.md) / FR-269/T-269/AC-269 | [011-mensajeria](../App_NexoLocal/specs/011-mensajeria/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-070 | PUT `/conversations/{id}/read` | S05 | [nv-11](../API_NexoLocal/specs/nv-11/spec.md) / FR-270/T-270/AC-270 | [011-mensajeria](../App_NexoLocal/specs/011-mensajeria/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-071 | PUT `/conversations/{id}/block` | S05 | [nv-11](../API_NexoLocal/specs/nv-11/spec.md) / FR-271/T-271/AC-271 | [011-mensajeria](../App_NexoLocal/specs/011-mensajeria/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-072 | DELETE `/conversations/{id}/block` | S05 | [nv-11](../API_NexoLocal/specs/nv-11/spec.md) / FR-272/T-272/AC-272 | [011-mensajeria](../App_NexoLocal/specs/011-mensajeria/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-073 | POST `/realtime/ticket` | S01 | [nv-04](../API_NexoLocal/specs/nv-04/spec.md) / FR-273/T-273/AC-273 | [011-mensajeria](../App_NexoLocal/specs/011-mensajeria/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-074 | WS `/ws/v1/chat` | S05 | [nv-11](../API_NexoLocal/specs/nv-11/spec.md) / FR-274/T-274/AC-274 | [011-mensajeria](../App_NexoLocal/specs/011-mensajeria/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-075 | POST `/media` | S06 | [nv-05](../API_NexoLocal/specs/nv-05/spec.md) / FR-275/T-275/AC-275 | [005-contenido-seguro](../App_NexoLocal/specs/005-contenido-seguro/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-076 | GET `/media/{id}/access` | S06 | [nv-05](../API_NexoLocal/specs/nv-05/spec.md) / FR-276/T-276/AC-276 | [005-contenido-seguro](../App_NexoLocal/specs/005-contenido-seguro/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-077 | DELETE `/media/{id}` | S06 | [nv-05](../API_NexoLocal/specs/nv-05/spec.md) / FR-277/T-277/AC-277 | [005-contenido-seguro](../App_NexoLocal/specs/005-contenido-seguro/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-078 | POST `/reports` | S06 | [nv-05](../API_NexoLocal/specs/nv-05/spec.md) / FR-278/T-278/AC-278 | [005-contenido-seguro](../App_NexoLocal/specs/005-contenido-seguro/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-079 | GET `/me/reports` | S06 | [nv-05](../API_NexoLocal/specs/nv-05/spec.md) / FR-279/T-279/AC-279 | [005-contenido-seguro](../App_NexoLocal/specs/005-contenido-seguro/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-080 | GET `/admin/reports` | S06 | [nv-24](../API_NexoLocal/specs/nv-24/spec.md) / FR-280/T-280/AC-280 | Sin consumo directo: administrativa | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-081 | POST `/admin/reports/{id}/decision` | S06 | [nv-24](../API_NexoLocal/specs/nv-24/spec.md) / FR-281/T-281/AC-281 | Sin consumo directo: administrativa | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-082 | POST `/assist/draft` | S06 | [nv-13](../API_NexoLocal/specs/nv-13/spec.md) / FR-282/T-282/AC-282 | [013-inteligencia](../App_NexoLocal/specs/013-inteligencia/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-083 | PUT `/me/devices/{id}` | S07 | [nv-21](../API_NexoLocal/specs/nv-21/spec.md) / FR-283/T-283/AC-283 | [022-push-dispositivos](../App_NexoLocal/specs/022-push-dispositivos/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-084 | DELETE `/me/devices/{id}` | S07 | [nv-21](../API_NexoLocal/specs/nv-21/spec.md) / FR-284/T-284/AC-284 | [022-push-dispositivos](../App_NexoLocal/specs/022-push-dispositivos/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-085 | GET `/me/notifications` | S07 | [nv-21](../API_NexoLocal/specs/nv-21/spec.md) / FR-285/T-285/AC-285 | [022-push-dispositivos](../App_NexoLocal/specs/022-push-dispositivos/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-086 | PUT `/me/notifications/{id}/read` | S07 | [nv-21](../API_NexoLocal/specs/nv-21/spec.md) / FR-286/T-286/AC-286 | [022-push-dispositivos](../App_NexoLocal/specs/022-push-dispositivos/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-087 | POST `/internal/moderation/check` | S06 | [nv-05](../API_NexoLocal/specs/nv-05/spec.md) / FR-287/T-287/AC-287 | Sin consumo directo: interna entre servicios | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-088 | GET `/internal/orders/{id}/review-eligibility` | S04 | [nv-10](../API_NexoLocal/specs/nv-10/spec.md) / FR-288/T-288/AC-288 | Sin consumo directo: interna entre servicios | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-089 | GET `/health/live` | Transversal | [nv-01](../API_NexoLocal/specs/nv-01/spec.md) / FR-289/T-289/AC-289 | Sin consumo directo: infraestructura | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-090 | GET `/health/ready` | Transversal | [nv-01](../API_NexoLocal/specs/nv-01/spec.md) / FR-290/T-290/AC-290 | Sin consumo directo: infraestructura | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-091 | GET `/providers/{id}/contact` | S02 | [nv-25](../API_NexoLocal/specs/nv-25/spec.md) / FR-291/T-291/AC-291 | [025-contacto-consentimiento](../App_NexoLocal/specs/025-contacto-consentimiento/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-092 | GET `/orders/{id}/contact` | S04 | [nv-25](../API_NexoLocal/specs/nv-25/spec.md) / FR-292/T-292/AC-292 | [025-contacto-consentimiento](../App_NexoLocal/specs/025-contacto-consentimiento/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-093 | GET `/mentions/suggestions` | S02 | [nv-19](../API_NexoLocal/specs/nv-19/spec.md) / FR-293/T-293/AC-293 | [020-experiencias-reputacion](../App_NexoLocal/specs/020-experiencias-reputacion/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-094 | GET `/me/reviews` | S03 | [nv-19](../API_NexoLocal/specs/nv-19/spec.md) / FR-294/T-294/AC-294 | [020-experiencias-reputacion](../App_NexoLocal/specs/020-experiencias-reputacion/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-095 | GET `/reviews/{id}` | S03 | [nv-19](../API_NexoLocal/specs/nv-19/spec.md) / FR-295/T-295/AC-295 | [020-experiencias-reputacion](../App_NexoLocal/specs/020-experiencias-reputacion/spec.md) | Complemento de diseño; condición/UX y alcance se ratifican antes de Ready, sin pantalla inventada. |
| EP-096 | PATCH `/me/provider/contact-preferences` | S02 | [nv-25](../API_NexoLocal/specs/nv-25/spec.md) / FR-296/T-296/AC-296 | [025-contacto-consentimiento](../App_NexoLocal/specs/025-contacto-consentimiento/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-097 | PATCH `/orders/{id}/contact-preference` | S04 | [nv-25](../API_NexoLocal/specs/nv-25/spec.md) / FR-297/T-297/AC-297 | [025-contacto-consentimiento](../App_NexoLocal/specs/025-contacto-consentimiento/spec.md) | Complemento de diseño; condición/UX y alcance se ratifican antes de Ready, sin pantalla inventada. |
| EP-098 | POST `/graphql/social/v1` | S08 | [nv-15](../API_NexoLocal/specs/nv-15/spec.md) / FR-298/T-298/AC-298 | [015-relaciones-opcional](../App_NexoLocal/specs/015-relaciones-opcional/spec.md) | Opcional; no bloquea alcance obligatorio si no se habilita. |
| EP-099 | GET `/catalog/report-reasons` | S06 | [nv-05](../API_NexoLocal/specs/nv-05/spec.md) / FR-299/T-299/AC-299 | [005-contenido-seguro](../App_NexoLocal/specs/005-contenido-seguro/spec.md) | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-100 | GET `/internal/providers/{id}/contact-policy` | S02 | [nv-25](../API_NexoLocal/specs/nv-25/spec.md) / FR-300/T-300/AC-300 | Sin consumo directo: interna entre servicios | Previsto en línea base; contrato formal y aceptación pendientes. |
| EP-101 | POST `/internal/accounts/visibility-batch` | S01 | [nv-04](../API_NexoLocal/specs/nv-04/spec.md) / FR-301/T-301/AC-301 | Sin consumo directo: interna entre servicios | Previsto en línea base; contrato formal y aceptación pendientes. |

## Consumo secundario e integración

App 016 integra EP-038/039/040 para sincronización; el dueño de intención es 019. App 006/007/009 consumen catálogo de 018. Perfil/pedido/chat invocan contacto vía 025, sin repetir regla. App 012 inicia borrado y verifica retiro de dispositivo con 022; el borrado global espera acuses de todos los dueños habilitados. EP-073 es producido en S01/nv-04 pero se consume principalmente en 011. EP-088/100/101 son entre servicios, nunca acceso Flutter.

## No equivalencia con producto listo

Los 101 registros son baseline de diseño; 056/057/098 opcionales y 024/095/097 complementos requieren decisión de alcance/UX. No se agregan endpoints ni se fuerza pantalla por registro. Falta formalizar tipos/nulos/enums/errores y ejecutar pruebas; decisiones D01–D08 y revisión humana no se inventan.

## Componentes backend del XLSX

| Componente | Spec primaria | Traza |
|---|---|---|
| G01 | [nv-01](../API_NexoLocal/specs/nv-01/spec.md) | FR-601/T-601/AC-601 |
| S01 | [nv-04](../API_NexoLocal/specs/nv-04/spec.md) | FR-602/T-602/AC-602 |
| S02 | [nv-06](../API_NexoLocal/specs/nv-06/spec.md) | FR-603/T-603/AC-603 |
| S03 | [nv-08](../API_NexoLocal/specs/nv-08/spec.md) | FR-604/T-604/AC-604 |
| S04 | [nv-10](../API_NexoLocal/specs/nv-10/spec.md) | FR-605/T-605/AC-605 |
| S05 | [nv-11](../API_NexoLocal/specs/nv-11/spec.md) | FR-606/T-606/AC-606 |
| S06 | [nv-05](../API_NexoLocal/specs/nv-05/spec.md) | FR-607/T-607/AC-607 |
| S07 | [nv-21](../API_NexoLocal/specs/nv-21/spec.md) | FR-608/T-608/AC-608 |
| S08 | [nv-15](../API_NexoLocal/specs/nv-15/spec.md) | FR-609/T-609/AC-609 |
| I01 | [nv-01](../API_NexoLocal/specs/nv-01/spec.md) | FR-610/T-610/AC-610 |
| I02 | [nv-22](../API_NexoLocal/specs/nv-22/spec.md) | FR-611/T-611/AC-611 |
| I03 | [nv-14](../API_NexoLocal/specs/nv-14/spec.md) | FR-612/T-612/AC-612 |
| I04 | [nv-14](../API_NexoLocal/specs/nv-14/spec.md) | FR-613/T-613/AC-613 |

## Componentes móviles del XLSX

| Componente | Spec de experiencia primaria | Traza |
|---|---|---|
| M01 | [001-base-flutter](../App_NexoLocal/specs/001-base-flutter/spec.md) | FR-501/T-501/AC-501 |
| M02 | [004-identidad-sesion](../App_NexoLocal/specs/004-identidad-sesion/spec.md) | FR-502/T-502/AC-502 |
| M03 | [004-identidad-sesion](../App_NexoLocal/specs/004-identidad-sesion/spec.md) | FR-503/T-503/AC-503 |
| M04 | [006-perfiles](../App_NexoLocal/specs/006-perfiles/spec.md) | FR-504/T-504/AC-504 |
| M05 | [001-base-flutter](../App_NexoLocal/specs/001-base-flutter/spec.md) | FR-505/T-505/AC-505 |
| M06 | [007-descubrimiento](../App_NexoLocal/specs/007-descubrimiento/spec.md) | FR-506/T-506/AC-506 |
| M07 | [007-descubrimiento](../App_NexoLocal/specs/007-descubrimiento/spec.md) | FR-507/T-507/AC-507 |
| M08 | [007-descubrimiento](../App_NexoLocal/specs/007-descubrimiento/spec.md) | FR-508/T-508/AC-508 |
| M09 | [009-solicitudes](../App_NexoLocal/specs/009-solicitudes/spec.md) | FR-509/T-509/AC-509 |
| M10 | [007-descubrimiento](../App_NexoLocal/specs/007-descubrimiento/spec.md) | FR-510/T-510/AC-510 |
| M11 | [006-perfiles](../App_NexoLocal/specs/006-perfiles/spec.md) | FR-511/T-511/AC-511 |
| M12 | [007-descubrimiento](../App_NexoLocal/specs/007-descubrimiento/spec.md) | FR-512/T-512/AC-512 |
| M13 | [009-solicitudes](../App_NexoLocal/specs/009-solicitudes/spec.md) | FR-513/T-513/AC-513 |
| M14 | [008-comunidad](../App_NexoLocal/specs/008-comunidad/spec.md) | FR-514/T-514/AC-514 |
| M15 | [020-experiencias-reputacion](../App_NexoLocal/specs/020-experiencias-reputacion/spec.md) | FR-515/T-515/AC-515 |
| M16 | [021-interesados-candidatos](../App_NexoLocal/specs/021-interesados-candidatos/spec.md) | FR-516/T-516/AC-516 |
| M17 | [010-pedidos](../App_NexoLocal/specs/010-pedidos/spec.md) | FR-517/T-517/AC-517 |
| M18 | [011-mensajeria](../App_NexoLocal/specs/011-mensajeria/spec.md) | FR-518/T-518/AC-518 |
| M19 | [011-mensajeria](../App_NexoLocal/specs/011-mensajeria/spec.md) | FR-519/T-519/AC-519 |
| M20 | [019-guardados-indicadores](../App_NexoLocal/specs/019-guardados-indicadores/spec.md) | FR-520/T-520/AC-520 |
| M21 | [006-perfiles](../App_NexoLocal/specs/006-perfiles/spec.md) | FR-521/T-521/AC-521 |
| M22 | [022-push-dispositivos](../App_NexoLocal/specs/022-push-dispositivos/spec.md) | FR-522/T-522/AC-522 |
| M23 | [005-contenido-seguro](../App_NexoLocal/specs/005-contenido-seguro/spec.md) | FR-523/T-523/AC-523 |
| M24 | [023-privacidad-permisos-enlaces](../App_NexoLocal/specs/023-privacidad-permisos-enlaces/spec.md) | FR-524/T-524/AC-524 |
| M25 | [013-inteligencia](../App_NexoLocal/specs/013-inteligencia/spec.md) | FR-525/T-525/AC-525 |
| M26 | [001-base-flutter](../App_NexoLocal/specs/001-base-flutter/spec.md) | FR-526/T-526/AC-526 |
| M27 | [023-privacidad-permisos-enlaces](../App_NexoLocal/specs/023-privacidad-permisos-enlaces/spec.md) | FR-527/T-527/AC-527 |

W01 tiene FR-528/T-528/AC-528 en API nv-23 y app 024; es coordinación del artefacto web separado.

## Requisitos académicos con tarea propia en ambas superficies

| Punto | API | App | Traza local |
|---|---|---|---|
| 01 Instalación desde Play | [nv-23](../API_NexoLocal/specs/nv-23/spec.md) | [014-entrega](../App_NexoLocal/specs/014-entrega/spec.md) | FR-401/T-401/AC-401 |
| 02 Evaluación interactiva y con prompts | [nv-00](../API_NexoLocal/specs/nv-00/spec.md) | [002-quality-gates](../App_NexoLocal/specs/002-quality-gates/spec.md) | FR-402/T-402/AC-402 |
| 03 Cinco componentes del proyecto | [nv-01](../API_NexoLocal/specs/nv-01/spec.md) | [001-base-flutter](../App_NexoLocal/specs/001-base-flutter/spec.md) | FR-403/T-403/AC-403 |
| 04 Correspondencia con maqueta | [nv-02](../API_NexoLocal/specs/nv-02/spec.md) | [001-base-flutter](../App_NexoLocal/specs/001-base-flutter/spec.md) | FR-404/T-404/AC-404 |
| 05 SDD y DevSecOps | [nv-00](../API_NexoLocal/specs/nv-00/spec.md) | [002-quality-gates](../App_NexoLocal/specs/002-quality-gates/spec.md) | FR-405/T-405/AC-405 |
| 06 Desarrollo con agentes | [nv-00](../API_NexoLocal/specs/nv-00/spec.md) | [001-base-flutter](../App_NexoLocal/specs/001-base-flutter/spec.md) | FR-406/T-406/AC-406 |
| 07 Pruebas | [nv-03](../API_NexoLocal/specs/nv-03/spec.md) | [002-quality-gates](../App_NexoLocal/specs/002-quality-gates/spec.md) | FR-407/T-407/AC-407 |
| 08 CI/CD | [nv-14](../API_NexoLocal/specs/nv-14/spec.md) | [014-entrega](../App_NexoLocal/specs/014-entrega/spec.md) | FR-408/T-408/AC-408 |
| 09 Caché en tres niveles | [nv-07](../API_NexoLocal/specs/nv-07/spec.md) | [016-sincronizacion-local](../App_NexoLocal/specs/016-sincronizacion-local/spec.md) | FR-409/T-409/AC-409 |
| 10 Logout | [nv-04](../API_NexoLocal/specs/nv-04/spec.md) | [004-identidad-sesion](../App_NexoLocal/specs/004-identidad-sesion/spec.md) | FR-410/T-410/AC-410 |
| 11 Matriz de versiones | [nv-00](../API_NexoLocal/specs/nv-00/spec.md) | [001-base-flutter](../App_NexoLocal/specs/001-base-flutter/spec.md) | FR-411/T-411/AC-411 |
| 12 MCP opcional | [nv-00](../API_NexoLocal/specs/nv-00/spec.md) | [003-contratos-consumo](../App_NexoLocal/specs/003-contratos-consumo/spec.md) | FR-412/T-412/AC-412 |
| 13 Nube y balanceo | [nv-14](../API_NexoLocal/specs/nv-14/spec.md) | [003-contratos-consumo](../App_NexoLocal/specs/003-contratos-consumo/spec.md) | FR-413/T-413/AC-413 |
| 14 NoSQL | [nv-22](../API_NexoLocal/specs/nv-22/spec.md) | [003-contratos-consumo](../App_NexoLocal/specs/003-contratos-consumo/spec.md) | FR-414/T-414/AC-414 |
| 15 Backend operativo | [nv-14](../API_NexoLocal/specs/nv-14/spec.md) | [003-contratos-consumo](../App_NexoLocal/specs/003-contratos-consumo/spec.md) | FR-415/T-415/AC-415 |
| 16 Móvil completo | [nv-05](../API_NexoLocal/specs/nv-05/spec.md) | [023-privacidad-permisos-enlaces](../App_NexoLocal/specs/023-privacidad-permisos-enlaces/spec.md) | FR-416/T-416/AC-416 |
| 17 Landing/Analytics | [nv-23](../API_NexoLocal/specs/nv-23/spec.md) | [024-landing-evaluacion](../App_NexoLocal/specs/024-landing-evaluacion/spec.md) | FR-417/T-417/AC-417 |
| 18 GitHub/coordinación | [nv-00](../API_NexoLocal/specs/nv-00/spec.md) | [001-base-flutter](../App_NexoLocal/specs/001-base-flutter/spec.md) | FR-418/T-418/AC-418 |
| 19 Paquete y evaluación | [nv-23](../API_NexoLocal/specs/nv-23/spec.md) | [024-landing-evaluacion](../App_NexoLocal/specs/024-landing-evaluacion/spec.md) | FR-419/T-419/AC-419 |

Las seis tareas previas PRE1–PRE6 son FR/T/AC-451..456 en API nv-00 y app 001; su evidencia común se enlaza, no se inventa o duplica. H01–H12 conservan los escenarios existentes y se complementan con las reglas específicas de cada EP (contacto 025, experiencias 019/020, perfiles, comparación, chat e interesados).

## Regresiones H01–H12 con tarea propia

| Hallazgo | API | App | Traza local |
|---|---|---|---|
| H01 No revelar teléfono de cliente pendiente | [nv-25](../API_NexoLocal/specs/nv-25/spec.md) | [025-contacto-consentimiento](../App_NexoLocal/specs/025-contacto-consentimiento/spec.md) | FR-701/T-701/AC-701 |
| H02 No revelar domicilio al rechazar/cancelar | [nv-10](../API_NexoLocal/specs/nv-10/spec.md) | [010-pedidos](../App_NexoLocal/specs/010-pedidos/spec.md) | FR-702/T-702/AC-702 |
| H03 Aislamiento entre cuentas | [nv-04](../API_NexoLocal/specs/nv-04/spec.md) | [004-identidad-sesion](../App_NexoLocal/specs/004-identidad-sesion/spec.md) | FR-703/T-703/AC-703 |
| H04 Mención reactiva | [nv-19](../API_NexoLocal/specs/nv-19/spec.md) | [020-experiencias-reputacion](../App_NexoLocal/specs/020-experiencias-reputacion/spec.md) | FR-704/T-704/AC-704 |
| H05 Respuesta rápida real | [nv-11](../API_NexoLocal/specs/nv-11/spec.md) | [011-mensajeria](../App_NexoLocal/specs/011-mensajeria/spec.md) | FR-705/T-705/AC-705 |
| H06 Completitud única | [nv-06](../API_NexoLocal/specs/nv-06/spec.md) | [006-perfiles](../App_NexoLocal/specs/006-perfiles/spec.md) | FR-706/T-706/AC-706 |
| H07 Contadores honestos | [nv-06](../API_NexoLocal/specs/nv-06/spec.md) | [006-perfiles](../App_NexoLocal/specs/006-perfiles/spec.md) | FR-707/T-707/AC-707 |
| H08 Comparación equivalente | [nv-07](../API_NexoLocal/specs/nv-07/spec.md) | [007-descubrimiento](../App_NexoLocal/specs/007-descubrimiento/spec.md) | FR-708/T-708/AC-708 |
| H09 Edición permanente | [nv-06](../API_NexoLocal/specs/nv-06/spec.md) | [006-perfiles](../App_NexoLocal/specs/006-perfiles/spec.md) | FR-709/T-709/AC-709 |
| H10 Modalidad solo local | [nv-06](../API_NexoLocal/specs/nv-06/spec.md) | [006-perfiles](../App_NexoLocal/specs/006-perfiles/spec.md) | FR-710/T-710/AC-710 |
| H11 Contexto de chat por mensaje | [nv-11](../API_NexoLocal/specs/nv-11/spec.md) | [011-mensajeria](../App_NexoLocal/specs/011-mensajeria/spec.md) | FR-711/T-711/AC-711 |
| H12 Límites y filtros reales | [nv-09](../API_NexoLocal/specs/nv-09/spec.md) | [009-solicitudes](../App_NexoLocal/specs/009-solicitudes/spec.md) | FR-712/T-712/AC-712 |

## Validación final 0.4.0 y límites

| Contexto | Specs | Tareas definidas | FR/NFR | AC | Lint final |
|---|---|---|---|---|---|
| API_NexoLocal | 26 | 444 | 392 | 282 | Exit 0; SDD-OK: 26 specs |
| App_NexoLocal | 25 | 439 | 389 | 286 | Exit 0; SDD-OK: 25 specs |

Se ejecutaron scripts/check_sdd.ps1 desde ambas carpetas tras aplicar cambios. La revisión adicional examinó enlaces, IDs definidos/citados/duplicados, FR/NFR/AC cubiertos por tareas/matriz y ciclos locales de tareas; devolvió 0 fallos. También verificó primario único de cada EP, consumidor o exclusión móvil, asignación individual de componentes/obligaciones/regresiones y que los 101 métodos/rutas/IDs coinciden con la fuente 1.2.0. Los Markdown móviles aplicados coinciden con la copia revisada, salvo Memoria, que incorpora además la salida real del lint.

El primer lint API durante preparación detectó enlaces a las nuevas specs móviles aún en copia temporal; tras aplicarlas, ambos lints terminaron correctamente. No queda ese fallo de enlaces pendiente.

Las comprobaciones adicionales fueron automatización temporal de sesión, no nuevo código entregado al proyecto. No se ejecutaron build, tests backend/Flutter, SQLite/Android, proveedores, carga, nube, Play, GA4 o QR. La cobertura es de la línea base documental examinada: no certifica semántica completa, diseño óptimo de cada regla ni aprobación humana. Los 101 formalContract siguen null; falta formalizar esquemas/tipos/nulos/enums/errores/compatibilidad y resolver D01–D08 pertinentes antes de Ready/aceptación. Opcionales y complementos conservan condiciones de alcance. No se añadieron rutas ni microservicios por el desglose.
