# Nexo Local: requisitos y arquitectura

Versión documental 1.2.0 · 29 de octubre de 2026. Diseño previo al desarrollo.

## Base de diseño y lectura del documento

Nexo Local es una red de servicios locales que permite descubrir prestadores, comparar sus perfiles, conversar, publicar necesidades, gestionar pedidos y compartir experiencias. Este documento organiza la preparación del desarrollo conforme a los 19 puntos y las seis tareas previas de los lineamientos del cuatrimestre septiembre-diciembre de 2026.

### Jerarquía de las fuentes

El PDF Requerimientos para el desarrollo del proyecto Móvil v2 establece las obligaciones académicas. La maqueta V1.00.002-Aprovada.html define el comportamiento funcional actual. Nexo_Local_Propuesta_de_proyecto.pdf aporta la problemática, los objetivos y el contexto. Los Markdown existentes se usan como referencia auxiliar y se corrigen cuando contradicen las dos fuentes principales.

### Estado del trabajo

Versión documental 1.2.0, 29 de octubre de 2026. Flutter es una decisión indicada por el equipo. La separación en microservicios responde a la dirección solicitada. .NET 10, Azure, la distribución de datos y los contratos aquí descritos son recomendaciones de diseño. No representan servicios ya instalados, una arquitectura previamente aprobada ni pruebas ejecutadas contra una aplicación real.

### Entregables complementarios

El libro Nexo_Local_Matrices.xlsx contiene la matriz de cumplimiento, componentes backend y móvil, entidades, catálogo de endpoints y una ficha por endpoint. Las fichas describen entradas, respuestas, permisos, reglas, diseño del documento NoSQL, llaves, índices y comprobaciones. La fuente Markdown permite revisar el texto sin editar el PDF.

### Alcance de la revisión

Auditoría interactiva realizada el 29/10/2026 en https://nexo-local-v1.netlify.app/ mediante Chrome DevTools MCP, alternativa autorizada por el usuario. Se usaron las cuentas demo de solicitante y prestador, y dos cuentas ficticias creadas para alta, recuperación y borrado. Las imágenes de prueba se generaron en el navegador y pasaron por los controles de archivo del prototipo (no por un servidor de moderación). Se recorrieron las funciones visibles de los 27 componentes móviles del inventario; M25 carece de integración real y M26 tiene verificación visual limitada. No se ejecutaron todas las combinaciones posibles ni pruebas de APIs, seguridad productiva o dispositivo Android. La landing W01 se conserva como pendiente separado. El script principal publicado coincide con el local aprobado: 253,043 caracteres normalizados a LF y SHA-256 6144a3bc4073aa74dc383543be98a38191bb8fb0cffc2c01213a7940ec4ccc94. Esta coincidencia no compara todos los assets ni el HTML completo.

### Pendientes que requieren datos reales

Faltan evidencia de entrevistas, URL de los proyectos del docente, cuenta de GitHub definitiva, responsables actualizados, cuenta y región de nube, disponibilidad de créditos, proveedor de SMS y estado de Play Console. Se entregan criterios y formatos para completarlos sin inventar resultados. El significado de costo cero debe confirmarse antes de provisionar recursos facturables.

## Actualización del alcance funcional

La versión aprobada amplía el alcance de la propuesta original. La regla del punto 4 impide eliminar funciones visibles de la maqueta al construir la app.

### Cambios frente a la propuesta

La propuesta anterior excluía chat interno y concentraba el contacto en canales externos (pp. 4, 16 y 28-30). La maqueta actual contiene bandeja y chat, pedidos con aceptación o rechazo, ubicación privada para el servicio y calificación posterior. Esas funciones pasan a formar parte del alcance inicial. Se conserva el contacto mediante copia del número. Las referencias residuales a WhatsApp en acciones antiguas no justifican reintroducirlo como canal principal.

### Visitante y cuenta única

El visitante explora contenido público y elige zona manualmente o con permiso de ubicación. Contactar, guardar, recomendar y comparar activan la invitación al registro. Una cuenta puede buscar servicios y disponer de un perfil de prestador; alternar el modo cambia la experiencia, pero nunca otorga permisos nuevos desde el cliente. El prestador puede ser persona con oficio o negocio.

### Prestadores y descubrimiento

Se conservan categorías, especialidades, servicios del negocio, biografía, foto y portada, modalidad a domicilio/en local/ambas, cobertura, horarios, urgencias, costo de visita, precios orientativos, formas de pago declaradas, garantía declarada y tiempo de respuesta. Se muestran perfiles, trabajos, opiniones, señales de confianza, completitud, comparación de dos prestadores, filtros, orden, autocompletado, mapa y estados sin resultados.

### Comunidad y pedidos

El solicitante publica una necesidad, revisa interesados y ordena candidatos; el prestador expresa o retira interés, incluso en otra categoría si la solicitud es visible. El solicitante envía el pedido desde el perfil, el chat o los interesados. El prestador acepta o rechaza, puede indicar precio acordado y marca el servicio como resuelto. Se conserva cancelación, cambio de domicilio durante estados permitidos y acceso posterior a la experiencia.

### Límites comerciales

Nexo Local registra coordinación y señales de confianza. No procesa pagos, comisiones, depósitos, facturación, garantías de ejecución ni contratos electrónicos en esta versión. Un precio acordado es información del pedido. Una calificación expresa opinión; el teléfono confirmado acredita control del número, no competencia profesional ni identidad legal.

### Correcciones necesarias de la simulación

Se reemplazan respuestas automáticas de la contraparte, códigos OTP aceptados sin comprobación, contraseñas en memoria, avisos de reporte sin persistencia, nombres usados como identificadores y datos semilla por servicios reales. Los controles exclusivos de demostración, como msimdone y audemo, no se publican como capacidades de usuario final.

## Descripción en español del proyecto backend

El backend será el sistema que aplica las reglas del negocio, conserva la información y coordina a los participantes. Cada servicio tendrá un despliegue, contratos y datos de su propiedad. La app accederá mediante una entrada HTTPS común.

### Identidad y acceso

Registrará una cuenta mediante teléfono y contraseña protegida, verificará el control del número, recuperará el acceso y mantendrá sesiones renovables por dispositivo. Resolverá quién puede consultar o cambiar cada recurso. Gestionará consentimientos, cierre de sesión y solicitudes de eliminación propagadas a todos los servicios.

### Directorio y comunidad

Administrará perfiles de prestadores, catálogo de servicios, cobertura y condiciones declaradas. Resolverá consultas por texto, categoría, zona, distancia y disponibilidad calculada. Mantendrá publicaciones de trabajos, experiencias, recomendaciones y guardados. Producirá resúmenes públicos sin datos privados para el inicio, el mapa y la comparación.

### Coordinación de servicios

Mantendrá en el mismo servicio las solicitudes, los interesados y los pedidos, porque aceptar un candidato cambia reglas que deben ser consistentes. Impedirá dos asignaciones activas sobre una misma solicitud. Cada transición conservará actor, fecha, versión y evento. Entregará la dirección precisa únicamente a participantes habilitados por el estado del pedido.

### Mensajería y notificaciones

Persistirá mensajes aceptados, comprobará pertenencia a la conversación y bloqueos, y distribuirá avisos en tiempo real a dispositivos conectados. Permitirá recuperar el historial tras una desconexión. Las notificaciones push informarán sobre nuevos mensajes, interés, pedidos y resolución sin revelar domicilio ni contenido sensible en la pantalla bloqueada.

### Confianza, medios e inteligencia

Analizará textos e imágenes mediante una API de moderación de nube antes de incorporarlos al almacenamiento persistente del producto. Administrará reportes y decisiones humanas auditables. Gestionará las imágenes aprobadas, su acceso y eliminación. La asistencia generativa redactará borradores a petición del usuario sin publicar ni inventar precios, licencias, garantías o experiencia.

### Operación

Registrará métricas y trazas sin secretos ni mensajes privados. Aplicará caché distribuida, límites de consumo, paginación, índices y contratos versionados. Publicará eventos duraderos para propagar cambios y aceptará reintentos sin duplicar pedidos, opiniones o mensajes. Cada servicio dispondrá de pruebas, configuración externa y procedimientos de recuperación.

## Descripción en español del proyecto móvil

La aplicación Flutter para Android reproducirá los recorridos de la maqueta y conectará sus acciones con las APIs. La navegación principal será Inicio, Buscar, Publicar, Mensajes y Cuenta; Guardados se abrirá desde Cuenta.

### Entrada y registro

Mostrará bienvenida, exploración como visitante y guía contextual. El registro distinguirá la cuenta personal del perfil de prestador. Permitirá completar datos obligatorios, omitir pasos opcionales y terminar después horarios, precios y portafolio. El inicio de sesión usará teléfono y contraseña; la recuperación comprobará un código real. Los formularios mostrarán errores específicos sin exponer si una cuenta ajena existe.

### Experiencia del solicitante

Podrá cambiar zona, revisar trabajos y prestadores cercanos, buscar y filtrar, consultar señales de confianza, guardar y comparar dos perfiles, compartir enlaces, abrir una conversación y publicar una necesidad. Tendrá acceso a interesados, preselección, pedidos, estado del servicio y publicación de experiencias.

### Experiencia del prestador

Podrá crear un perfil de persona o negocio, declarar servicios y cobertura, mostrar trabajos y editar información. Consultará solicitudes dentro de sus capacidades y zona, expresará interés y responderá a pedidos. Aceptará con precio opcional, consultará el domicilio autorizado y marcará la resolución. Verá actividad propia sin contabilizarla como ventas verificadas.

### Mensajes y confianza

La bandeja diferenciará modos y mensajes sin leer. El chat permitirá texto, respuestas rápidas y fotos aprobadas; mostrará avisos del pedido, menú de reporte y bloqueo. El usuario tendrá rutas claras a privacidad, términos, eliminación de cuenta y cierre de sesión. La ubicación exacta no aparecerá en tarjetas públicas ni en la comparación.

### Arquitectura Flutter

Organizar por funcionalidades con vistas, modelos de presentación, repositorios y adaptadores de API/SQLite. Usar Riverpod como recomendación de estado y go_router para navegación con enlaces profundos; fijar versiones al comenzar. El repositorio combina origen remoto y caché. Los casos de uso contienen reglas de sincronización, no los widgets. Esta separación sigue la guía oficial de arquitectura Flutter [F01].

### Accesibilidad y estados

Preservar verde #17695D, marfil #F6F4EE y acento #C87825, con contraste revisado. Incluir etiquetas semánticas, escala de texto, áreas táctiles de al menos 48 dp y mensajes que no dependan solo del color. Cada pantalla tendrá estados de carga, vacío, error, sin conexión, permiso denegado y sesión revocada.

## Arquitectura propuesta de microservicios

Se proponen seis servicios de negocio, S07 de notificaciones con API y worker, una puerta de entrada y S08 de relaciones como extensión para consultas de grafo. Separar responsabilidades permite evolucionar chat, búsqueda y pedidos de forma independiente. El costo de esta decisión es mantener contratos, consistencia eventual y operación distribuida.

### S01 Identidad

Cuentas, verificación de teléfono, sesiones, consentimientos, preferencias de cuenta y eliminación. Base nl_identity. Emite JWT y gobierna revocación. No almacena perfiles comerciales, mensajes ni pedidos.

### S02 Directorio y descubrimiento

Perfiles, servicios, categorías, condiciones, cobertura, búsquedas y proyecciones públicas. Base nl_directory. La búsqueda nace dentro de este servicio; se separaría solo con evidencia de carga. Los datos derivados de comunidad y pedidos llegan mediante eventos versionados.

### S03 Comunidad

Trabajos, experiencias, calificaciones, recomendaciones, guardados y métricas de interacción. Base nl_community. Separa experiencias declaradas de opiniones vinculadas a pedidos resueltos; calcula agregados sin convertirlos en certificación del servicio.

### S04 Solicitudes y pedidos

Solicitudes, interesados, preselección, asignaciones, pedidos y logística privada. Base nl_orders. Conserva juntas las operaciones que requieren atomicidad, como aceptar un pedido y asignar la solicitud. Publica cambios para chat y notificaciones.

### S05 Mensajería

Conversaciones, membresías, mensajes, lectura y bloqueos. Base nl_messaging. REST para escritura e historial; WebSocket JSON para avisos, lectura y escritura en curso. Redis Pub/Sub distribuye avisos entre réplicas. La recuperación fiable siempre proviene de la base persistente.

### S06 Confianza y contenido

Moderación previa, reportes, revisión humana, metadatos de medios y asistencia generativa. Base nl_trust; fotos aprobadas en Blob Storage. Es un servicio con módulos internos diferenciados. No tendrá autoridad para modificar directamente las bases de los demás servicios.

### S07 Notificaciones y entrada

S07 consume eventos, conserva dispositivos, bandeja y entregas en nl_notifications y envía push mediante FCM. La entrada ASP.NET Core/YARP enruta y agrega respuestas de pantalla sin ser dueña del negocio. Se recomienda .NET 10 LTS para homogeneizar desarrollo y operación [F02]. No es necesario asignar un lenguaje distinto a cada API.

### S08 Relaciones y descubrimiento con grafos

Neo4j conserva una proyección reconstruible de perfiles, categorías, trabajos y experiencias públicas. S02/S03 mantienen la autoridad de escritura. El consumidor aplica eventos idempotentes; una API de lectura opcional expone consultas acotadas mediante GraphQL. Las menciones actuales continúan funcionando mediante REST y MongoDB. No se usa el grafo para autorizar acceso privado.

## Tipos de API y comunicación

El tipo de API se elige según la interacción. Muchas funciones comparten REST de forma adecuada; usar protocolos distintos por cada pantalla añadiría trabajo sin mejorar el producto.

### REST sobre HTTPS

Usar JSON y rutas /api/v1 para registro, perfiles, búsqueda, publicaciones, solicitudes, pedidos, mensajes persistentes, guardados, reportes y cuenta. Una operación modifica un agregado de un servicio. Describir esquemas, ejemplos, autorización y errores en OpenAPI. Paginación por cursor estable y límite máximo de 50 elementos.

### WebSocket para avisos en vivo

Ruta /ws/v1/chat. Eventos message.available, conversation.read, typing y order.updated. El cliente obtiene un ticket de un solo uso por REST autenticado, válido 30 segundos, y lo consume durante el handshake. No se pone el JWT duradero en URLs o logs. Todo evento incluye id, tipo, versión, conversación, secuencia y fecha UTC.

### Eventos asíncronos

Usar outbox transaccional por servicio y Azure Queue Storage con una cola por consumidor. Un distribuidor copia cada evento a sus suscriptores y registra el estado de entrega por destino; una única cola compartida por consumidores distintos no hace difusión. Registrar eventId, aggregateId, aggregateVersion, correlationId y occurredAt. El consumidor deduplica y conserva inbox.

### Integraciones externas

Los adaptadores backend consumen APIs HTTPS de SMS, moderación, geocodificación, generación y FCM. El cliente consume mapas mediante una integración con licencia y credenciales restringidas. Imágenes públicas aprobadas se leen por CDN; imágenes privadas del chat requieren autorización y enlaces de corta duración.

### Protocolos opcionales y límites

GraphQL se diseña como interfaz opcional de lectura de S08, mediante /graphql/social/v1. REST sigue cubriendo las acciones existentes. El motor de grafos no obliga a usar GraphQL; se elige la interfaz por las necesidades del cliente [F20, F21]. No se propone gRPC sin una necesidad medida de comunicación interna de alta frecuencia. SSE sería válido para una salida generativa progresiva futura; la primera versión devuelve un borrador corto mediante REST.

### Errores y reintentos

Usar 400 para formato inválido, 401 para credenciales no válidas, 403 para acceso prohibido, 404 cuando no debe revelarse existencia, 409 para conflicto de versión o transición, 413 para tamaño y 422 para contenido rechazado. Devolver 429 con Retry-After y 503 cuando una dependencia impide operar. Problem Details contendrá code, detail y traceId sin datos privados.

## Persistencia por módulo y modelo NoSQL

La combinación propuesta es MongoDB para documentos autoritativos, Neo4j en S08 para una proyección de relaciones, Redis para datos transitorios y coordinación, y Azure Blob Storage para archivos aprobados. S08 se habilita tras comprobar sus consultas y costo; las funciones actuales mantienen una ruta REST operativa sin él. SQLite se reserva al teléfono porque el punto 16 lo contempla expresamente; las bases del backend siguen siendo NoSQL.

### MongoDB por propietario

Usar una base lógica y una credencial por servicio. Un clúster puede alojarlas al iniciar para contener costo, con el riesgo explícito de compartir capacidad y disponibilidad. Ningún servicio hace joins ni escrituras sobre la base de otro. Una referencia userId, providerId o orderId entre servicios es un identificador externo, no una llave foránea con integridad automática.

### Diseño de documentos

Cada entidad usa _id UUID, schemaVersion, createdAt, updatedAt y version para concurrencia. Embebidos pequeños: horarios semanales, condiciones de atención y precio del pedido. Colecciones separadas para mensajes, interesados, eventos y guardados, porque crecen sin límite. Dinero como importe entero en centavos y currency MXN; fechas UTC y zona horaria IANA para horarios.

### Directorio geográfico

Índice 2dsphere sobre la ubicación privada de cobertura y una proyección pública aproximada [F03]. Para servicio a domicilio se prefiltran candidatos por radio máximo permitido y se verifica distancia menor o igual al radio propio de cada prestador. Para local se usa distancia al local público autorizado; ambas modalidades se unen sin duplicados. Buscar fuera de cobertura requiere acción explícita y etiqueta de disponibilidad.

### Redis con responsabilidad clara

Caché de consultas, sesiones revocadas, contadores de rate limit, tickets WebSocket y canales efímeros entre réplicas. Usar prefijos por entorno/servicio y políticas diferenciadas; los datos de seguridad no deben poder expulsarse como una caché común. MongoDB conserva sesiones y revocaciones duraderas. Redis nunca será el único historial de mensajes o pedidos.

### Grafo para relaciones; otros motores según evidencia

Neo4j es la opción propuesta para modelar relaciones y recorridos de dos saltos en S08 [F20]. No sustituye a MongoDB en cuentas, pedidos, chat ni publicaciones. Una mención directa también puede resolverse con referencias documentales; MongoDB ofrece $graphLookup para ciertos recorridos [F23]. Cosmos DB for Apache Gremlin es una alternativa de grafo administrado en Azure [F22], no un segundo grafo simultáneo. Comparar costo, partición, operación y consultas antes de elegir. No se justifica añadir Cassandra o un buscador independiente con los datos actuales.

### Archivos y búsqueda

Blob guarda bytes; MongoDB guarda autor, hash, tamaño, MIME, estado de moderación, propósito y ruta. No guardar imágenes base64 en los documentos. La búsqueda inicial usa tokens normalizados y prefijos indexados con filtros; medir relevancia. Adoptar MongoDB Search cuando la capacidad y el plan se verifiquen, sin prometer autocompletado gratuito ilimitado.

## Consistencia, privacidad y flujos críticos

Las decisiones sobre pedidos y permisos requieren consistencia inmediata dentro de su propietario. Feed, métricas y notificaciones admiten propagación eventual.

### Pedido y concurrencia

Tanto desde perfil como desde interesados, el pedido nace pend. El comentario antiguo que anuncia match inmediato queda superado por ACT.agok, que crea pend. Solo el prestador destinatario puede aceptar o rechazar. La aceptación actualiza pedido y solicitud mediante una transacción local en S04. Un índice parcial único impide más de un pedido activo por solicitud; otro impide duplicar un pedido activo entre el mismo cliente y prestador, según la regla visible de la maqueta.

### Transiciones autorizadas

pend pasa a ok por aceptación o a cancel por rechazo/cancelación. ok pasa a done por el prestador o a cancel por cualquiera de las partes. done y cancel son terminales. Toda escritura usa version y comparación condicional; dos aceptaciones simultáneas generan un ganador y un 409. El precio es opcional y se fija al aceptar. No se simulan respuestas de la contraparte.

### Domicilio y teléfono

Antes de aceptar, el prestador recibe zona aproximada. En ok accede al domicilio; en done se propone acceso durante siete días para cierre operativo y después solo zona. En cancel se retira de inmediato el acceso preciso. El teléfono requiere además consentimiento vigente: contactPreference=both para el cliente y showPhone=true para el prestador. Solo chat nunca comparte el número. Para un pedido directo se propone chat por defecto y consentimiento explícito separado. Es un endurecimiento explícito del HTML, cuya condición status != pend podría revelar ubicación de un pedido rechazado. Los plazos de conservación deben acordarse y reflejarse en privacidad.

### Experiencias y reputación

Se permite publicar una experiencia declarada desde Publicar aunque no exista pedido, porque la maqueta lo ofrece. Solo se muestra vínculo con un pedido registrado si S04 confirma que pertenece al solicitante y está done. Una calificación por pedido. El compositor exige un prestador seleccionado, estrellas enteras de 1 a 5 y texto de 10 a 280 caracteres. La mención se guarda como providerId junto con la experiencia; @nombre es solo presentación. Las recomendaciones se hacen idempotentes por usuario y objetivo.

### Mensajes y eventos

El cliente inicia la conversación; el prestador puede responder o iniciar tras asignación. Las claves utilizan identificadores de cuenta, no nombres visibles. Un mensaje queda confirmado solo después de moderación y persistencia. La reconexión solicita mensajes posteriores al último cursor; Redis Pub/Sub y push no garantizan historial. Los avisos de sistema derivados del pedido se deduplican por eventId.

### Fallas y recuperación

La caída del moderador impide publicar contenido nuevo y permite seguir consultando. La caída del chat no impide navegar perfiles. Reintentar con espera exponencial y variación aleatoria. Un evento no procesable pasa a una cola de errores propia tras cinco intentos propuestos. La eliminación de cuenta espera confirmaciones de todos los servicios y conserva una bitácora mínima sin el contenido eliminado.

## 1. Descarga de la aplicación desde Google Play

El inicio de la evaluación debe hacerse con la aplicación descargada de Google Play. Instalar un APK por cable o compartir un AAB no demuestra este punto.

### Preparación

Crear o verificar Play Console, titular, identidad, ficha, identificador definitivo de aplicación y clave de carga. Guardar la clave fuera del repositorio, con respaldo y acceso controlado. Elaborar ícono, capturas, descripción, clasificación de contenido, declaración de seguridad de datos y enlaces públicos requeridos.

### Pruebas y publicación

Si aplica la política para nuevas cuentas personales, se requieren al menos 12 testers inscritos durante 14 días consecutivos antes de solicitar acceso a producción [F04]. Verificar el requisito en la cuenta real. Proponer inicio de prueba cerrada el 5 de noviembre, fin mínimo el 19 y margen para revisión; no asumir aprobación automática.

### Canal de evaluación

La meta es producción. Si se propone un canal cerrado accesible al docente, confirmar que sea aceptado para la evaluación. Registrar correo autorizado, enlace de participación e instalación desde la tienda. No confundir una distribución de Firebase con Google Play.

### Aceptación

Desde un dispositivo de prueba sin instalación previa, abrir el enlace, descargar, iniciar y completar búsqueda, chat y pedido entre dos cuentas. Registrar versionName, versionCode, fecha, canal y video. Estado actual: plan documentado, cuenta y publicación pendientes.

## 2. Evaluación interactiva y evaluación con prompts

El proyecto debe poder explicarse y comprobarse desde su repositorio. La documentación facilita la evaluación, pero no reemplaza las pruebas de funcionamiento.

### Trazabilidad

Mantener REQ-01 a REQ-19, RF por recorrido, spec, endpoint, servicio, prueba y evidencia de ejecución. La matriz del libro es la base de diseño; añadir después commit, archivo real y resultado. Un requisito no pasa a Implementado solo porque figure en una spec.

### Preguntas de comprobación

Preparar prompts como: “Ubica el cierre de sesión y demuestra que un JWT previo falla en ambas réplicas”; “Explica quién puede consultar el domicilio antes de aceptar”; “Identifica el índice que evita doble asignación”; “Muestra cómo se impide guardar una foto rechazada”; “Relaciona cada función de la maqueta con su prueba”.

### Expediente reproducible

Cada versión debe incluir arquitectura, contratos OpenAPI, eventos, inventario, matriz de datos, decisiones, instrucciones de arranque y evidencia. Las respuestas deben señalar archivos y pruebas existentes, con sus límites. No presentar mocks, capturas antiguas o respuestas generadas como evidencia de ejecución.

### Aceptación

Una persona ajena al cambio puede localizar el recorrido, ejecutar sus pruebas y explicar datos, permisos y errores sin depender de una conversación privada con el autor.

## 3. Componentes del proyecto

El sistema integra cinco capas obligatorias. Cada una tendrá su inventario, versión, configuración y evidencia de operación.

### Nube

Azure como propuesta: Container Apps, ingress, Blob Storage, Front Door, Queue Storage, Key Vault, observabilidad, moderación y modelo generativo. MongoDB puede residir en un proveedor externo, posibilidad admitida por el requisito 13. Firebase se usa como proveedor de push; la lógica propia se aloja en Azure.

### Datos

Bases NoSQL por servicio, credenciales separadas, validación de esquemas e índices. Redis distribuido mantiene funciones transitorias. SQLite sirve al almacenamiento local móvil. Los archivos aprobados se guardan en objetos y se relacionan por mediaId.

### Backend

Seis servicios de negocio, worker de notificaciones y entrada común. Cada artefacto se construye y despliega por separado. Las integraciones externas se encapsulan en adaptadores con timeout, límites y telemetría.

### Móvil y landing

Flutter Android reproduce la maqueta. La landing conserva identidad visual, explica la solución, enlaza Google Play y publica privacidad, términos y solicitud de eliminación. Su contenido comercial debe coincidir con las capacidades de la versión instalada.

### Aceptación

Un inventario enlaza las cinco capas: URL pública, servicio propietario, almacén, versión y responsable. El libro adjunto detalla los componentes propuestos; los identificadores reales de nube se incorporarán al implementarlos.

## 4. Correspondencia con la maqueta aprobada

El HTML aprobado es la referencia funcional, incluso donde los README o la propuesta original quedaron desactualizados.

### Inventario mínimo

Cubrir bienvenida y guía, login y recuperación, ambos registros, inicio de solicitante y prestador, búsqueda y mapa, filtros y sugerencias, perfil público y propio, comparación, las tres clases de publicación, solicitudes propias, interesados, pedido, bandeja, chat, guardados, cuenta, notificaciones, reportes, privacidad y eliminación.

### Detalles que deben conservarse

Comparación de dos perfiles; completar registro básico y luego ampliar; atención en local/a domicilio/ambas; urgencias, visita gratis y precios; ampliar búsqueda sin afirmar cobertura; ordenar interesados; preselección explícita queda como ampliación opcional sin control visible; indicar precio opcional al aceptar; experiencia sin pedido diferenciada; cambio de modo sobre una sola cuenta; invitación al registro cuando el visitante intenta una acción protegida.

### Referencia comprobable

Usar funciones V.home, V.search, V.profile, V.compare, V.publish, V.myprofile, V.saved, V.account, V.ints, V.match, V.inbox y V.chat, junto con ACT y sus hojas inferiores. Las fichas del libro referencian acciones concretas. Un control de zoom, cambio de pestaña o apertura de hoja es estado local y no necesita un endpoint exclusivo.

### Aceptación

Comparar en dispositivos los recorridos del HTML y Flutter, además de revisar estados vacíos y de error. No copiar mecanismos inseguros de la demo: se conserva la intención de uso y se reemplaza su simulación por autorización, validación y persistencia reales.

## 5. Spec Driven Development y DevSecOps

Cada incremento nace de una especificación verificable. La seguridad y la operación se incorporan desde el diseño, tanto en backend como en Flutter.

### Secuencia SDD

Constitución del proyecto; spec en español con actores y reglas; plan técnico con contratos y datos; tareas pequeñas; implementación mediante agente; pruebas; revisión; despliegue y evidencia. La spec describe qué y por qué. El plan concentra tecnologías, estructura y decisiones. Una modificación de alcance actualiza primero su spec.

### Estructura prevista

docs/requirements, docs/architecture, docs/adr, specs/NNN-funcion, contracts/openapi, contracts/events, services, apps/mobile, apps/landing, infra y evidence. Esta es una propuesta para el futuro repositorio; esta entrega no crea una implementación vacía ni afirma que esos componentes estén listos.

### Controles DevSecOps

Análisis estático, dependencias vulnerables, detección de secretos, análisis de contenedor e IaC, pruebas unitarias e integración, pruebas de autorización y escaneo dinámico en evaluación. Publicar inventario de componentes y conservar hashes de los artefactos. Las excepciones documentan riesgo, responsable, vencimiento y mitigación.

### Definición de terminado

Spec y contratos vigentes; revisión humana; pruebas críticas aprobadas; ausencia de secretos; recorrido Flutter validado; migración compatible y plan de reversión; métricas sin datos sensibles; evidencia vinculada a la versión. Elegir herramientas que funcionen con la visibilidad y plan reales de GitHub.

## 6. Desarrollo mediante agentes de IA

El punto 6 exige agentes para backend y móvil y permite elegir herramientas. OpenCode con WARP es una sugerencia del docente, no una restricción de framework.

### Contexto del agente

Entregar constitución, spec, contratos, esquema, reglas de privacidad, archivos permitidos y criterios de aceptación. El agente debe identificar los requisitos que atiende, implementar cambios acotados y reportar las comprobaciones ejecutadas con sus resultados.

### Flujo de colaboración

El equipo define y revisa el producto; el agente desarrolla y propone cambios; una persona revisa código, permisos y pruebas antes de integrarlo. Ningún integrante debe depender de que el agente recuerde conversaciones previas. Los acuerdos duraderos quedan en el repositorio.

### Registro de evidencia

Conservar por tarea fecha, herramienta/modelo declarado, instrucciones sin secretos, archivos afectados, commit, comprobaciones y decisiones humanas. No registrar tokens, datos reales de usuarios ni imágenes privadas en prompts. Usar datos sintéticos para pruebas y ejemplos.

### Aceptación

Seleccionar un cambio de backend y uno de móvil y reconstruir su recorrido desde la spec hasta el despliegue. La evidencia debe demostrar intervención real del agente y revisión del equipo, sin atribuirle pruebas que no se ejecutaron.

## 7. Pruebas unitarias, de seguridad e integración

Se propone una estrategia basada en reglas de negocio y riesgos de integración. Las pruebas de esta sección son el plan para la aplicación futura.

### Unitarias backend

Probar cobertura según modalidad y radio, horarios con zona horaria, transiciones de pedido, permiso para domicilio, deduplicación, estrellas válidas, conversión monetaria y caducidad. Casos límite: distancia igual al radio, solicitud cerrada, aceptación duplicada y cancelación concurrente.

### Integración backend

Usar MongoDB configurado como replica set para probar transacciones, Redis real de pruebas y emulador/adaptador de colas. Verificar outbox/inbox, pérdida de conexión, eventos duplicados, esquema e índices. Ejecutar además ensayos contra moderación, SMS y push reales antes de afirmar integración externa.

### Seguridad

Dos usuarios A y B prueban acceso cruzado a pedidos, conversaciones, mensajes, medios y eliminación. Cambiar ids y mode no debe saltar permisos. Probar JWT vencido, sesión revocada, reutilización de refresh, subida MIME falsa, sobrecarga, texto rechazado, ticket WebSocket repetido y autorización durante reconexión.

### Flutter

Pruebas unitarias de modelos de presentación y sincronización; widget tests de validación, accesibilidad y permisos; integration_test para registro, búsqueda, solicitud, interés, pedido, chat, experiencia, logout y borrado. Dispositivos con distintos tamaños, texto ampliado y conexión intermitente.

### Carga y recuperación

Meta inicial propuesta: 100 usuarios concurrentes, p95 menor a 800 ms en lecturas calientes y error menor a 1% bajo carga controlada. Medir publicaciones con moderación por separado. Registrar dataset, región, recursos y límites reales. Ensayar caída de una réplica y recuperación sin pérdida de mensajes confirmados.

### Aceptación

Entregar reportes por versión con aprobados, fallidos y no ejecutados. La cobertura crítica de permisos y estados es obligatoria; una cifra de cobertura de líneas no sustituye estas comprobaciones.

## 8. Integración y despliegue continuos

Los pipelines backend y móvil serán independientes, pero compartirán la versión de contratos y el expediente de liberación.

### CI backend

Restaurar dependencias bloqueadas, compilar, analizar, ejecutar pruebas, verificar OpenAPI y eventos, escanear secretos/dependencias/contenedores y producir imágenes identificadas por digest. Cambios incompatibles de contrato bloquean integración hasta definir migración.

### CD backend e infraestructura

Plan de Terraform sobre entorno concreto; revisión del plan; creación/actualización; despliegue de imágenes por digest; health checks; pruebas de humo; evidencia y reversión a revisión anterior. Autenticación de CI a Azure mediante identidad federada OIDC. Evitar claves de nube duraderas dentro de GitHub.

### CI/CD móvil

Análisis de Dart, pruebas, validación de contratos, compilación AAB release, firma con secreto protegido y publicación al canal de Play elegido. versionCode debe crecer siempre. Verificar manualmente las tareas iniciales de Play Console y que la API de publicación tenga permisos antes de prometer el primer despliegue automático.

### Separación de permisos

Pull requests de origen no confiable no reciben secretos de despliegue. Proteger cambios en workflows, IaC y contratos. Si el plan de GitHub no ofrece gates deseados, documentar el mecanismo disponible de revisión y ejecución con permisos mínimos.

### Aceptación

Una versión trazable produce reporte de CI, imágenes, AAB, manifiesto, recursos y prueba posterior. El pipeline de eliminación es independiente del de publicación y solicita entorno explícito; no destruye datos persistentes por una limpieza automática.

## 9. Caché en base de datos, backend y frontend

El caché mejora consultas repetidas, pero no puede decidir permisos ni ocultar cambios críticos. Se documentan TTL iniciales propuestos y mecanismos de invalidación.

### Nivel base de datos

Colección read_cache dentro de nl_directory para consultas derivadas públicas: _id igual a hash de filtros normalizados y versión del catálogo, payload resumido, generatedAt y expiresAt. Índice TTL sobre expiresAt. El lector comprueba expiración porque el borrado TTL no es inmediato. Las proyecciones y el caché interno del motor ayudan, pero no se presentan como un caché de aplicación por sí solos.

### Nivel backend distribuido

Patrón cache-aside con Redis: catálogo 24 horas; perfil público 60 segundos; búsqueda pública 30 segundos; cuenta y permisos sin caché público. Cambios generan invalidación por versión y clave. Variar claves por zona, modalidad, filtros, idioma y versión. Aplicar exclusión temporal para evitar avalanchas de recomputación.

### Nivel Flutter

SQLite conserva catálogo, resúmenes públicos, guardados y borradores por usuario; caché de imágenes por hash. Mostrar fecha de actualización y origen local. Purgar datos privados en logout y eliminación. La respuesta autoritativa del servidor sustituye el dato local al reconectar.

### Privacidad y consistencia

No almacenar domicilio en caché compartido ni incluir datos privados en respuestas cacheables del gateway. No cachear una autorización positiva de forma que sobreviva al cierre de sesión. Los estados de pedido se revalidan al ejecutar acciones; la UI no decide una transición con datos antiguos.

### Aceptación

Demostrar hit/miss, menos lecturas al motor, expiración y actualización visible después de editar perfil. Probar dos usuarios y dos réplicas para descartar contaminación de caché. Redis caído permite lectura pública desde MongoDB con límites; operaciones de seguridad recurren a fuente durable o rechazan de forma segura.

## 10. Logout en backend y móvil

Cerrar sesión revoca la capacidad de usarla en el servidor y elimina el acceso local. Borrar únicamente el token del teléfono no satisface el requisito.

### Modelo de sesión

JWT de acceso de corta duración, propuesta cinco minutos, con sub, sid, jti, aud, iss, exp y roles mínimos. Refresh token opaco aleatorio, almacenado como hash en MongoDB, rotado en cada uso. Conservar familia por dispositivo y estado de revocación. La sesión se renueva automáticamente durante uso válido; no existe JWT eterno.

### Operación de logout

POST /auth/logout revoca la sesión durable, registra revocación en Redis, invalida familia de refresh, desvincula dispositivo push y cierra sus conexiones WebSocket. Cada petición protegida valida la sesión, además de firma y caducidad. Todas las réplicas consultan el mismo estado distribuido.

### Cliente y fallas de red

Flutter cancela solicitudes, destruye credenciales del almacenamiento seguro, borra SQLite privado, limpia imágenes privadas y vuelve a visitante. Si el dispositivo está offline, el cierre local es inmediato y se indica que la revocación remota no pudo confirmarse; usar una credencial limitada de revocación pendiente o permitir cerrar dispositivos desde una nueva sesión. No afirmar cierre remoto sin respuesta del servidor.

### Sesión siempre viva

Mantener experiencia sin login repetido mediante renovación silenciosa, almacenamiento seguro y recuperación al reabrir. La renovación puede fallar por logout, eliminación, revocación administrativa, recuperación de contraseña o sospecha de robo. Esas excepciones de seguridad se documentan frente a la redacción literal del requisito.

### Aceptación

Con la misma sesión, llamar a réplicas A y B antes y después del logout. Ambas deben rechazarla, incluidos mensajes por conexiones ya abiertas. Probar reutilización de refresh anterior, cierre en un dispositivo y aislamiento de otras sesiones según la opción elegida.

## 11. Matriz de numeración y versionamiento

La matriz se define antes del desarrollo y cada despliegue produce un manifiesto inmutable con las versiones que realmente se publicaron.

### Componentes

Servicios y landing: SemVer MAJOR.MINOR.PATCH. Flutter: versionName SemVer y versionCode entero global creciente. API pública: /api/v1; cambios incompatibles requieren nueva versión y convivencia temporal. OpenAPI: info.version por revisión de contrato. Eventos: tipo y schemaVersion. Datos: schemaVersion por documento y migraciones numeradas.

### Ejemplo de liberación

Ejemplo ilustrativo, no despliegue real: app 0.1.0+1, identidad 0.1.0, directorio 0.1.0, pedidos 0.1.0, contrato v1, evento order.accepted versión 1, esquema orders 1 e infraestructura 0.1.0. El identificador visual de la maqueta V1.00.002 no se reutiliza como versión de una app todavía no construida.

### Reglas de cambio

PATCH corrige sin romper compatibilidad; MINOR añade capacidades compatibles; MAJOR cambia contratos incompatibles. Una columna opcional nueva se introduce primero como compatible. No reutilizar etiquetas ni versionCode. Las imágenes se referencian por digest y commit, aunque tengan una etiqueta legible.

### Manifiesto

releaseId, fecha UTC, commit, specIds, versiones de servicios, contrato, eventos, migraciones, imagen/digest, AAB/hash, versionCode, Terraform/provider lock, entorno, ejecutor, resultados y procedimiento de reversión. El libro contiene la matriz inicial y su regla de incremento.

### Aceptación

Reconstruir exactamente una liberación desde el manifiesto y mostrar qué app puede comunicarse con cada contrato. La reversión del backend respeta migraciones y versiones móviles ya distribuidas.

## 12. Uso opcional de MCP

El texto del requisito permite MCP cuando un proveedor lo ofrece. No obliga a instalar conectores ni a otorgarles administración completa.

### Usos útiles

Consulta de documentación oficial, lectura de issues y pull requests, inventario de recursos y análisis de esquemas de prueba. Evaluar servidores para GitHub, Azure o MongoDB solo después de comprobar proveedor, capacidades y compatibilidad con el agente elegido.

### Configuración

Registrar nombre, origen, versión, permisos, entorno y finalidad. Preferir lectura en exploración y credenciales distintas para entornos. No incluir secretos en archivos versionados. Las operaciones con costo, despliegue o datos sensibles deben seguir los controles del proyecto.

### Alternativa

Si no existe conector adecuado, usar CLI o SDK documentado. La ausencia de MCP no impide el cumplimiento del producto. Los resultados obtenidos por un conector requieren la misma validación que un comando manual.

### Aceptación

Si se adopta, mostrar una consulta útil y su límite de permisos. Estado inicial: propuesta de uso, ningún servidor externo configurado por esta entrega.

## 13. Nube, balanceo, HTTPS e infraestructura

Se recomienda Azure por la integración entre contenedores, almacenamiento, observabilidad y moderación. Es una propuesta pendiente de verificar contra la cuenta, región, presupuesto y servicios disponibles.

### Topología

Container Apps publica la entrada HTTPS y balancea sus réplicas; servicios de negocio usan ingress interno. En evaluación, entrada y APIs síncronas operan con mínimo dos réplicas cada una. El worker escala por cola. Todas las funciones API propias permanecen en Azure. Un clúster MongoDB externo debe permitir conectividad restringida y cifrada.

### Seguridad de infraestructura

TLS en accesos públicos, identidad administrada cuando el recurso lo permita, secretos en Key Vault, red privada para Redis y acceso mínimo a bases. TLS sustituye protocolos SSL obsoletos. No exponer MongoDB ni Redis directamente al móvil. Verificar también las credenciales entre servicios; una red interna no sustituye autenticación.

### Terraform

Separar entorno, configuración persistente y recursos efímeros. Versionar módulos y proveedores. Proteger el estado remoto cifrado y con bloqueo, pues puede contener información sensible. Plan debe mostrar exactamente región, tamaños, réplicas, CDN, Redis y almacenamiento antes de aplicar.

### Ciclo de vida

Crear: validar configuración, plan, revisión, apply, migraciones, despliegue y smoke test. Eliminar: exportar datos de prueba, comprobar entorno, retirar aplicaciones y recursos efímeros, verificar recursos restantes y conservar acta. Producción conserva respaldos y datos mediante protecciones específicas.

### Balanceo comprobable

Añadir instanceId en telemetría interna, no datos sensibles en respuestas públicas. Ejecutar tráfico concurrente y demostrar atención por dos réplicas; detener una y comprobar continuidad. Contar servicios distintos no equivale a contar réplicas de una misma API.

## 14. Diseño y administración de bases NoSQL

Las bases centrales serán documentales y de clave-valor. La elección responde a las consultas, consistencia y tamaño esperado del piloto, sin imponer un motor distinto por pantalla.

### Asignación

nl_identity conserva accounts, sessions y otp_challenges. nl_directory conserva providers, categories y read_cache. nl_community conserva posts, reviews, reactions, saved y métricas agregadas. nl_orders conserva requests, interests y orders. nl_messaging conserva conversations, messages y blocks. nl_trust conserva media, reports y decisiones. nl_notifications conserva devices, notifications y deliveries.

### Llaves e índices

UUID como identificador primario. Índices únicos sobre teléfono normalizado, perfil por usuario, interés por solicitud/prestador, opinión por pedido y mensaje por conversación/clientMessageId. Índices de consulta incluyen estado y fecha más _id como desempate. GeoJSON usa coordenadas [longitud, latitud]. El libro desarrolla el documento y los índices de cada entidad.

### Transacciones

Configurar MongoDB con soporte transaccional y probar el plan elegido. Cambios críticos y su outbox se confirman juntos en la base propietaria. No simular atomicidad entre servicios. Referencias externas se validan mediante API o proyección con versión y se reconcilian por eventos.

### Scripts entregables

Preparar scripts idempotentes de creación, validadores, índices, roles y semillas sintéticas, migraciones ordenadas y procedimiento de respaldo/restauración. El script de Redis describe namespaces, ACL, TTL y políticas; no exporta sesiones reales. Las reglas de objetos describen acceso, ciclo de vida y eliminación.

### Aceptación

Restaurar un entorno vacío, ejecutar scripts dos veces sin duplicados, comprobar índices con planes de consulta y recuperar una copia de seguridad. La disponibilidad de respaldo administrado debe validarse en el plan contratado; no se da por incluida en una capa gratuita.

### Grafo NoSQL

S08 incorpora Neo4j como proyección NoSQL. Entregar restricciones de unicidad, índices, contratos de eventos y procedimiento de reconstrucción. SQLite permanece únicamente en móvil.

## 15. Backend: rendimiento, seguridad y operación

Este punto concentra obligaciones de escalabilidad, alojamiento, Redis, JWT, CDN, observabilidad, patrones, rendimiento y administración de despliegues.

### Escalabilidad y autenticación

APIs sin sesión en memoria local, mínimo dos réplicas en evaluación, límites de concurrencia y conexiones por servicio. JWT validado por emisor, audiencia, firma, tiempo y sesión vigente. Redis compartido coordina revocaciones, rate limit y caché. Si Redis de seguridad falla, recurrir a estado durable o negar operaciones protegidas; no permitir por omisión.

### API performance

Cache-aside; límites distribuidos por IP y usuario; middleware de autenticación, autorización, validación, trazas y errores; cursor y máximo 50; índices derivados de consulta; DTO que excluye datos privados; System.Text.Json; compresión gzip/Brotli para JSON cuando convenga. No comprimir nuevamente JPEG ni registrar payloads de chat. Evitar N+1 con lotes y proyecciones.

### Límites iniciales propuestos

Lectura pública: 60 solicitudes/minuto/IP; escrituras: 30/minuto/cuenta; login: 5 intentos/15 minutos por combinación de cuenta e IP, con prevención de bloqueo malicioso; OTP: 3 envíos/15 minutos; IA: 10 peticiones/día/cuenta; imagen: máximo 3 MB. Ajustar después de pruebas y límites del proveedor.

### Patrones

Gateway/BFF para composición; repositorio por agregado; Adapter para nube y SMS; outbox/inbox para eventos; saga para borrado de cuenta; concurrencia optimista para pedidos; circuit breaker y timeout por dependencia; bulkhead para aislar moderación y chat. Estos patrones resuelven fallas específicas y no exigen introducir frameworks adicionales.

### CDN y observabilidad

Azure Blob más Front Door para imágenes públicas aprobadas. Los medios privados se entregan con autorización y sin caché compartida abierta. OpenTelemetry hacia Application Insights/Log Analytics registra latencia, errores, colas, moderación, reconexiones, caché y costo por operación. CorrelationId une la petición con sus eventos.

### Aceptación

Prueba de carga y caída de réplica, evidencia de CDN, trazas, límites distribuidos y comandos de creación/despliegue/eliminación. Costo cero permanece condicionado: véase el análisis económico siguiente. Un crédito promocional consumido no es costo operativo cero.

### Costo incremental del grafo

Habilitar S08 con dos réplicas HTTP lleva el ejemplo de 16 a 18 réplicas: 16,200 vCPU-segundos y 32,400 GiB-segundos por hora a 0.25 vCPU/0.5 GiB cada una. Añadir motor Neo4j, almacenamiento, respaldos, consumidor y tráfico. Este cálculo no demuestra gratuidad ni alta disponibilidad de la base.

## Viabilidad del requisito de costo cero

La arquitectura propuesta cumple técnicamente con microservicios, dos réplicas y CDN, pero no puede declararse de costo cero sin una cotización y una interpretación acordada del requisito.

### Hechos verificados

Container Apps ofrece una cuota mensual gratuita compartida por suscripción y factura consumo adicional [F05]. Front Door Standard tiene una tarifa base además del uso [F06]. Azure Managed Redis es un recurso administrado que debe cotizarse [F07]. SMS, almacenamiento, logs y generación también requieren verificar precio, cuotas y disponibilidad. No se acreditó una cuenta con beneficios activos.

### Dimensionamiento ilustrativo

Seis APIs de negocio, la API de notificaciones y una entrada, dos réplicas por componente, equivalen a 16 réplicas antes del worker y Redis. A 0.25 vCPU y 0.5 GiB por réplica durante una hora son 14,400 vCPU-segundos y 28,800 GiB-segundos asignados. Es una medida de capacidad, no una factura: la modalidad activa/idle, región, solicitudes y otros recursos cambian el costo.

### Escenarios

Desarrollo local: sin consumo de nube para pruebas con dobles, pero no acredita APIs alojadas, moderación real ni Google Play. Evaluación limitada: dos réplicas y recursos reales durante una ventana controlada, con consumo medido y posible uso de créditos. Operación continua: requiere presupuesto de cómputo, Redis, CDN, datos y servicios de IA/SMS.

### Decisión pendiente

Confirmar con el docente si “costo cero” admite créditos y una ventana de evaluación, o significa factura estrictamente igual a cero. Si exige gratuidad continua sin créditos, la selección Azure aquí propuesta no se aprueba para despliegue y debe rehacerse la comparación de proveedores con la cuenta real. No eliminar Redis, CDN o la segunda réplica para aparentar cumplimiento.

### Controles de consumo

Fijar duración, máximo de réplicas, límites de IA/SMS, retención de logs y limpieza de recursos efímeros. Las alertas presupuestales notifican, no detienen automáticamente cargos. Programar apagado y verificar recursos residuales. Las cuotas de Play Console y dominios se registran por separado.

### Evidencia requerida

Cotización guardada con fecha, región, plan, unidades, horas, consumo, moneda e impuestos aplicables; saldo de crédito y vencimiento; validación del docente; reporte de costo al concluir. Hasta entonces la matriz conserva este subpunto como pendiente y no como satisfecho.

## 16. Móvil: moderación y protección de contenido

El contenido se verifica en servidor antes de guardarse de forma persistente en las bases o contenedores del producto. La validación del teléfono no reemplaza esta comprobación.

### Pipeline de texto e imagen

Flutter envía datos al servicio de confianza. Este valida tamaño y tipo, mantiene el archivo en memoria acotada y llama a la API de moderación de Azure. Si rechaza, descarta los bytes y devuelve 422 con motivo apropiado. Si aprueba, guarda la imagen en Blob, registra mediaId y un comprobante vinculado a hash, usuario, finalidad y versión de política. El servicio de negocio comprueba ese comprobante antes de asociar el medio.

### Evitar cargas previas indebidas

No entregar una URL de subida directa al almacenamiento público antes de la revisión. Desactivar buffering a disco, captura de cuerpos en proxies/APM, archivos temporales y logs de payload para este flujo. Aplicar límites de concurrencia y tamaño para que la revisión en memoria sea viable. El envío a la API de nube es tratamiento por un proveedor y debe figurar en privacidad.

### Textos y cambios posteriores

Aplicar revisión a nombre público, biografía, solicitud, trabajo, experiencia, mensaje y borrador generativo antes de persistirlos. El contenido modificado invalida la aprobación anterior por hash. No registrar el contenido rechazado en la auditoría; conservar solo metadatos mínimos de decisión, política y fecha.

### Fallos y revisión humana

Si la API falla o agota cuota, conservar el borrador solo en el teléfono y permitir reintento. No publicar por defecto. El reporte posterior permite denunciar contenido que escapó a la revisión automática; la decisión humana produce eventos para ocultar o restaurar y deja motivo auditado.

### Video

La maqueta carga imágenes, no ofrece publicación de video. Mantener videos deshabilitados en esta versión. Si se incorpora esa función, requiere una spec adicional para moderar imagen y audio con una API adecuada antes de persistencia. Content Safety documenta APIs de texto e imagen [F08]; no debe anunciarse como una solución completa de moderación de video.

### Aceptación

Enviar texto e imagen permitidos, rechazados, demasiado grandes, con MIME falso y con proveedor caído. Verificar que el contenido rechazado no aparece en MongoDB, Blob, CDN, temporales ni logs y que no puede reutilizarse un comprobante para un archivo distinto.

## 16. Móvil: push, privacidad, permisos y eliminación

Estas funciones forman parte del producto inicial y deben verificarse en un dispositivo real.

### Notificaciones push

FCM entrega avisos de mensaje nuevo, interés, pedido recibido, aceptación/rechazo/cancelación, resolución y decisión de reporte [F09]. S07 registra token por dispositivo, preferencia y último resultado; invalida tokens rechazados y deduplica por evento/destinatario. El enlace profundo abre el recurso tras autenticar y comprobar acceso. No transportar dirección, texto privado ni teléfono en el push.

### Permisos Android

Ubicación durante uso, solicitada al pulsar usar ubicación; alternativa manual siempre disponible. Notificaciones mediante solicitud contextual según versión Android. Cámara solo al tomar foto y selección de galería mediante selector del sistema. No pedir contactos, SMS, teléfono ni ubicación en segundo plano sin una función aprobada que los requiera.

### Aviso y datos

La app y landing publican el mismo aviso versionado: responsable y contacto reales, datos tratados, finalidad, proveedores, visibilidad, retención, eliminación y medios de atención. Mostrar distinción entre zona pública, domicilio privado y local comercial publicado voluntariamente. El contenido legal definitivo requiere completar información real del titular; esta especificación no inventa su identidad.

### Eliminación de cuenta

Reautenticar, explicar alcance y confirmar. S01 bloquea acceso, revoca sesiones y emite account.deletion.requested. Cada servicio elimina o anonimiza sus datos según política: perfil, fotos, guardados, dispositivos y contenido asociado. Mantener el estado hasta reunir confirmaciones. No mostrar “eliminado” mientras falte un servicio.

### Ruta web y conservación

Publicar una ruta web para solicitar eliminación además de la app, conforme a Play [F10]. Propuesta de plazos a ratificar: ejecución activa en siete días, respaldo rotativo con máximo treinta días y comprobante mínimo de trámite. Explicar las excepciones justificadas y no reactivar datos eliminados al restaurar respaldos. Mensajes compartidos requieren una política consistente de anonimización y retiro de adjuntos.

### Aceptación

Probar push en primer plano, segundo plano y app cerrada; permisos denegados; apertura de enlaces con sesión cerrada; eliminación parcial y completa; purga de caché/CDN y restauración con registro de borrados aplicado.

## 16. Móvil: offline, ML e IA generativa

La app mantiene recorridos de consulta sin conexión y ofrece dos funciones inteligentes distintas, con control del usuario y métricas de calidad.

### SQLite y sincronización

Guardar catálogo, últimos perfiles públicos, guardados y borradores bajo userId. Cola local con operationId, tipo, payload, fecha y versión base. Reenviar con Idempotency-Key cuando haya red. Los guardados usan PUT/DELETE idempotentes; cambios de perfil usan If-Match y resolución de conflicto. Pedidos, aceptación y publicación necesitan confirmación del servidor y se muestran pendientes hasta recibirla.

### Límites offline

No declarar publicado un borrador ni entregado un mensaje sin acuse persistente. No permitir aceptación o resolución offline sobre un estado obsoleto. Sin conexión se pueden preparar textos y conservar consultas anteriores con aviso de antigüedad. Tras logout, purgar cola y datos privados; no subir borradores del usuario anterior.

### Función ML propuesta

Sugerir categoría de servicio a partir de la foto con un modelo de clasificación local integrado mediante ML Kit/LiteRT. El modelo genérico reconoce objetos, pero no garantiza categorías de oficios [F11]. Validar el mapeo o entrenar un clasificador específico; permitir abstención y selección manual. No sustituir ML por las palabras clave inferCats del HTML y anunciarlo como modelo entrenado.

### Evaluación ML

Preparar dataset etiquetado con autorización y sin duplicados entre entrenamiento y prueba. Propuesta inicial: al menos treinta imágenes de prueba por categoría prioritaria; medir precisión, recall, macro-F1, confusión y latencia en dispositivo. Meta propuesta macro-F1 >= 0.75 y p95 < 800 ms; si no se alcanza, ajustar el modelo y mantener sugerencias conservadoras. No se reportan métricas aún inexistentes.

### Función generativa propuesta

Botón “Ayúdame a redactar” en solicitud y trabajo. S06 envía descripción mínima, categoría y tono a un modelo de texto hospedado en Azure; modelo y región se fijan tras verificar acceso [F12]. Devuelve borrador editable de extensión acotada. No agrega datos no indicados ni publica automáticamente. El texto final pasa por moderación. Sin cupo, el usuario redacta manualmente, pero la entrega académica todavía requiere demostrar IA real.

### Evaluación y privacidad de IA

Ensayar al menos treinta casos con información faltante, instrucciones maliciosas, precios, teléfonos y contenido inseguro. Medir utilidad, fidelidad y ausencia de datos inventados. Minimizar información enviada, excluir conversaciones privadas y domicilio; limitar tokens y frecuencia. La moderación no se cuenta como sustituto de ambas funciones exigidas.

## 17. Landing page y Google Analytics

La landing será el punto público de presentación y soporte de políticas, conectado con la app publicada y su versión real.

### Contenido y navegación

Propuesta de valor, explicación breve para solicitante y prestador, capturas reales de Flutter, enlace a Google Play, contacto del proyecto, privacidad, manejo de datos, términos y solicitud de eliminación. Mantener la identidad de landing-v3.html y actualizar lo que contradiga el producto vigente.

### Google Analytics

Crear una propiedad GA4 desde la cuenta de proyecto, un flujo web y su Measurement ID. Insertar el código oficial en la landing y verificar page_view y click_google_play en DebugView. “Vincular el correo” implica usar esa cuenta para administrar la propiedad; el correo no reemplaza el ID de medición.

### Datos y consentimiento

No enviar a Analytics nombres, teléfonos, correos, texto de solicitudes, conversaciones ni coordenadas precisas. Revisar parámetros y URLs. Informar el tratamiento y configurar los mecanismos de consentimiento que correspondan al despliegue. No habilitar analítica privada dentro de la app por inferencia de este requisito de landing.

### Hosting y enlaces

Static Web Apps es una opción de alojamiento; el punto 17 permite otra. Usar HTTPS, enlace de tienda definitivo y rutas permanentes para privacidad y eliminación. Un dominio ilustrativo en el prototipo no acredita titularidad ni disponibilidad.

### Aceptación

Probar enlaces desde móvil, navegación por teclado, contraste, tiempos y registro de eventos sin datos personales. Conservar captura de DebugView y versión del aviso. El código de medición real queda pendiente de la cuenta y propiedad del equipo.

## 18. GitHub, cuenta de proyecto y carpeta compartida

Los proyectos deben quedar bajo una única cuenta titular de GitHub. El PDF sugiere un correo común de proyecto y solicita una carpeta compartida del equipo.

### Organización propuesta

Un monorepo bajo la cuenta acordada simplifica la evaluación: aplicaciones, servicios, contratos, infraestructura y documentación. Las rutas disparan pipelines independientes; usar un repositorio común no convierte a los microservicios en un monolito de ejecución. Si se prefieren varios repositorios, todos deben quedar bajo la misma cuenta y enlazados desde un índice.

### Acceso del equipo

Invitar a integrantes con sus propias cuentas y permisos de colaboración. Usar MFA y evitar compartir contraseña del titular. Un correo institucional del proyecto administra notificaciones y servicios cuando sea posible; preservar trazabilidad individual en commits, revisiones e infraestructura.

### Carpeta compartida

El jefe de proyecto crea carpetas para fuentes, entrevistas, arquitectura, matrices, diseños, pruebas, entregas y actas. Definir acceso del docente y retención de consentimientos. El repositorio conserva los documentos técnicos versionables; la carpeta centraliza evidencia de campo y archivos de entrega.

### Estado y aceptación

La cuenta y carpeta actuales no se verificaron en esta tarea. Registrar titular, repositorio, enlace de carpeta y responsables vigentes. Comprobar que cada integrante puede acceder y que las evidencias no exponen secretos o datos personales innecesarios.

## 19. Evaluación y paquete de entrega

La fecha indicada en el documento es el 2 de diciembre de 2026. Las entregas posteriores se consideran remedial y, en su caso, extraordinario.

### Paquete .rar

Incluir código de backend, Flutter y landing; specs y contratos; Terraform; scripts de bases NoSQL; validadores, índices y semillas sintéticas; manual de ejecución; manifiesto de versiones; pruebas y evidencias. Excluir secretos, bases reales, claves de firma, tokens, cachés y dependencias regenerables. Comprimir con una herramienta compatible y comprobar extracción.

### Guía de evaluación

Explicar instalación desde Google Play, cuentas de prueba, orden de los recorridos, servicios requeridos y evidencias de dos réplicas, Redis, moderación, push, ML e IA generativa. Distinguir función real de mock de prueba. Conservar un entorno disponible durante la evaluación y plan de apagado posterior acorde al presupuesto.

### Cronograma propuesto

26-30 octubre: cerrar alcance, entrevistas, matrices, decisiones de nube y SDD. 31 octubre-4 noviembre: identidad, directorio y primer AAB. 5-12 noviembre: solicitudes, pedidos, chat y prueba cerrada. 13-19 noviembre: comunidad, moderación, push, ML/IA, eliminación y landing. 20-26 noviembre: integración, carga y publicación. 27 noviembre-1 diciembre: correcciones, respaldo y ensayo. 2 diciembre: evaluación.

### Condiciones del cronograma

Es una planificación objetivo, no estimación validada con capacidad del equipo. La prueba cerrada puede iniciar con una versión temprana, pero el alcance final debe estar completo para evaluación. Revisión de tienda, disponibilidad de nube y aprendizaje de ML pueden obligar a adelantar trabajo o redistribuir responsables.

### Trabajo del equipo

Conservar aportaciones verificables por integrante. El requisito señala que quien se separe deberá realizar un proyecto propio que cumpla el mismo recorrido. El documento no acredita participación ni asigna nuevos nombres sin confirmación del equipo.

## Tareas previas 1 y 2: usuarios y descripción

La última página del PDF añade seis tareas para equipos con maqueta autorizada. Son entregables previos al desarrollo, además de los 19 puntos generales.

### Tarea 1. Retroalimentación real

Proponer seis entrevistas iniciales: tres personas que buscan servicios y tres prestadores, incluyendo un negocio. Esta es una meta de reclutamiento, no evidencia existente. Registrar consentimiento, fecha, perfil, contexto, tareas, dificultades, citas autorizadas y decisiones. Anonimizar participantes con E01, E02, etc.

### Guion de observación

Pedir al solicitante encontrar un servicio en su zona, comparar dos opciones, entender las señales de confianza, contactar y enviar un pedido. Pedir al prestador crear un perfil, ajustar cobertura, expresar interés y aceptar un pedido. Observar sin guiar cada clic; preguntar qué espera de la privacidad, el precio, la calificación y la confirmación del teléfono.

### Evidencia

Conservar notas originales, grabación o captura con consentimiento, síntesis y matriz hallazgo/impacto/cambio/prueba. No usar personajes semilla del HTML como entrevistas. Documentar también hallazgos que no producen cambios y su razón. Las entrevistas permanecen pendientes porque no se aportaron registros.

### Tarea 2. Descripciones separadas

Los capítulos “Descripción en español del proyecto backend” y “Descripción en español del proyecto móvil” satisfacen la preparación documental de esta tarea. Explican responsabilidad, flujo, información y restricciones por separado, con el alcance actualizado del prototipo.

## Tareas previas 3 a 6: matrices, referencias y SDD

Las hojas de cálculo acompañantes convierten los recorridos en componentes y contratos preparados para discusión e implementación.

### Tarea 3. Componentes

El libro incluye Componentes_Backend y Componentes_Movil. Cada registro identifica propósito, responsabilidad, entradas/salidas, dependencia y criterio de aceptación. Los componentes visuales incluyen navegación, formularios, tarjetas, mapas, pestañas, selectores, estados y hojas inferiores. No se inventó contenido de la unidad 1, que no fue proporcionado.

### Tarea 4. CRUD y otras funciones

El catálogo asigna identificador a cada endpoint. Cada ficha propia documenta método/ruta, descripción natural, actor, entrada, respuesta, validación, entidad, diseño, llave, índices, paginación, caché y comprobación. Las funciones de búsqueda, filtro, autocompletado y transición de estado se describen como operaciones específicas, no se fuerzan a un CRUD genérico.

### Tarea 5. Proyectos del docente

Pendiente de URL de la cuenta y repositorios compartidos. Al recibirlos: registrar URL y commit, leer licencia y documentación, identificar patrones aplicables y compararlos con esta arquitectura. Entregar matriz proyecto/aprendizaje/adopción/razón. No se afirma haber descargado o analizado repositorios no identificados.

### Tarea 6. Estructura SDD

Después de completar las tareas anteriores, crear constitución, glosario, specs, planes, tareas, contratos y evidencia. Priorizar una vertical verificable: visitante busca, se registra, consulta perfil y envía pedido; continuar con prestador y chat. La estructura prevista se documenta aquí; su creación operativa corresponde al inicio del desarrollo.

### Pendientes para la siguiente clase

Confirmar fecha de clase, completar entrevistas, facilitar enlaces del docente, elegir responsables actuales y resolver la interpretación de costo cero. Estos faltantes no se marcan como cumplidos por la existencia de este PDF.

## Decisiones de arquitectura y alternativas

Las decisiones propuestas se registrarán como ADR y se revisarán cuando cambien volumen, equipo, presupuesto o reglas del producto.

### ADR-01. Microservicios por negocio

Elegir servicios independientes y datos propios. Beneficio: despliegue y escalado por capacidad. Costo: red, operación y eventos. Mantener solicitudes/pedidos/interesados juntos protege la consistencia de asignación. No partir cada pantalla en un servicio.

### ADR-02. NoSQL y datos políglotas

MongoDB para estado durable, Redis para coordinación/caché, Blob para archivos y SQLite local. Reutilizar un motor adecuado entre varios servicios es válido. Diferenciar propiedad lógica y motor físico. Añadir otro motor requiere una consulta o restricción medida que lo justifique.

### ADR-03. REST, WebSocket y eventos

REST ofrece contratos simples y testeables; WebSocket cubre avisos bidireccionales; eventos desacoplan proyecciones y notificaciones. Los mensajes se escriben por REST para reutilizar moderación, idempotencia y errores. WebSocket no constituye la única copia del contenido.

### ADR-04. Moderación previa

Revisión de bytes en memoria antes de guardar. Se renuncia a subir directamente al Blob sin revisión porque contradice el punto 16. El tamaño y paralelismo se limitan; archivos grandes y video requieren diseño específico adicional.

### ADR-05. Azure condicionado al costo

Azure es la ruta recomendada por integración, pero necesita cotización. No se toma como válida la afirmación de costo cero de la guía antigua. La arquitectura funcional puede mantenerse si cambia el proveedor mediante adaptadores e IaC.

### ADR-06. Confianza y privacidad

Diferenciar declarado, teléfono comprobado y opinión. Separar experiencia declarada de pedido registrado. Revocar acceso al domicilio tras cancelación y evitar coordenadas exactas públicas. La interfaz refleja exactamente el alcance comprobado de cada señal.

## Revisión 1.1. Relaciones, menciones y grafo

Se incorpora un diseño de grafo para descubrimiento, sin convertir cada relación del producto en un nuevo motor o protocolo.

### Qué demuestra la maqueta

mresHTML y mentionHTML permiten elegir un prestador y mostrar @nombre al publicar una experiencia. expSteps exige prestador, estrellas y texto. La relación real es autor -> experiencia -> prestador. No se identificaron flujos de amistad, seguimiento entre personas, comentarios anidados ni múltiples menciones libres en publicaciones. Estos no se añaden al alcance aprobado por suponer que toda red local los necesita.

### Qué se corrige

La edición 1.0 descartaba el grafo de forma demasiado general y omitía contratos específicos. Esta revisión diseña S08 con Neo4j, completa la selección de menciones, la consulta propia de experiencias y preferencias de contacto. La utilidad de recorridos indirectos debe demostrarse con consultas del producto; tener una relación por sí solo no hace obligatoria una base de grafos.

### Relación directa y consulta indirecta

Para mostrar experiencias del prestador basta un índice por providerId en MongoDB. Para explorar prestadores que comparten categorías se recorre Provider -> Category <- Provider. Para propuestas basadas en recomendaciones se sigue AccountRef -> Experience -> Provider y se agregan los prestadores por recomendador compartido. Ese segundo caso se precomputa por lotes con límites, no se expone como recorrido ilimitado. Ningún resultado identifica a personas que recomendaron en común.

### Decisión ADR-G01

Estado: propuesta de arquitectura para validar. Elegir Neo4j como proyección en S08 porque representa relaciones tipadas y recorridos explícitos [F20]. Mantener MongoDB como autoridad de S01-S07. Alternativa mínima: referencias e índices MongoDB, incluyendo $graphLookup donde encaje [F23]; alternativa administrada: Cosmos Gremlin [F22]. Comparar esfuerzo, costo total, latencia y recuperación. No se afirma que Neo4j ya sea más rápido ni que exista una carga que obligue a desplegarlo.

### API y base son decisiones distintas

REST, GraphQL y WebSocket son interfaces; MongoDB y Neo4j son persistencia. Una API REST puede consultar Neo4j y GraphQL puede resolver MongoDB. GraphQL no es el lenguaje de consulta de Neo4j: el adaptador usa Cypher. Una librería puede traducir GraphQL a Cypher [F25], pero no sustituye la autorización ni la moderación de Nexo. Flutter se conecta a la API HTTPS, nunca directamente al motor.

### Activación y continuidad

Primero publicar los recorridos actuales con REST. S08 queda en el diseño y se activa al validar consultas, recuperación y costo. Si el grafo falla, directorio, menciones, publicaciones, pedidos y chat siguen operando; se ocultan recomendaciones o se devuelve una lista REST básica identificada como tal. GraphQL es opcional, sin obligación de reescribir todos los repositorios Flutter.

## Modelo y consistencia del grafo

S08 recibe hechos aprobados de los servicios propietarios. Su contenido es derivado y puede reconstruirse.

### Nodos y relaciones

AccountRef -AUTHORED-> Experience -ABOUT_PROVIDER-> Provider; Experience -RECOMMENDS-> Provider cuando el usuario lo indicó. Provider -PUBLISHED-> WorkPost; Provider -OFFERS-> Category; WorkPost -IN_CATEGORY-> Category. Las reacciones a trabajos pueden proyectarse para cálculo interno con identificador seudónimo. No copiar pedidos, chats, domicilios, números, credenciales, guardados privados ni preferencias personales de intereses.

### Autoridad y sincronización

S03 guarda experiencia, mención y outbox en una misma transacción. S02 emite perfiles/categorías actualizados; S03 publica snapshots versionados de trabajos, experiencias y reacciones. S08 procesa por agregado; en una transacción Neo4j actualiza relaciones, marca eventId y sourceVersion. Eventos duplicados no duplican aristas; una versión antigua no revive un estado retirado. Un snapshot que cambia proveedor elimina primero las aristas salientes del mismo agregado y conserva las de otros.

### Eliminación y privacidad

Una cuenta eliminada se bloquea inmediatamente en S01 y deja de aparecer al revalidar resultados. S08 consume account.deletion.requested, retira nodos/aristas y confirma la saga. Mantener tombstone mínimo con identificador seudónimo, sin contenido de usuario, acceso restringido y retención durante el horizonte de replay acordado, o usar un registro de exclusión en la reconstrucción. No devolver datos del grafo si no se puede comprobar la visibilidad vigente en S01/S02/S03. Una revocación no espera a que llegue el evento para ser efectiva en la API.

### Reconstrucción y operación

Crear un snapshot exportado por cada propietario con checkpoint, importar en una proyección nueva, reproducir eventos posteriores, comparar conteos/relaciones e intercambiar la proyección activa. Son procesos internos controlados, no endpoints públicos de escritura arbitraria. Medir lag, duplicados, errores, cola muerta, tiempo de reconstrucción y tamaño. Respaldar la base y probar restauración; disponer de los datos de origen no sustituye una estrategia de continuidad.

### Calidad y límites de recomendaciones

Usar categorías comunes como primer caso de dos saltos. Un cálculo por recomendadores compartidos es una ampliación analítica, requiere evaluar consentimiento, sesgo y exposición de relaciones; solo produce candidatos agregados. Revalidar actividad, cobertura, bloqueo aplicable y visibilidad en servicios propietarios. La afinidad no demuestra calidad ni contratación real y no reemplaza filtros de búsqueda. El modelo de grafo no acredita por sí solo el requisito de aprendizaje automático.

### Ensayo de aceptación propuesto

Comparar en un conjunto sintético reproducible referencias MongoDB y Neo4j: detalle directo, categorías compartidas y cambio/borrado de experiencia. Medir p50/p95, costo de ingestión y operación con volumen declarado. Metas iniciales a validar: lectura p95 <300 ms en backend y lag normal <5 s; límites no observados todavía. Probar caída del grafo, replay fuera de orden, dos consumidores concurrentes y eliminación durante una reconstrucción.

## Contratos nuevos y ajustes de la revisión

Se conservan EP-001 a EP-092 y se agregan EP-093 a EP-098. Los seis contratos nuevos distinguen funciones visibles y ampliaciones técnicas.

### Menciones y experiencia propia

EP-093 GET /mentions/suggestions reproduce búsqueda por nombre/oficio y sugerencias cercanas sin texto, con cinco resultados. EP-094 GET /me/reviews recupera experiencias por authorId. EP-095 GET /reviews/{id} es complemento propuesto para referencias y enlaces, no una nueva pantalla confirmada. La mención se escribe en POST/PATCH /reviews: no necesita un endpoint de escritura ni una colección independiente.

### Contacto y consentimiento

EP-096 PATCH /me/provider/contact-preferences representa las opciones de cuenta. EP-097 PATCH /orders/{id}/contact-preference añade revocación explícita al diseño. La opción Solo chat debe prevalecer aun cuando el pedido esté aceptado. Nuevas conversaciones consultan chatEnabled; se propone conservar conversaciones de pedidos activos cuando se desactiva la captación por chat. Esta última regla necesita ratificación de producto.

### GraphQL opcional

EP-098 POST /graphql/social/v1 es una ruta raíz propia, fuera de /api/v1. Operaciones de lectura SocialProviderContext y RelatedProviders, descritas en la hoja GraphQL. Categorías comunes usan dos saltos; agregados más complejos se calculan fuera de la petición. Un solo endpoint puede ofrecer distintas consultas tipadas. No se duplica cada operación como endpoint independiente ni se añaden mutations que eludan REST/moderación.

### Controles de GraphQL

Aplicar operaciones registradas, variables tipadas, autorización por recurso/campo y protección frente a consultas costosas [F24]. Límites propuestos: profundidad 4, dos saltos, first 1..20, hasta 100 objetos por respuesta, una operación por petición y timeout 2 s. La paginación usa cursor opaco ligado a snapshot y consulta; un snapshot vencido obliga a reiniciar, evitando mezclar ordenamientos. Rate limit por identidad y costo; no aceptar Cypher/Gremlin del cliente. data/errors puede ser parcial y Flutter debe distinguirlo de lista vacía.

### Campos y reglas completados

Revisar además endpoints existentes: fotos/portada y ubicación de cuenta, campos comerciales de prestador, radio cero para local, texto de trabajo 10..200 y cuatro fotos, texto de solicitud/experiencia 10..280 y estrellas obligatorias. El título del trabajo se genera desde el texto. Problema/tiempo permanecían en handlers residuales, no en el compositor visible; no se exigen como campos del MVP.

### Notificación de mención

Propuesta adicional: review.upserted puede avisar al prestador una sola vez al crear la experiencia o cambiar el destinatario. Deduplicar por eventId, destinatario y tipo; revalidar destino al abrir. Editar el texto sin cambiar destinatario no genera otra notificación. No se presenta este aviso como comportamiento ya comprobado en la maqueta.

## Auditoría interactiva y cobertura por módulo

Auditoría interactiva realizada el 29/10/2026 en https://nexo-local-v1.netlify.app/ mediante Chrome DevTools MCP, alternativa autorizada por el usuario. Se usaron las cuentas demo de solicitante y prestador, y dos cuentas ficticias creadas para alta, recuperación y borrado. Las imágenes de prueba se generaron en el navegador y pasaron por los controles de archivo del prototipo (no por un servidor de moderación). Se recorrieron las funciones visibles de los 27 componentes móviles del inventario; M25 carece de integración real y M26 tiene verificación visual limitada. No se ejecutaron todas las combinaciones posibles ni pruebas de APIs, seguridad productiva o dispositivo Android. La landing W01 se conserva como pendiente separado. El script principal publicado coincide con el local aprobado: 253,043 caracteres normalizados a LF y SHA-256 6144a3bc4073aa74dc383543be98a38191bb8fb0cffc2c01213a7940ec4ccc94. Esta coincidencia no compara todos los assets ni el HTML completo.

### Resultados y límites

El catálogo T01-T57 registra pasos, esperado, observado y estado. Conforme significa que el recorrido descrito respondió como se esperaba en la maqueta; no acredita persistencia, seguridad o integración de producción. Con hallazgo indica discrepancia reproducida; Simulación identifica OTP, respuestas automáticas, reportes y notificaciones de ejemplo. No disponible y No ejecutado son estados explícitos, no aprobaciones.

### Hallazgos con impacto de arquitectura

H01-H03 exigen permisos por estado y consentimiento, proyección de DTO privados y aislamiento por usuario. H04-H05 afectan mención y envío rápido. H06-H08 precisan completitud, contadores y comparabilidad. H09-H12 completan edición, modalidad local, contexto de conversación y contratos de filtros/límites. No es necesario añadir otra base de datos para corregirlos.

### Qué sigue pendiente

APIs productivas, concurrencia entre clientes, SMS/OTP real, revocación Redis, moderación en nube, push FCM, modelos ML/GenAI, reconstrucción del grafo, respaldos, permisos Android, lector de pantalla y prueba de deep links. La landing conserva su checklist separado. Estas pruebas deberán repetirse cuando existan backend y app Flutter.

### Evidencia reproducible

output/auditoria/2026-10-29 contiene registros JSON, captura del teléfono expuesto en pedido pendiente, captura móvil y el informe editable. Los números, direcciones y precios usados son datos demo o ficticios. No se modificó el código de la maqueta; los defectos se registran para diseño e implementación.

## Revisión 1.2. Resultados y decisiones de implementación

La prueba del prototipo completa el análisis estático. Los defectos observados se convierten en reglas verificables para Flutter y las APIs.

### Prioridad de corrección

Antes de desarrollar funcionalidades adicionales, cerrar H01-H03: autorización del contacto, retiro del domicilio al rechazar/cancelar e identidad por autor. Estas reglas se prueban con dos cuentas, estados distintos y caché. Después corregir interacción de menciones y respuestas rápidas, edición permanente y definición de indicadores.

### Contratos agregados sin multiplicar bases

Se conservan EP-001 a EP-098 y se agregan EP-099 catálogo de motivos, EP-100 política interna de contacto y EP-101 visibilidad interna de autores por lote. Son complementos de consistencia del diseño; no APIs existentes del HTML. Completitud, contadores y contexto se incorporan a contratos ya existentes. No se necesita otro motor para cada control de UI.

### Datos y filtros precisados

MongoDB conserva cuenta/autor, portafolio, publicaciones, pedidos, opiniones, intereses y mensajes con contexto. La consulta de solicitudes distingue propietario, coincidencia de servicios, cobertura y urgencia Hoy. Interés fuera de categoría coincidente sigue permitido por el alcance visible; shortlist no se presenta como función aprobada visible.

### Impacto sobre el grafo

S08 sigue siendo proyección opcional para consultas indirectas. Las menciones son providerId dentro de reviews; AUTHORED usa accountId estable. El problema observado de Tú demuestra la necesidad de identidad, no una limitación de MongoDB. El grafo no decide teléfonos ni domicilios: revalida con propietarios y no guarda estos datos. Los hallazgos no justifican añadir amistades/seguidores inexistentes.

### Política de indicadores propuesta

Separar fotos de portafolio, publicaciones, pedidos completados y recomendaciones. El detalle de precios incluye unidad/moneda/servicio/materiales. Definir siete criterios de completitud con la misma política versionada en registro, perfil y cuenta; su fórmula queda propuesta y pendiente de validación de producto, no copiada de porcentajes inconsistentes del HTML.

### Alcance de la evidencia

Las capturas y registros acreditan interacción con la maqueta, no una implementación de Flutter, seguridad backend, sincronización SQLite, infraestructura o Neo4j. Las pruebas pendientes tienen responsable funcional y criterio. No se corrigió el HTML aprobado durante esta auditoría: las correcciones están especificadas en los entregables de desarrollo.

## Anexo: entidades y contratos

### accounts (S01)

Una cuenta por persona responsable: _id UUID, phoneE164, passwordHash, displayName, requesterProfile, providerId opcional, preferences, consentVersions, status, createdAt, updatedAt, version. El hash de contraseña usa un algoritmo adaptativo y sal aleatoria, nunca cifrado reversible. Perfil solicitante: photoMediaId, coverMediaId, privateHomeLocation y publicZone. Resúmenes propios de solicitudes/experiencias/guardados se componen por API; no se alteran desde el cliente.

Índices: PK _id; UQ phoneE164; status+updatedAt. No devolver passwordHash en DTO.

Cuenta única con modo solicitante y prestador si tiene perfil. Campos públicos pasan moderación. Datos privados solo al propietario. authorId y namespace de caché siempre se derivan de la identidad autenticada; displayName=Tú o providerId=me nunca son claves reales. Cambio de cuenta purga cachés privados y borradores de otro usuario.

### otp_challenges (S01)

_id UUID, phoneHash, purpose, codeHash, attempts, expiresAt, usedAt. No guardar código en claro ni registrarlo en logs.

Índices: PK _id; phoneHash+purpose+createdAt; TTL expiresAt.

Propuesta OTP de seis dígitos, cinco minutos, máximo cinco intentos, reenvío tras sesenta segundos. Comprobar expiresAt en aplicación; TTL no controla por sí solo la validez.

### sessions (S01)

_id sid, userId, deviceId, refreshHash, familyId, generation, status, expiresAt, revokedAt, version. Historial de hashes gastados para detectar reutilización.

Índices: PK sid; UQ refreshHash; userId+status; TTL expiresAt con retención acordada.

Rotación atómica y detección de replay. Redis conserva revocación/ticket/contador con TTL; MongoDB mantiene verdad durable.

### deletions (S01)

_id UUID, userId, requestedAt, status, acknowledgements por servicio, lastError sin datos sensibles, completedAt.

Índices: PK _id; UQ userId para trámite activo; status+requestedAt.

Bloquear acceso de inmediato y completar solo al confirmar todos los propietarios. Reintentos idempotentes y tratamiento de copias de seguridad.

### categories (S02)

_id slug, label, synonyms, specialties, sectors, active, version. Catálogo controlado de servicios y modalidades.

Índices: PK slug; active+label; tokens normalizados para sugerencias.

Solo administración cambia catálogo. Las categorías inactivas conservan referencias históricas y no permiten altas nuevas.

### providers (S02)

_id UUID, userId, type persona/negocio, name, bio, categoryIds, specialties, serviceLabels, mode dom/local/ambos, privateOrigin GeoJSON, publicZone, publicBusinessLocation opcional, radiusKm, schedule, timeZone, visitPrice, prices, paymentMethods, warrantyText, responseText, urgent, mediaIds, confirmedPhone, status, version. Campos visibles adicionales: ownerDisplayName, experienceLabel (declarada), sectorId/otherSector, activity, otherCategoryLabel, otherSpecialtyLabel, team, crew, materialsPolicy, invoiceDeclared, website, portfolioMediaIds (hasta seis fotos en registro), avatarMediaId, coverMediaId; contactPreferences {chatEnabled, showPhone}. priceItems: hasta tres filas visibles iniciales con serviceKey opcional de catálogo, label, amountMinor, currency, pricingMode from/fixed/quote, unit y includesMaterials; no inferir unidad ausente. Respuesta propia: completeness {policyVersion,percent,missingFields}; opportunitySummary {matchingOpen,allVisibleOpen,withMyInterest}. Respuesta pública: portfolioPhotoCount, publishedPostCount, completedOrderCount, recommendationsCount separados.

Índices: PK _id; UQ userId; 2dsphere privateOrigin; categoryIds+status+updatedAt; tokens normalizados; status+_id. Medir planes con multikey.

No publicar privateOrigin. La dirección comercial exacta requiere intención explícita. Condiciones y experiencia son declaradas. Actualizaciones con If-Match y moderación. Responsable visible no sustituye a userId. Facturación es declaración comercial, no emisión de facturas. radio=0 permitido para modalidad solo local; dom/ambos exigen radio positivo. URLs HTTP(S) validadas. Completitud derivada, no editable. Una política propuesta de completitud: siete criterios con igual peso (teléfono confirmado, nombre/categoría/bio válidos, cobertura/modalidad válida, horario, precio/visita, foto de perfil, al menos tres publicaciones activas). percent=round(100*n/7). Condiciones y portada no alteran esa primera política; registrar su versión y ratificar criterio con producto. Las fotos del registro no cuentan como publicaciones ni como pedidos completados.

### read_cache (S02)

_id hash de consulta/version, payload público resumido, generatedAt, expiresAt. Proyecciones públicas usan sourceId y sourceVersion.

Índices: PK _id; TTL expiresAt; UQ sourceId en proyecciones.

Excluir PII, dirección privada y datos dependientes de sesión. Invalidación por cambios y comparación de versión. Cache-aside Redis delante del motor.

### posts (S03)

_id UUID, authorId, providerId, categoryId, title derivado del texto, workDone de 10 a 200 caracteres, publicZone, privateWorkLocation opcional, mediaIds (0..4), moderationRef, status, createdAt, version.

Índices: PK _id; providerId+status+createdAt+_id; categoryId+status+createdAt+_id.

Solo prestador propietario, categoría ofrecida, texto 10..200, máximo 4 fotos aprobadas propias. Título derivado de primera oración hasta 60 caracteres. Problema/tiempo no se exigen: sus handlers son residuales, sin controles en el compositor actual. Ubicación del trabajo privada; devolver zona aproximada. Borrado lógico y retiro de medios sin referencias.

### reviews (S03)

_id UUID, authorId, providerId obligatorio (una mención estructurada), orderId opcional, kind declared/registeredOrder, text de 10 a 280 caracteres, recommends booleano, stars entero obligatorio 1..5, moderationRef, status, createdAt, version.

Índices: PK _id; UQ parcial orderId cuando existe; providerId+status+createdAt+_id; authorId+createdAt+_id.

No autoevaluación. Selección por providerId, nunca por texto @nombre. Si orderId existe, validar dueño y done en S04 y mantener su providerId. Una opinión por pedido. Para experiencia declarada se permite corregir providerId validado; emitir retiro de la relación anterior y nueva relación en un evento versionado. No certificar experiencias declaradas.

### saved (S03)

_id UUID, userId, targetType provider/post/request, targetId, createdAt. Reacciones usan colección reactions: userId, targetType, targetId, createdAt.

Índices: PK _id; UQ userId+targetType+targetId; userId+targetType+createdAt+_id.

Solo dueño lista guardados. PUT crea o conserva; DELETE retira idempotentemente. Agregados derivados, nunca contador alterable libremente por cliente.

### metrics (S03)

_id UUID para evento mínimo, providerId, kind view/contact/share, actorPseudonym opcional, occurredAt; agregados diarios con counts.

Índices: PK _id; TTL de eventos crudos según política; UQ providerId+day en agregado.

Registrar intención y visitas, no contratación ni ingreso. Minimizar identificadores y evitar doble conteo por reintentos.

### requests (S04)

_id UUID, ownerId, categoryId, description, publicZone, privateLocation, urgency, contactPreference, status open/assigned/closed, selectedProviderId, activeOrderId, createdAt, version. Filtros separados: ownerOnly (propias), matchMyServices (coincidencia de categoría), withinMyCoverage y urgency=Hoy. No interpretar urgente hoy como createdAt de hoy.

Índices: PK _id; 2dsphere privateLocation; categoryId+status+createdAt+_id; ownerId+createdAt+_id.

Consulta pública entrega solo zona aproximada. Publicar exige cuenta, categoría y diez caracteres. Solicitud cerrada no admite interés ni nuevos pedidos. Asignación se modifica dentro de S04. Texto máximo 280. contactPreference chat/both; no divulgar número con chat. S04 mantiene la preferencia vigente del pedido; cambios en una solicitud vinculada se propagan en la misma transacción local.

### interests (S04)

_id UUID, requestId, providerId, createdAt, shortlisted. La propiedad shortlisted se modifica únicamente por dueño de solicitud.

Índices: PK _id; UQ requestId+providerId; requestId+createdAt; providerId+createdAt.

Solo perfil activo puede interesarse en solicitud ajena abierta. Retirar no cancela automáticamente pedido existente. La preselección no confirma contratación. Coincidencia de categoría prioriza/filtra resultados, no es un bloqueo de autorización en el alcance visible. Solicitud debe ser abierta, ajena y visible para el prestador; fuera de radio requiere ampliación explícita etiquetada. Mantener UUID real de prestador por cuenta.

### orders (S04)

_id UUID, requestId opcional, clientId, providerId, categoryId, description, origin, mode, privatePlace, publicZone, status pend/ok/done/cancel, active bool, quote {amountMinor,currency,note}, history limitada o colección separada, version, createdAt. clientContactPreference chat/both y contactConsentVersion, heredados de la solicitud o explícitos en pedido directo (chat por defecto).

Índices: PK _id; clientId+status+createdAt+_id; providerId+status+createdAt+_id; UQ parcial requestId con active=true y requestId existente; UQ parcial clientId+providerId con active=true.

Cambios condicionales por version. Aceptar y asignar solicitud en transacción local. active=true solo pend/ok. Precio opcional, positivo, en centavos. Domicilio filtrado por actor y estado. Teléfono exige estado ok/done, participante autorizado y consentimiento vigente both; cancelación/revocación lo retira inmediatamente. No depender de una proyección eventual para este permiso.

### conversations (S05)

_id UUID, clientId, providerId, contextRequestId opcional, lastSequence, lastMessageAt, readState por miembro, createdAt, version. activeOrderId opcional derivado de S04 y contextHistoryRefs acotada/paginada; nunca reemplazar contexto de mensajes anteriores por el último pedido.

Índices: PK _id; UQ clientId+providerId; clientId+lastMessageAt+_id; providerId+lastMessageAt+_id.

La pareja conserva orientación cliente/prestador. Un usuario puede participar en ambos papeles sin mezclar conversaciones. No usar nombre como llave.

### messages (S05)

_id UUID, conversationId, senderId, clientMessageId UUID, sequence, kind text/image/system, text o mediaId, moderationRef, eventId opcional, createdAt. Contexto opcional autorizado: requestId, orderId y contextVersion; el mensaje conserva su contexto aunque cambie el pedido activo de la pareja. Texto 1..600 caracteres tras trim.

Índices: PK _id; UQ conversationId+clientMessageId; UQ conversationId+sequence; UQ parcial eventId para avisos; conversationId+sequence para cursor.

Solo miembros sin bloqueo efectivo. Persistir después de moderación. Secuencia asignada atómicamente y confirmación con id real. No arreglos ilimitados de mensajes en conversación.

### blocks (S05)

_id UUID, blockerId, blockedId, conversationId, createdAt.

Índices: PK _id; UQ blockerId+blockedId; blockedId+createdAt.

Solo quien bloqueó puede desbloquear. Cualquiera de las dos direcciones bloquea nuevos envíos; conservar historial autorizado.

### media (S06)

_id UUID, ownerId, sha256, purpose, mime, size, decisionRef, objectKey, visibility public/private, boundResource, status, createdAt, expiresAt de huérfano.

Índices: PK _id; ownerId+createdAt; status+expiresAt; hash+purpose como índice no necesariamente único.

Guardar bytes solo después de aprobación. Autorizar antes de vincular, leer o borrar. Medio de chat privado; sin enlace público permanente. Retirar huérfanos y purgar CDN al eliminar contenido público.

### reports (S06)

_id UUID, reporterId, targetType, targetId, reasonCode, status open/reviewing/closed, decision, reviewerId, createdAt, version; moderation_decisions almacena metadatos sin contenido rechazado.

Índices: PK _id; status+createdAt+_id; targetType+targetId+createdAt; reporterId+createdAt.

Motivo obligatorio y catálogo controlado. Solo moderadores autorizados deciden con auditoría. La ocultación se comunica al propietario por evento.

### devices (S07)

_id UUID, userId, sessionId, token, platform, preferences, updatedAt, status.

Índices: PK _id; UQ token; userId+status; sessionId.

Asociar a sesión actual, invalidar token anterior y eliminar al logout. No exponer tokens en cliente ajeno o logs.

### notifications (S07)

_id UUID, userId, eventId, kind, resourceId, readAt, createdAt; deliveries registra intento, resultado y próximo reintento.

Índices: PK _id; UQ userId+eventId; userId+createdAt+_id; deliveries.status+nextAttemptAt.

Consultar propiedad y revalidar recurso al abrir. Push es aviso; la bandeja persistente refleja el evento. No prometer entrega exactamente una vez.

### outbox_inbox (Transversal)

outbox: _id eventId, type, schemaVersion, aggregateId, aggregateVersion, correlationId, payload mínimo, occurredAt, deliveries. inbox: _id consumerId:eventId, processedAt.

Índices: PK eventId; outbox.deliveryState+occurredAt; UQ inbox.consumerId+eventId; índices de limpieza según retención.

Cambio de negocio y outbox en la misma transacción. Confirmar procesamiento y efecto juntos. Eventos sin contenido de chat ni domicilio. Eliminar mensaje de cola después de confirmar inbox.

### social_graph (S08)

Nodos AccountRef, Provider, WorkPost, Experience, Category con id estable, sourceService, sourceVersion y status público. AccountRef contiene identificador seudónimo, nunca teléfono, dirección o credenciales. Relaciones AUTHORED (AccountRef→Experience), PUBLISHED (Provider→WorkPost), ABOUT_PROVIDER (Experience→Provider), RECOMMENDS (Experience→Provider solo recommends=true), OFFERS (Provider→Category), IN_CATEGORY (WorkPost→Category) y REACTED_TO (AccountRef→WorkPost, restringida al procesamiento interno). No inferir amistades por una mención.

Índices: Unicidad id por etiqueta, índices Provider.status y Category.id según consultas medidas. Relaciones con id lógico determinista (origen,tipo,destino,sourceId), creadas con MERGE dentro de transacciones y consumidor serializado por agregado; no asumir que MERGE solo impide carreras. Ledger SourceState: clave sourceService:aggregateId única y última versión; ProcessedEvent id único. Restricciones exactas según edición elegida.

Solo S08 escribe la proyección. Cada snapshot versionado reemplaza relaciones salientes administradas por ese agregado; elimina aristas obsoletas al cambiar prestador/recomendación. Transacción incluye efecto, SourceState e inbox. Tombstones rechazan eventos antiguos después del borrado. Autorización y visibilidad se revalidan en S01/S02/S03 antes de devolver datos; nunca revelar identidades de co-recomendadores ni usar conexiones privadas para inferir confianza.

### EP-001 POST /auth/otp

- **Servicio propietario:** S01
- **Descripción en español:** Solicitar verificación o recuperación del teléfono
- **Actor autorizado:** Público limitado
- **Entrada:** phoneE164, purpose registration/recovery
- **Respuesta esperada:** 202 challengeId y retryAfter
- **Reglas de negocio:** Respuesta neutral; límites por IP/teléfono; no devolver código
- **Entidad / base:** otp_challenges / nl_identity
- **Diseño del documento o estado:** _id UUID, phoneHash, purpose, codeHash, attempts, expiresAt, usedAt. No guardar código en claro ni registrarlo en logs.
- **Llaves e índices:** PK _id; phoneHash+purpose+createdAt; TTL expiresAt.
- **Integridad y privacidad:** Propuesta OTP de seis dígitos, cinco minutos, máximo cinco intentos, reenvío tras sesenta segundos. Comprobar expiresAt en aplicación; TTL no controla por sí solo la validez.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: solicitar verificación o recuperación del teléfono. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** obresend, aunext
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-002 POST /auth/otp/verify

- **Servicio propietario:** S01
- **Descripción en español:** Comprobar código y obtener prueba de control
- **Actor autorizado:** Público con desafío
- **Entrada:** challengeId, code
- **Respuesta esperada:** 200 proofToken de un uso y corta duración
- **Reglas de negocio:** Verificar intentos, propósito, expiración y no reutilización
- **Entidad / base:** otp_challenges / nl_identity
- **Diseño del documento o estado:** _id UUID, phoneHash, purpose, codeHash, attempts, expiresAt, usedAt. No guardar código en claro ni registrarlo en logs.
- **Llaves e índices:** PK _id; phoneHash+purpose+createdAt; TTL expiresAt.
- **Integridad y privacidad:** Propuesta OTP de seis dígitos, cinco minutos, máximo cinco intentos, reenvío tras sesenta segundos. Comprobar expiresAt en aplicación; TTL no controla por sí solo la validez.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: comprobar código y obtener prueba de control. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** obnext, aunext
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-003 POST /auth/register

- **Servicio propietario:** S01
- **Descripción en español:** Crear cuenta única y consentimiento
- **Actor autorizado:** Público con prueba OTP
- **Entrada:** proofToken, password, displayName, consentVersions
- **Respuesta esperada:** 201 account y sesión
- **Reglas de negocio:** Teléfono único; nombre moderado; secreto protegido
- **Entidad / base:** accounts / nl_identity
- **Diseño del documento o estado:** Una cuenta por persona responsable: _id UUID, phoneE164, passwordHash, displayName, requesterProfile, providerId opcional, preferences, consentVersions, status, createdAt, updatedAt, version. El hash de contraseña usa un algoritmo adaptativo y sal aleatoria, nunca cifrado reversible. Perfil solicitante: photoMediaId, coverMediaId, privateHomeLocation y publicZone. Resúmenes propios de solicitudes/experiencias/guardados se componen por API; no se alteran desde el cliente.
- **Llaves e índices:** PK _id; UQ phoneE164; status+updatedAt. No devolver passwordHash en DTO.
- **Integridad y privacidad:** Cuenta única con modo solicitante y prestador si tiene perfil. Campos públicos pasan moderación. Datos privados solo al propietario. authorId y namespace de caché siempre se derivan de la identidad autenticada; displayName=Tú o providerId=me nunca son claves reales. Cambio de cuenta purga cachés privados y borradores de otro usuario.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: crear cuenta única y consentimiento. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** obFinish
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-004 POST /auth/login

- **Servicio propietario:** S01
- **Descripción en español:** Iniciar sesión con teléfono y contraseña
- **Actor autorizado:** Público limitado
- **Entrada:** phoneE164, password, deviceId
- **Respuesta esperada:** 200 accessToken y refreshToken
- **Reglas de negocio:** Error neutral; hash adaptativo; nunca aceptar cuentas demo en release
- **Entidad / base:** sessions / nl_identity
- **Diseño del documento o estado:** _id sid, userId, deviceId, refreshHash, familyId, generation, status, expiresAt, revokedAt, version. Historial de hashes gastados para detectar reutilización.
- **Llaves e índices:** PK sid; UQ refreshHash; userId+status; TTL expiresAt con retención acordada.
- **Integridad y privacidad:** Rotación atómica y detección de replay. Redis conserva revocación/ticket/contador con TTL; MongoDB mantiene verdad durable.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: iniciar sesión con teléfono y contraseña. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** aunext
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-005 POST /auth/refresh

- **Servicio propietario:** S01
- **Descripción en español:** Renovar sesión sin login repetido
- **Actor autorizado:** Poseedor de refresh
- **Entrada:** refreshToken, deviceId
- **Respuesta esperada:** 200 nuevo par de tokens
- **Reglas de negocio:** Rotación atómica; replay revoca familia; coordinación de peticiones móviles
- **Entidad / base:** sessions / nl_identity
- **Diseño del documento o estado:** _id sid, userId, deviceId, refreshHash, familyId, generation, status, expiresAt, revokedAt, version. Historial de hashes gastados para detectar reutilización.
- **Llaves e índices:** PK sid; UQ refreshHash; userId+status; TTL expiresAt con retención acordada.
- **Integridad y privacidad:** Rotación atómica y detección de replay. Redis conserva revocación/ticket/contador con TTL; MongoDB mantiene verdad durable.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: renovar sesión sin login repetido. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Sesión persistente requerida
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-006 POST /auth/password-reset

- **Servicio propietario:** S01
- **Descripción en español:** Restablecer acceso y revocar sesiones previas
- **Actor autorizado:** Prueba OTP recovery
- **Entrada:** proofToken, newPassword
- **Respuesta esperada:** 204
- **Reglas de negocio:** No aceptar prueba de registro ni código ya consumido
- **Entidad / base:** accounts / nl_identity
- **Diseño del documento o estado:** Una cuenta por persona responsable: _id UUID, phoneE164, passwordHash, displayName, requesterProfile, providerId opcional, preferences, consentVersions, status, createdAt, updatedAt, version. El hash de contraseña usa un algoritmo adaptativo y sal aleatoria, nunca cifrado reversible. Perfil solicitante: photoMediaId, coverMediaId, privateHomeLocation y publicZone. Resúmenes propios de solicitudes/experiencias/guardados se componen por API; no se alteran desde el cliente.
- **Llaves e índices:** PK _id; UQ phoneE164; status+updatedAt. No devolver passwordHash en DTO.
- **Integridad y privacidad:** Cuenta única con modo solicitante y prestador si tiene perfil. Campos públicos pasan moderación. Datos privados solo al propietario. authorId y namespace de caché siempre se derivan de la identidad autenticada; displayName=Tú o providerId=me nunca son claves reales. Cambio de cuenta purga cachés privados y borradores de otro usuario.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: restablecer acceso y revocar sesiones previas. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** aunext newpass
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-007 POST /auth/logout

- **Servicio propietario:** S01
- **Descripción en español:** Cerrar sesión actual en backend y dispositivos
- **Actor autorizado:** Cuenta autenticada
- **Entrada:** sid derivado del JWT
- **Respuesta esperada:** 204
- **Reglas de negocio:** Revocación durable y Redis; cierre WebSocket; operación idempotente
- **Entidad / base:** sessions / nl_identity
- **Diseño del documento o estado:** _id sid, userId, deviceId, refreshHash, familyId, generation, status, expiresAt, revokedAt, version. Historial de hashes gastados para detectar reutilización.
- **Llaves e índices:** PK sid; UQ refreshHash; userId+status; TTL expiresAt con retención acordada.
- **Integridad y privacidad:** Rotación atómica y detección de replay. Redis conserva revocación/ticket/contador con TTL; MongoDB mantiene verdad durable.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: cerrar sesión actual en backend y dispositivos. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** logoutdo
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-008 GET /me

- **Servicio propietario:** S01
- **Descripción en español:** Recuperar cuenta, capacidades y preferencias
- **Actor autorizado:** Propietario
- **Entrada:** JWT
- **Respuesta esperada:** 200 perfil privado y modos autorizados; summary de solicitudes/experiencias/guardados mediante composición autorizada
- **Reglas de negocio:** El modo de UI no concede privilegios
- **Entidad / base:** accounts / nl_identity
- **Diseño del documento o estado:** Una cuenta por persona responsable: _id UUID, phoneE164, passwordHash, displayName, requesterProfile, providerId opcional, preferences, consentVersions, status, createdAt, updatedAt, version. El hash de contraseña usa un algoritmo adaptativo y sal aleatoria, nunca cifrado reversible. Perfil solicitante: photoMediaId, coverMediaId, privateHomeLocation y publicZone. Resúmenes propios de solicitudes/experiencias/guardados se componen por API; no se alteran desde el cliente.
- **Llaves e índices:** PK _id; UQ phoneE164; status+updatedAt. No devolver passwordHash en DTO.
- **Integridad y privacidad:** Cuenta única con modo solicitante y prestador si tiene perfil. Campos públicos pasan moderación. Datos privados solo al propietario. authorId y namespace de caché siempre se derivan de la identidad autenticada; displayName=Tú o providerId=me nunca son claves reales. Cambio de cuenta purga cachés privados y borradores de otro usuario.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: recuperar cuenta, capacidades y preferencias. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** V.account
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-009 PATCH /me

- **Servicio propietario:** S01
- **Descripción en español:** Editar nombre, intereses y preferencias
- **Actor autorizado:** Propietario
- **Entrada:** Campos permitidos, If-Match, photoMediaId, coverMediaId, privateHomeLocation/publicZone
- **Respuesta esperada:** 200 cuenta y nueva version
- **Reglas de negocio:** Lista blanca; moderar nombre; no permitir cambio libre de roles; fotos propias aprobadas; origen privado nunca se publica.
- **Entidad / base:** accounts / nl_identity
- **Diseño del documento o estado:** Una cuenta por persona responsable: _id UUID, phoneE164, passwordHash, displayName, requesterProfile, providerId opcional, preferences, consentVersions, status, createdAt, updatedAt, version. El hash de contraseña usa un algoritmo adaptativo y sal aleatoria, nunca cifrado reversible. Perfil solicitante: photoMediaId, coverMediaId, privateHomeLocation y publicZone. Resúmenes propios de solicitudes/experiencias/guardados se componen por API; no se alteran desde el cliente.
- **Llaves e índices:** PK _id; UQ phoneE164; status+updatedAt. No devolver passwordHash en DTO.
- **Integridad y privacidad:** Cuenta única con modo solicitante y prestador si tiene perfil. Campos públicos pasan moderación. Datos privados solo al propietario. authorId y namespace de caché siempre se derivan de la identidad autenticada; displayName=Tú o providerId=me nunca son claves reales. Cambio de cuenta purga cachés privados y borradores de otro usuario.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: editar nombre, intereses y preferencias. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** uint, chan, mode
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-010 GET /me/sessions

- **Servicio propietario:** S01
- **Descripción en español:** Consultar sesiones de sus dispositivos
- **Actor autorizado:** Propietario
- **Entrada:** cursor, limit
- **Respuesta esperada:** 200 lista de sesiones sin secretos
- **Reglas de negocio:** No devolver refreshHash ni direcciones completas
- **Entidad / base:** sessions / nl_identity
- **Diseño del documento o estado:** _id sid, userId, deviceId, refreshHash, familyId, generation, status, expiresAt, revokedAt, version. Historial de hashes gastados para detectar reutilización.
- **Llaves e índices:** PK sid; UQ refreshHash; userId+status; TTL expiresAt con retención acordada.
- **Integridad y privacidad:** Rotación atómica y detección de replay. Redis conserva revocación/ticket/contador con TTL; MongoDB mantiene verdad durable.
- **Paginación y filtros:** Cursor estable + limit 1-50 si devuelve lista. Orden por fecha/secuencia e identificador; no aplicar offset ilimitado.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: consultar sesiones de sus dispositivos. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Ampliación de seguridad
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-011 DELETE /me/sessions/{sid}

- **Servicio propietario:** S01
- **Descripción en español:** Revocar otro dispositivo
- **Actor autorizado:** Propietario
- **Entrada:** sid
- **Respuesta esperada:** 204
- **Reglas de negocio:** Verificar dueño de sesión antes de revocar
- **Entidad / base:** sessions / nl_identity
- **Diseño del documento o estado:** _id sid, userId, deviceId, refreshHash, familyId, generation, status, expiresAt, revokedAt, version. Historial de hashes gastados para detectar reutilización.
- **Llaves e índices:** PK sid; UQ refreshHash; userId+status; TTL expiresAt con retención acordada.
- **Integridad y privacidad:** Rotación atómica y detección de replay. Redis conserva revocación/ticket/contador con TTL; MongoDB mantiene verdad durable.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: revocar otro dispositivo. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Ampliación de seguridad
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-012 POST /me/deletion

- **Servicio propietario:** S01
- **Descripción en español:** Solicitar eliminación integral
- **Actor autorizado:** Propietario reautenticado
- **Entrada:** reauthProof, confirmation
- **Respuesta esperada:** 202 deletionId y estado
- **Reglas de negocio:** Bloquear cuenta y emitir evento; no afirmar completado al recibir
- **Entidad / base:** deletions / nl_identity
- **Diseño del documento o estado:** _id UUID, userId, requestedAt, status, acknowledgements por servicio, lastError sin datos sensibles, completedAt.
- **Llaves e índices:** PK _id; UQ userId para trámite activo; status+requestedAt.
- **Integridad y privacidad:** Bloquear acceso de inmediato y completar solo al confirmar todos los propietarios. Reintentos idempotentes y tratamiento de copias de seguridad.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: solicitar eliminación integral. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** delconfirm
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-013 GET /me/deletion/{id}

- **Servicio propietario:** S01
- **Descripción en español:** Consultar progreso del borrado
- **Actor autorizado:** Credencial limitada al trámite
- **Entrada:** id, deletionReceipt
- **Respuesta esperada:** 200 estado y servicios pendientes
- **Reglas de negocio:** Receipt solo permite consultar este trámite, nunca reabrir cuenta
- **Entidad / base:** deletions / nl_identity
- **Diseño del documento o estado:** _id UUID, userId, requestedAt, status, acknowledgements por servicio, lastError sin datos sensibles, completedAt.
- **Llaves e índices:** PK _id; UQ userId para trámite activo; status+requestedAt.
- **Integridad y privacidad:** Bloquear acceso de inmediato y completar solo al confirmar todos los propietarios. Reintentos idempotentes y tratamiento de copias de seguridad.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: consultar progreso del borrado. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Requisito 16
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-014 GET /catalog/categories

- **Servicio propietario:** S02
- **Descripción en español:** Listar categorías, especialidades y sectores
- **Actor autorizado:** Público
- **Entrada:** version opcional
- **Respuesta esperada:** 200 catálogo y ETag
- **Reglas de negocio:** Excluir altas inactivas; caché público 24 h
- **Entidad / base:** categories / nl_directory
- **Diseño del documento o estado:** _id slug, label, synonyms, specialties, sectors, active, version. Catálogo controlado de servicios y modalidades.
- **Llaves e índices:** PK slug; active+label; tokens normalizados para sugerencias.
- **Integridad y privacidad:** Solo administración cambia catálogo. Las categorías inactivas conservan referencias históricas y no permiten altas nuevas.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** Caché solo de DTO público. Catálogo 24 h, perfil 60 s, búsqueda 30 s; invalidación por versión/evento. Geo sin ubicación privada en caché público.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: listar categorías, especialidades y sectores. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** CATS, SPEC, obStep
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-015 PUT /admin/catalog/categories/{id}

- **Servicio propietario:** S02
- **Descripción en español:** Crear o actualizar categoría
- **Actor autorizado:** Administrador
- **Entrada:** label, synonyms, active, If-Match si existe
- **Respuesta esperada:** 200/201 categoría
- **Reglas de negocio:** Auditar; conservar referencias; invalidar caché
- **Entidad / base:** categories / nl_directory
- **Diseño del documento o estado:** _id slug, label, synonyms, specialties, sectors, active, version. Catálogo controlado de servicios y modalidades.
- **Llaves e índices:** PK slug; active+label; tokens normalizados para sugerencias.
- **Integridad y privacidad:** Solo administración cambia catálogo. Las categorías inactivas conservan referencias históricas y no permiten altas nuevas.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: crear o actualizar categoría. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Operación requerida
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-016 POST /providers

- **Servicio propietario:** S02
- **Descripción en español:** Crear perfil de persona o negocio
- **Actor autorizado:** Cuenta sin perfil
- **Entrada:** type, name, categorías, modalidad, ubicación, radio, mediaIds
- **Respuesta esperada:** 201 perfil privado/publicable
- **Reglas de negocio:** Un perfil por cuenta; mínimos de registro; texto/medios aprobados; portafolio de registro hasta seis fotos aprobadas; no contar fotos como trabajos ni reutilizar providerId=me entre cuentas.
- **Entidad / base:** providers / nl_directory
- **Diseño del documento o estado:** _id UUID, userId, type persona/negocio, name, bio, categoryIds, specialties, serviceLabels, mode dom/local/ambos, privateOrigin GeoJSON, publicZone, publicBusinessLocation opcional, radiusKm, schedule, timeZone, visitPrice, prices, paymentMethods, warrantyText, responseText, urgent, mediaIds, confirmedPhone, status, version. Campos visibles adicionales: ownerDisplayName, experienceLabel (declarada), sectorId/otherSector, activity, otherCategoryLabel, otherSpecialtyLabel, team, crew, materialsPolicy, invoiceDeclared, website, portfolioMediaIds (hasta seis fotos en registro), avatarMediaId, coverMediaId; contactPreferences {chatEnabled, showPhone}. priceItems: hasta tres filas visibles iniciales con serviceKey opcional de catálogo, label, amountMinor, currency, pricingMode from/fixed/quote, unit y includesMaterials; no inferir unidad ausente. Respuesta propia: completeness {policyVersion,percent,missingFields}; opportunitySummary {matchingOpen,allVisibleOpen,withMyInterest}. Respuesta pública: portfolioPhotoCount, publishedPostCount, completedOrderCount, recommendationsCount separados.
- **Llaves e índices:** PK _id; UQ userId; 2dsphere privateOrigin; categoryIds+status+updatedAt; tokens normalizados; status+_id. Medir planes con multikey.
- **Integridad y privacidad:** No publicar privateOrigin. La dirección comercial exacta requiere intención explícita. Condiciones y experiencia son declaradas. Actualizaciones con If-Match y moderación. Responsable visible no sustituye a userId. Facturación es declaración comercial, no emisión de facturas. radio=0 permitido para modalidad solo local; dom/ambos exigen radio positivo. URLs HTTP(S) validadas. Completitud derivada, no editable. Una política propuesta de completitud: siete criterios con igual peso (teléfono confirmado, nombre/categoría/bio válidos, cobertura/modalidad válida, horario, precio/visita, foto de perfil, al menos tres publicaciones activas). percent=round(100*n/7). Condiciones y portada no alteran esa primera política; registrar su versión y ratificar criterio con producto. Las fotos del registro no cuentan como publicaciones ni como pedidos completados.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: crear perfil de persona o negocio. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** buildProvider, obFinish
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-017 GET /providers/{id}

- **Servicio propietario:** S02
- **Descripción en español:** Consultar perfil público y señales
- **Actor autorizado:** Público
- **Entrada:** id
- **Respuesta esperada:** 200 DTO público y ETag; conteos separados de publicaciones, fotos y pedidos resueltos
- **Reglas de negocio:** Ocultar origen privado y datos de cuenta; teléfono según permisos
- **Entidad / base:** providers / nl_directory
- **Diseño del documento o estado:** _id UUID, userId, type persona/negocio, name, bio, categoryIds, specialties, serviceLabels, mode dom/local/ambos, privateOrigin GeoJSON, publicZone, publicBusinessLocation opcional, radiusKm, schedule, timeZone, visitPrice, prices, paymentMethods, warrantyText, responseText, urgent, mediaIds, confirmedPhone, status, version. Campos visibles adicionales: ownerDisplayName, experienceLabel (declarada), sectorId/otherSector, activity, otherCategoryLabel, otherSpecialtyLabel, team, crew, materialsPolicy, invoiceDeclared, website, portfolioMediaIds (hasta seis fotos en registro), avatarMediaId, coverMediaId; contactPreferences {chatEnabled, showPhone}. priceItems: hasta tres filas visibles iniciales con serviceKey opcional de catálogo, label, amountMinor, currency, pricingMode from/fixed/quote, unit y includesMaterials; no inferir unidad ausente. Respuesta propia: completeness {policyVersion,percent,missingFields}; opportunitySummary {matchingOpen,allVisibleOpen,withMyInterest}. Respuesta pública: portfolioPhotoCount, publishedPostCount, completedOrderCount, recommendationsCount separados.
- **Llaves e índices:** PK _id; UQ userId; 2dsphere privateOrigin; categoryIds+status+updatedAt; tokens normalizados; status+_id. Medir planes con multikey.
- **Integridad y privacidad:** No publicar privateOrigin. La dirección comercial exacta requiere intención explícita. Condiciones y experiencia son declaradas. Actualizaciones con If-Match y moderación. Responsable visible no sustituye a userId. Facturación es declaración comercial, no emisión de facturas. radio=0 permitido para modalidad solo local; dom/ambos exigen radio positivo. URLs HTTP(S) validadas. Completitud derivada, no editable. Una política propuesta de completitud: siete criterios con igual peso (teléfono confirmado, nombre/categoría/bio válidos, cobertura/modalidad válida, horario, precio/visita, foto de perfil, al menos tres publicaciones activas). percent=round(100*n/7). Condiciones y portada no alteran esa primera política; registrar su versión y ratificar criterio con producto. Las fotos del registro no cuentan como publicaciones ni como pedidos completados.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** Caché solo de DTO público. Catálogo 24 h, perfil 60 s, búsqueda 30 s; invalidación por versión/evento. Geo sin ubicación privada en caché público.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: consultar perfil público y señales. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** V.profile
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-018 GET /me/provider

- **Servicio propietario:** S02
- **Descripción en español:** Consultar perfil editable y completitud
- **Actor autorizado:** Prestador propietario
- **Entrada:** JWT
- **Respuesta esperada:** 200 perfil privado; completeness versionada y opportunitySummary con conteos distintos
- **Reglas de negocio:** Solo propio; completitud se calcula desde campos persistidos
- **Entidad / base:** providers / nl_directory
- **Diseño del documento o estado:** _id UUID, userId, type persona/negocio, name, bio, categoryIds, specialties, serviceLabels, mode dom/local/ambos, privateOrigin GeoJSON, publicZone, publicBusinessLocation opcional, radiusKm, schedule, timeZone, visitPrice, prices, paymentMethods, warrantyText, responseText, urgent, mediaIds, confirmedPhone, status, version. Campos visibles adicionales: ownerDisplayName, experienceLabel (declarada), sectorId/otherSector, activity, otherCategoryLabel, otherSpecialtyLabel, team, crew, materialsPolicy, invoiceDeclared, website, portfolioMediaIds (hasta seis fotos en registro), avatarMediaId, coverMediaId; contactPreferences {chatEnabled, showPhone}. priceItems: hasta tres filas visibles iniciales con serviceKey opcional de catálogo, label, amountMinor, currency, pricingMode from/fixed/quote, unit y includesMaterials; no inferir unidad ausente. Respuesta propia: completeness {policyVersion,percent,missingFields}; opportunitySummary {matchingOpen,allVisibleOpen,withMyInterest}. Respuesta pública: portfolioPhotoCount, publishedPostCount, completedOrderCount, recommendationsCount separados.
- **Llaves e índices:** PK _id; UQ userId; 2dsphere privateOrigin; categoryIds+status+updatedAt; tokens normalizados; status+_id. Medir planes con multikey.
- **Integridad y privacidad:** No publicar privateOrigin. La dirección comercial exacta requiere intención explícita. Condiciones y experiencia son declaradas. Actualizaciones con If-Match y moderación. Responsable visible no sustituye a userId. Facturación es declaración comercial, no emisión de facturas. radio=0 permitido para modalidad solo local; dom/ambos exigen radio positivo. URLs HTTP(S) validadas. Completitud derivada, no editable. Una política propuesta de completitud: siete criterios con igual peso (teléfono confirmado, nombre/categoría/bio válidos, cobertura/modalidad válida, horario, precio/visita, foto de perfil, al menos tres publicaciones activas). percent=round(100*n/7). Condiciones y portada no alteran esa primera política; registrar su versión y ratificar criterio con producto. Las fotos del registro no cuentan como publicaciones ni como pedidos completados.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: consultar perfil editable y completitud. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** profileTodo
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-019 PATCH /me/provider

- **Servicio propietario:** S02
- **Descripción en español:** Actualizar datos comerciales y servicios
- **Actor autorizado:** Prestador propietario
- **Entrada:** Campos permitidos, If-Match; responsable, experiencia, equipo/materiales, factura declarada, web/sector y medios de perfil
- **Respuesta esperada:** 200 perfil y versión
- **Reglas de negocio:** Máximo tres precios orientativos en UI inicial; catálogo/categorías aparte; contenido moderado; editor permanente permite corregir campos completos, no solo faltantes.
- **Entidad / base:** providers / nl_directory
- **Diseño del documento o estado:** _id UUID, userId, type persona/negocio, name, bio, categoryIds, specialties, serviceLabels, mode dom/local/ambos, privateOrigin GeoJSON, publicZone, publicBusinessLocation opcional, radiusKm, schedule, timeZone, visitPrice, prices, paymentMethods, warrantyText, responseText, urgent, mediaIds, confirmedPhone, status, version. Campos visibles adicionales: ownerDisplayName, experienceLabel (declarada), sectorId/otherSector, activity, otherCategoryLabel, otherSpecialtyLabel, team, crew, materialsPolicy, invoiceDeclared, website, portfolioMediaIds (hasta seis fotos en registro), avatarMediaId, coverMediaId; contactPreferences {chatEnabled, showPhone}. priceItems: hasta tres filas visibles iniciales con serviceKey opcional de catálogo, label, amountMinor, currency, pricingMode from/fixed/quote, unit y includesMaterials; no inferir unidad ausente. Respuesta propia: completeness {policyVersion,percent,missingFields}; opportunitySummary {matchingOpen,allVisibleOpen,withMyInterest}. Respuesta pública: portfolioPhotoCount, publishedPostCount, completedOrderCount, recommendationsCount separados.
- **Llaves e índices:** PK _id; UQ userId; 2dsphere privateOrigin; categoryIds+status+updatedAt; tokens normalizados; status+_id. Medir planes con multikey.
- **Integridad y privacidad:** No publicar privateOrigin. La dirección comercial exacta requiere intención explícita. Condiciones y experiencia son declaradas. Actualizaciones con If-Match y moderación. Responsable visible no sustituye a userId. Facturación es declaración comercial, no emisión de facturas. radio=0 permitido para modalidad solo local; dom/ambos exigen radio positivo. URLs HTTP(S) validadas. Completitud derivada, no editable. Una política propuesta de completitud: siete criterios con igual peso (teléfono confirmado, nombre/categoría/bio válidos, cobertura/modalidad válida, horario, precio/visita, foto de perfil, al menos tres publicaciones activas). percent=round(100*n/7). Condiciones y portada no alteran esa primera política; registrar su versión y ratificar criterio con producto. Las fotos del registro no cuentan como publicaciones ni como pedidos completados.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: actualizar datos comerciales y servicios. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** svcadd, edsave, addcat
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-020 PATCH /me/provider/coverage

- **Servicio propietario:** S02
- **Descripción en español:** Editar modalidad y zona de atención
- **Actor autorizado:** Prestador propietario
- **Entrada:** mode, privateOrigin, radiusKm, publicBusinessLocation, If-Match
- **Respuesta esperada:** 200 cobertura
- **Reglas de negocio:** Validar rango de coordenadas y radio positivo en dom/ambos, cero permitido en local; publicación comercial explícita
- **Entidad / base:** providers / nl_directory
- **Diseño del documento o estado:** _id UUID, userId, type persona/negocio, name, bio, categoryIds, specialties, serviceLabels, mode dom/local/ambos, privateOrigin GeoJSON, publicZone, publicBusinessLocation opcional, radiusKm, schedule, timeZone, visitPrice, prices, paymentMethods, warrantyText, responseText, urgent, mediaIds, confirmedPhone, status, version. Campos visibles adicionales: ownerDisplayName, experienceLabel (declarada), sectorId/otherSector, activity, otherCategoryLabel, otherSpecialtyLabel, team, crew, materialsPolicy, invoiceDeclared, website, portfolioMediaIds (hasta seis fotos en registro), avatarMediaId, coverMediaId; contactPreferences {chatEnabled, showPhone}. priceItems: hasta tres filas visibles iniciales con serviceKey opcional de catálogo, label, amountMinor, currency, pricingMode from/fixed/quote, unit y includesMaterials; no inferir unidad ausente. Respuesta propia: completeness {policyVersion,percent,missingFields}; opportunitySummary {matchingOpen,allVisibleOpen,withMyInterest}. Respuesta pública: portfolioPhotoCount, publishedPostCount, completedOrderCount, recommendationsCount separados.
- **Llaves e índices:** PK _id; UQ userId; 2dsphere privateOrigin; categoryIds+status+updatedAt; tokens normalizados; status+_id. Medir planes con multikey.
- **Integridad y privacidad:** No publicar privateOrigin. La dirección comercial exacta requiere intención explícita. Condiciones y experiencia son declaradas. Actualizaciones con If-Match y moderación. Responsable visible no sustituye a userId. Facturación es declaración comercial, no emisión de facturas. radio=0 permitido para modalidad solo local; dom/ambos exigen radio positivo. URLs HTTP(S) validadas. Completitud derivada, no editable. Una política propuesta de completitud: siete criterios con igual peso (teléfono confirmado, nombre/categoría/bio válidos, cobertura/modalidad válida, horario, precio/visita, foto de perfil, al menos tres publicaciones activas). percent=round(100*n/7). Condiciones y portada no alteran esa primera política; registrar su versión y ratificar criterio con producto. Las fotos del registro no cuentan como publicaciones ni como pedidos completados.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: editar modalidad y zona de atención. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** obloc, addrad
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-021 PATCH /me/provider/schedule

- **Servicio propietario:** S02
- **Descripción en español:** Configurar horarios y urgencias
- **Actor autorizado:** Prestador propietario
- **Entrada:** schedule, timeZone, urgent, If-Match
- **Respuesta esperada:** 200 horario
- **Reglas de negocio:** Cierre posterior a apertura para alcance inicial; validar zona IANA
- **Entidad / base:** providers / nl_directory
- **Diseño del documento o estado:** _id UUID, userId, type persona/negocio, name, bio, categoryIds, specialties, serviceLabels, mode dom/local/ambos, privateOrigin GeoJSON, publicZone, publicBusinessLocation opcional, radiusKm, schedule, timeZone, visitPrice, prices, paymentMethods, warrantyText, responseText, urgent, mediaIds, confirmedPhone, status, version. Campos visibles adicionales: ownerDisplayName, experienceLabel (declarada), sectorId/otherSector, activity, otherCategoryLabel, otherSpecialtyLabel, team, crew, materialsPolicy, invoiceDeclared, website, portfolioMediaIds (hasta seis fotos en registro), avatarMediaId, coverMediaId; contactPreferences {chatEnabled, showPhone}. priceItems: hasta tres filas visibles iniciales con serviceKey opcional de catálogo, label, amountMinor, currency, pricingMode from/fixed/quote, unit y includesMaterials; no inferir unidad ausente. Respuesta propia: completeness {policyVersion,percent,missingFields}; opportunitySummary {matchingOpen,allVisibleOpen,withMyInterest}. Respuesta pública: portfolioPhotoCount, publishedPostCount, completedOrderCount, recommendationsCount separados.
- **Llaves e índices:** PK _id; UQ userId; 2dsphere privateOrigin; categoryIds+status+updatedAt; tokens normalizados; status+_id. Medir planes con multikey.
- **Integridad y privacidad:** No publicar privateOrigin. La dirección comercial exacta requiere intención explícita. Condiciones y experiencia son declaradas. Actualizaciones con If-Match y moderación. Responsable visible no sustituye a userId. Facturación es declaración comercial, no emisión de facturas. radio=0 permitido para modalidad solo local; dom/ambos exigen radio positivo. URLs HTTP(S) validadas. Completitud derivada, no editable. Una política propuesta de completitud: siete criterios con igual peso (teléfono confirmado, nombre/categoría/bio válidos, cobertura/modalidad válida, horario, precio/visita, foto de perfil, al menos tres publicaciones activas). percent=round(100*n/7). Condiciones y portada no alteran esa primera política; registrar su versión y ratificar criterio con producto. Las fotos del registro no cuentan como publicaciones ni como pedidos completados.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: configurar horarios y urgencias. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** edday, edurg, edsave
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-022 PATCH /me/provider/prices

- **Servicio propietario:** S02
- **Descripción en español:** Definir visita y precios orientativos
- **Actor autorizado:** Prestador propietario
- **Entrada:** visitPrice opcional, priceItems 0..3 con label, amountMinor, currency, unit, pricingMode, serviceKey opcional e includesMaterials, If-Match
- **Respuesta esperada:** 200 condiciones
- **Reglas de negocio:** Cero representa visita gratis; ausencia no equivale a cero; tres filas visibles; no comparar montos de unidades distintas.
- **Entidad / base:** providers / nl_directory
- **Diseño del documento o estado:** _id UUID, userId, type persona/negocio, name, bio, categoryIds, specialties, serviceLabels, mode dom/local/ambos, privateOrigin GeoJSON, publicZone, publicBusinessLocation opcional, radiusKm, schedule, timeZone, visitPrice, prices, paymentMethods, warrantyText, responseText, urgent, mediaIds, confirmedPhone, status, version. Campos visibles adicionales: ownerDisplayName, experienceLabel (declarada), sectorId/otherSector, activity, otherCategoryLabel, otherSpecialtyLabel, team, crew, materialsPolicy, invoiceDeclared, website, portfolioMediaIds (hasta seis fotos en registro), avatarMediaId, coverMediaId; contactPreferences {chatEnabled, showPhone}. priceItems: hasta tres filas visibles iniciales con serviceKey opcional de catálogo, label, amountMinor, currency, pricingMode from/fixed/quote, unit y includesMaterials; no inferir unidad ausente. Respuesta propia: completeness {policyVersion,percent,missingFields}; opportunitySummary {matchingOpen,allVisibleOpen,withMyInterest}. Respuesta pública: portfolioPhotoCount, publishedPostCount, completedOrderCount, recommendationsCount separados.
- **Llaves e índices:** PK _id; UQ userId; 2dsphere privateOrigin; categoryIds+status+updatedAt; tokens normalizados; status+_id. Medir planes con multikey.
- **Integridad y privacidad:** No publicar privateOrigin. La dirección comercial exacta requiere intención explícita. Condiciones y experiencia son declaradas. Actualizaciones con If-Match y moderación. Responsable visible no sustituye a userId. Facturación es declaración comercial, no emisión de facturas. radio=0 permitido para modalidad solo local; dom/ambos exigen radio positivo. URLs HTTP(S) validadas. Completitud derivada, no editable. Una política propuesta de completitud: siete criterios con igual peso (teléfono confirmado, nombre/categoría/bio válidos, cobertura/modalidad válida, horario, precio/visita, foto de perfil, al menos tres publicaciones activas). percent=round(100*n/7). Condiciones y portada no alteran esa primera política; registrar su versión y ratificar criterio con producto. Las fotos del registro no cuentan como publicaciones ni como pedidos completados.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: definir visita y precios orientativos. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** edvm, edsave
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-023 POST /me/provider/refresh

- **Servicio propietario:** S02
- **Descripción en español:** Confirmar vigencia de información
- **Actor autorizado:** Prestador propietario
- **Entrada:** If-Match
- **Respuesta esperada:** 200 updatedAt y versión
- **Reglas de negocio:** No aumentar reputación por pulsar actualizar
- **Entidad / base:** providers / nl_directory
- **Diseño del documento o estado:** _id UUID, userId, type persona/negocio, name, bio, categoryIds, specialties, serviceLabels, mode dom/local/ambos, privateOrigin GeoJSON, publicZone, publicBusinessLocation opcional, radiusKm, schedule, timeZone, visitPrice, prices, paymentMethods, warrantyText, responseText, urgent, mediaIds, confirmedPhone, status, version. Campos visibles adicionales: ownerDisplayName, experienceLabel (declarada), sectorId/otherSector, activity, otherCategoryLabel, otherSpecialtyLabel, team, crew, materialsPolicy, invoiceDeclared, website, portfolioMediaIds (hasta seis fotos en registro), avatarMediaId, coverMediaId; contactPreferences {chatEnabled, showPhone}. priceItems: hasta tres filas visibles iniciales con serviceKey opcional de catálogo, label, amountMinor, currency, pricingMode from/fixed/quote, unit y includesMaterials; no inferir unidad ausente. Respuesta propia: completeness {policyVersion,percent,missingFields}; opportunitySummary {matchingOpen,allVisibleOpen,withMyInterest}. Respuesta pública: portfolioPhotoCount, publishedPostCount, completedOrderCount, recommendationsCount separados.
- **Llaves e índices:** PK _id; UQ userId; 2dsphere privateOrigin; categoryIds+status+updatedAt; tokens normalizados; status+_id. Medir planes con multikey.
- **Integridad y privacidad:** No publicar privateOrigin. La dirección comercial exacta requiere intención explícita. Condiciones y experiencia son declaradas. Actualizaciones con If-Match y moderación. Responsable visible no sustituye a userId. Facturación es declaración comercial, no emisión de facturas. radio=0 permitido para modalidad solo local; dom/ambos exigen radio positivo. URLs HTTP(S) validadas. Completitud derivada, no editable. Una política propuesta de completitud: siete criterios con igual peso (teléfono confirmado, nombre/categoría/bio válidos, cobertura/modalidad válida, horario, precio/visita, foto de perfil, al menos tres publicaciones activas). percent=round(100*n/7). Condiciones y portada no alteran esa primera política; registrar su versión y ratificar criterio con producto. Las fotos del registro no cuentan como publicaciones ni como pedidos completados.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: confirmar vigencia de información. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** refresh
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-024 DELETE /me/provider

- **Servicio propietario:** S02
- **Descripción en español:** Retirar perfil de publicación
- **Actor autorizado:** Prestador reautenticado
- **Entrada:** confirmation
- **Respuesta esperada:** 202 retiro
- **Reglas de negocio:** Ampliación operativa; definir tratamiento de pedidos abiertos y vínculos
- **Entidad / base:** providers / nl_directory
- **Diseño del documento o estado:** _id UUID, userId, type persona/negocio, name, bio, categoryIds, specialties, serviceLabels, mode dom/local/ambos, privateOrigin GeoJSON, publicZone, publicBusinessLocation opcional, radiusKm, schedule, timeZone, visitPrice, prices, paymentMethods, warrantyText, responseText, urgent, mediaIds, confirmedPhone, status, version. Campos visibles adicionales: ownerDisplayName, experienceLabel (declarada), sectorId/otherSector, activity, otherCategoryLabel, otherSpecialtyLabel, team, crew, materialsPolicy, invoiceDeclared, website, portfolioMediaIds (hasta seis fotos en registro), avatarMediaId, coverMediaId; contactPreferences {chatEnabled, showPhone}. priceItems: hasta tres filas visibles iniciales con serviceKey opcional de catálogo, label, amountMinor, currency, pricingMode from/fixed/quote, unit y includesMaterials; no inferir unidad ausente. Respuesta propia: completeness {policyVersion,percent,missingFields}; opportunitySummary {matchingOpen,allVisibleOpen,withMyInterest}. Respuesta pública: portfolioPhotoCount, publishedPostCount, completedOrderCount, recommendationsCount separados.
- **Llaves e índices:** PK _id; UQ userId; 2dsphere privateOrigin; categoryIds+status+updatedAt; tokens normalizados; status+_id. Medir planes con multikey.
- **Integridad y privacidad:** No publicar privateOrigin. La dirección comercial exacta requiere intención explícita. Condiciones y experiencia son declaradas. Actualizaciones con If-Match y moderación. Responsable visible no sustituye a userId. Facturación es declaración comercial, no emisión de facturas. radio=0 permitido para modalidad solo local; dom/ambos exigen radio positivo. URLs HTTP(S) validadas. Completitud derivada, no editable. Una política propuesta de completitud: siete criterios con igual peso (teléfono confirmado, nombre/categoría/bio válidos, cobertura/modalidad válida, horario, precio/visita, foto de perfil, al menos tres publicaciones activas). percent=round(100*n/7). Condiciones y portada no alteran esa primera política; registrar su versión y ratificar criterio con producto. Las fotos del registro no cuentan como publicaciones ni como pedidos completados.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: retirar perfil de publicación. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Complemento CRUD
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-025 GET /providers

- **Servicio propietario:** S02
- **Descripción en español:** Buscar y filtrar prestadores por necesidad y zona
- **Actor autorizado:** Público
- **Entrada:** q, category, lat, lng, radius, mode, open, freeVisit, hasPrices, urgent, sort, cursor, limit
- **Respuesta esperada:** 200 resultados, nextCursor, coverageStatus
- **Reglas de negocio:** Cobertura real por prestador; orden estable; ubicación exacta no sale
- **Entidad / base:** providers / nl_directory
- **Diseño del documento o estado:** _id UUID, userId, type persona/negocio, name, bio, categoryIds, specialties, serviceLabels, mode dom/local/ambos, privateOrigin GeoJSON, publicZone, publicBusinessLocation opcional, radiusKm, schedule, timeZone, visitPrice, prices, paymentMethods, warrantyText, responseText, urgent, mediaIds, confirmedPhone, status, version. Campos visibles adicionales: ownerDisplayName, experienceLabel (declarada), sectorId/otherSector, activity, otherCategoryLabel, otherSpecialtyLabel, team, crew, materialsPolicy, invoiceDeclared, website, portfolioMediaIds (hasta seis fotos en registro), avatarMediaId, coverMediaId; contactPreferences {chatEnabled, showPhone}. priceItems: hasta tres filas visibles iniciales con serviceKey opcional de catálogo, label, amountMinor, currency, pricingMode from/fixed/quote, unit y includesMaterials; no inferir unidad ausente. Respuesta propia: completeness {policyVersion,percent,missingFields}; opportunitySummary {matchingOpen,allVisibleOpen,withMyInterest}. Respuesta pública: portfolioPhotoCount, publishedPostCount, completedOrderCount, recommendationsCount separados.
- **Llaves e índices:** PK _id; UQ userId; 2dsphere privateOrigin; categoryIds+status+updatedAt; tokens normalizados; status+_id. Medir planes con multikey.
- **Integridad y privacidad:** No publicar privateOrigin. La dirección comercial exacta requiere intención explícita. Condiciones y experiencia son declaradas. Actualizaciones con If-Match y moderación. Responsable visible no sustituye a userId. Facturación es declaración comercial, no emisión de facturas. radio=0 permitido para modalidad solo local; dom/ambos exigen radio positivo. URLs HTTP(S) validadas. Completitud derivada, no editable. Una política propuesta de completitud: siete criterios con igual peso (teléfono confirmado, nombre/categoría/bio válidos, cobertura/modalidad válida, horario, precio/visita, foto de perfil, al menos tres publicaciones activas). percent=round(100*n/7). Condiciones y portada no alteran esa primera política; registrar su versión y ratificar criterio con producto. Las fotos del registro no cuentan como publicaciones ni como pedidos completados.
- **Paginación y filtros:** Cursor estable + limit 1-50 si devuelve lista. Orden por fecha/secuencia e identificador; no aplicar offset ilimitado.
- **Caché:** Caché solo de DTO público. Catálogo 24 h, perfil 60 s, búsqueda 30 s; invalidación por versión/evento. Geo sin ubicación privada en caché público.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: buscar y filtrar prestadores por necesidad y zona. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** V.search, resultsHTML, filt, fsort
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-026 GET /search/suggestions

- **Servicio propietario:** S02
- **Descripción en español:** Autocompletar servicios y términos reconocidos
- **Actor autorizado:** Público
- **Entrada:** q mínimo 2 caracteres, limit máximo 10
- **Respuesta esperada:** 200 sugerencias
- **Reglas de negocio:** Tokens/prefijos indexados; debounce móvil; excluir búsqueda privada histórica
- **Entidad / base:** categories / nl_directory
- **Diseño del documento o estado:** _id slug, label, synonyms, specialties, sectors, active, version. Catálogo controlado de servicios y modalidades.
- **Llaves e índices:** PK slug; active+label; tokens normalizados para sugerencias.
- **Integridad y privacidad:** Solo administración cambia catálogo. Las categorías inactivas conservan referencias históricas y no permiten altas nuevas.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** Caché solo de DTO público. Catálogo 24 h, perfil 60 s, búsqueda 30 s; invalidación por versión/evento. Geo sin ubicación privada en caché público.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: autocompletar servicios y términos reconocidos. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** sugShow, qsug
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-027 GET /providers/compare

- **Servicio propietario:** S02
- **Descripción en español:** Comparar exactamente dos prestadores
- **Actor autorizado:** Cuenta autenticada
- **Entrada:** ids de dos perfiles
- **Respuesta esperada:** 200 columnas y priceComparison {comparable,reason,serviceKey,unit,currency}
- **Reglas de negocio:** Evitar inventar precio u horario faltante; route estática antes de {id}; destacar precio menor solo si servicio, moneda, unidad y materiales/alcance coinciden; de lo contrario no comparable y sin MEJOR.
- **Entidad / base:** providers / nl_directory
- **Diseño del documento o estado:** _id UUID, userId, type persona/negocio, name, bio, categoryIds, specialties, serviceLabels, mode dom/local/ambos, privateOrigin GeoJSON, publicZone, publicBusinessLocation opcional, radiusKm, schedule, timeZone, visitPrice, prices, paymentMethods, warrantyText, responseText, urgent, mediaIds, confirmedPhone, status, version. Campos visibles adicionales: ownerDisplayName, experienceLabel (declarada), sectorId/otherSector, activity, otherCategoryLabel, otherSpecialtyLabel, team, crew, materialsPolicy, invoiceDeclared, website, portfolioMediaIds (hasta seis fotos en registro), avatarMediaId, coverMediaId; contactPreferences {chatEnabled, showPhone}. priceItems: hasta tres filas visibles iniciales con serviceKey opcional de catálogo, label, amountMinor, currency, pricingMode from/fixed/quote, unit y includesMaterials; no inferir unidad ausente. Respuesta propia: completeness {policyVersion,percent,missingFields}; opportunitySummary {matchingOpen,allVisibleOpen,withMyInterest}. Respuesta pública: portfolioPhotoCount, publishedPostCount, completedOrderCount, recommendationsCount separados.
- **Llaves e índices:** PK _id; UQ userId; 2dsphere privateOrigin; categoryIds+status+updatedAt; tokens normalizados; status+_id. Medir planes con multikey.
- **Integridad y privacidad:** No publicar privateOrigin. La dirección comercial exacta requiere intención explícita. Condiciones y experiencia son declaradas. Actualizaciones con If-Match y moderación. Responsable visible no sustituye a userId. Facturación es declaración comercial, no emisión de facturas. radio=0 permitido para modalidad solo local; dom/ambos exigen radio positivo. URLs HTTP(S) validadas. Completitud derivada, no editable. Una política propuesta de completitud: siete criterios con igual peso (teléfono confirmado, nombre/categoría/bio válidos, cobertura/modalidad válida, horario, precio/visita, foto de perfil, al menos tres publicaciones activas). percent=round(100*n/7). Condiciones y portada no alteran esa primera política; registrar su versión y ratificar criterio con producto. Las fotos del registro no cuentan como publicaciones ni como pedidos completados.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: comparar exactamente dos prestadores. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** V.compare, cmp
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-028 GET /geo/search

- **Servicio propietario:** S02
- **Descripción en español:** Buscar lugar para seleccionar ubicación
- **Actor autorizado:** Público limitado
- **Entrada:** q, country MX, bounds, limit
- **Respuesta esperada:** 200 lugares y coordenadas
- **Reglas de negocio:** Adaptador Azure Maps; comprobar licencia/cupos; limitar precisión pública
- **Entidad / base:** read_cache / nl_directory
- **Diseño del documento o estado:** _id hash de consulta/version, payload público resumido, generatedAt, expiresAt. Proyecciones públicas usan sourceId y sourceVersion.
- **Llaves e índices:** PK _id; TTL expiresAt; UQ sourceId en proyecciones.
- **Integridad y privacidad:** Excluir PII, dirección privada y datos dependientes de sesión. Invalidación por cambios y comparación de versión. Cache-aside Redis delante del motor.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** Caché solo de DTO público. Catálogo 24 h, perfil 60 s, búsqueda 30 s; invalidación por versión/evento. Geo sin ubicación privada en caché público.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: buscar lugar para seleccionar ubicación. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** mapfind
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-029 GET /geo/reverse

- **Servicio propietario:** S02
- **Descripción en español:** Obtener etiqueta de zona desde punto
- **Actor autorizado:** Público limitado
- **Entrada:** lat, lng
- **Respuesta esperada:** 200 etiqueta y zona pública
- **Reglas de negocio:** No guardar consultas precisas en logs o caché pública sin anonimizar
- **Entidad / base:** read_cache / nl_directory
- **Diseño del documento o estado:** _id hash de consulta/version, payload público resumido, generatedAt, expiresAt. Proyecciones públicas usan sourceId y sourceVersion.
- **Llaves e índices:** PK _id; TTL expiresAt; UQ sourceId en proyecciones.
- **Integridad y privacidad:** Excluir PII, dirección privada y datos dependientes de sesión. Invalidación por cambios y comparación de versión. Cache-aside Redis delante del motor.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** Caché solo de DTO público. Catálogo 24 h, perfil 60 s, búsqueda 30 s; invalidación por versión/evento. Geo sin ubicación privada en caché público.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: obtener etiqueta de zona desde punto. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** pkLabel
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-030 GET /feed

- **Servicio propietario:** S03
- **Descripción en español:** Componer inicio por zona y modo
- **Actor autorizado:** Público o cuenta según filtro
- **Entrada:** mode, zone, category, tab, cursor, limit
- **Respuesta esperada:** 200 tarjetas y cursor
- **Reglas de negocio:** Gateway agrega DTO públicos; para mine exige usuario; fallos parciales explícitos; conservar trabajo cercano por cobertura de prestador o distancia del trabajo <=3 km según postNear, usando ubicación privada solo dentro del servidor.
- **Entidad / base:** posts / nl_community
- **Diseño del documento o estado:** _id UUID, authorId, providerId, categoryId, title derivado del texto, workDone de 10 a 200 caracteres, publicZone, privateWorkLocation opcional, mediaIds (0..4), moderationRef, status, createdAt, version.
- **Llaves e índices:** PK _id; providerId+status+createdAt+_id; categoryId+status+createdAt+_id.
- **Integridad y privacidad:** Solo prestador propietario, categoría ofrecida, texto 10..200, máximo 4 fotos aprobadas propias. Título derivado de primera oración hasta 60 caracteres. Problema/tiempo no se exigen: sus handlers son residuales, sin controles en el compositor actual. Ubicación del trabajo privada; devolver zona aproximada. Borrado lógico y retiro de medios sin referencias.
- **Paginación y filtros:** Cursor estable + limit 1-50 si devuelve lista. Orden por fecha/secuencia e identificador; no aplicar offset ilimitado.
- **Caché:** Caché solo de DTO público. Catálogo 24 h, perfil 60 s, búsqueda 30 s; invalidación por versión/evento. Geo sin ubicación privada en caché público.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: componer inicio por zona y modo. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** V.home, htab
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-031 POST /posts

- **Servicio propietario:** S03
- **Descripción en español:** Publicar un trabajo realizado
- **Actor autorizado:** Prestador
- **Entrada:** workDone 10..200, categoryId, publicZone, privateWorkLocation opcional, mediaIds 0..4
- **Respuesta esperada:** 201 publicación
- **Reglas de negocio:** Categoría ofrecida, 0..4 medios propios aprobados; título automático hasta 60 caracteres. No exigir campos residuales problema/tiempo.
- **Entidad / base:** posts / nl_community
- **Diseño del documento o estado:** _id UUID, authorId, providerId, categoryId, title derivado del texto, workDone de 10 a 200 caracteres, publicZone, privateWorkLocation opcional, mediaIds (0..4), moderationRef, status, createdAt, version.
- **Llaves e índices:** PK _id; providerId+status+createdAt+_id; categoryId+status+createdAt+_id.
- **Integridad y privacidad:** Solo prestador propietario, categoría ofrecida, texto 10..200, máximo 4 fotos aprobadas propias. Título derivado de primera oración hasta 60 caracteres. Problema/tiempo no se exigen: sus handlers son residuales, sin controles en el compositor actual. Ubicación del trabajo privada; devolver zona aproximada. Borrado lógico y retiro de medios sin referencias.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: publicar un trabajo realizado. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** publish
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-032 GET /posts

- **Servicio propietario:** S03
- **Descripción en español:** Consultar trabajos filtrados y perfil
- **Actor autorizado:** Público
- **Entrada:** providerId, categoryId, zone, cursor, limit
- **Respuesta esperada:** 200 lista
- **Reglas de negocio:** Solo publicados; orden por createdAt y _id
- **Entidad / base:** posts / nl_community
- **Diseño del documento o estado:** _id UUID, authorId, providerId, categoryId, title derivado del texto, workDone de 10 a 200 caracteres, publicZone, privateWorkLocation opcional, mediaIds (0..4), moderationRef, status, createdAt, version.
- **Llaves e índices:** PK _id; providerId+status+createdAt+_id; categoryId+status+createdAt+_id.
- **Integridad y privacidad:** Solo prestador propietario, categoría ofrecida, texto 10..200, máximo 4 fotos aprobadas propias. Título derivado de primera oración hasta 60 caracteres. Problema/tiempo no se exigen: sus handlers son residuales, sin controles en el compositor actual. Ubicación del trabajo privada; devolver zona aproximada. Borrado lógico y retiro de medios sin referencias.
- **Paginación y filtros:** Cursor estable + limit 1-50 si devuelve lista. Orden por fecha/secuencia e identificador; no aplicar offset ilimitado.
- **Caché:** Caché solo de DTO público. Catálogo 24 h, perfil 60 s, búsqueda 30 s; invalidación por versión/evento. Geo sin ubicación privada en caché público.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: consultar trabajos filtrados y perfil. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** V.home, V.profile work
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-033 GET /posts/{id}

- **Servicio propietario:** S03
- **Descripción en español:** Abrir detalle de trabajo
- **Actor autorizado:** Público
- **Entrada:** id
- **Respuesta esperada:** 200 trabajo
- **Reglas de negocio:** No exponer domicilio donde se realizó
- **Entidad / base:** posts / nl_community
- **Diseño del documento o estado:** _id UUID, authorId, providerId, categoryId, title derivado del texto, workDone de 10 a 200 caracteres, publicZone, privateWorkLocation opcional, mediaIds (0..4), moderationRef, status, createdAt, version.
- **Llaves e índices:** PK _id; providerId+status+createdAt+_id; categoryId+status+createdAt+_id.
- **Integridad y privacidad:** Solo prestador propietario, categoría ofrecida, texto 10..200, máximo 4 fotos aprobadas propias. Título derivado de primera oración hasta 60 caracteres. Problema/tiempo no se exigen: sus handlers son residuales, sin controles en el compositor actual. Ubicación del trabajo privada; devolver zona aproximada. Borrado lógico y retiro de medios sin referencias.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** Caché solo de DTO público. Catálogo 24 h, perfil 60 s, búsqueda 30 s; invalidación por versión/evento. Geo sin ubicación privada en caché público.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: abrir detalle de trabajo. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** workSheet
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-034 PATCH /posts/{id}

- **Servicio propietario:** S03
- **Descripción en español:** Corregir contenido de trabajo
- **Actor autorizado:** Autor
- **Entrada:** Campos editables, If-Match
- **Respuesta esperada:** 200 publicación actualizada
- **Reglas de negocio:** Volver a moderar cambios; conservar versión anterior solo según política
- **Entidad / base:** posts / nl_community
- **Diseño del documento o estado:** _id UUID, authorId, providerId, categoryId, title derivado del texto, workDone de 10 a 200 caracteres, publicZone, privateWorkLocation opcional, mediaIds (0..4), moderationRef, status, createdAt, version.
- **Llaves e índices:** PK _id; providerId+status+createdAt+_id; categoryId+status+createdAt+_id.
- **Integridad y privacidad:** Solo prestador propietario, categoría ofrecida, texto 10..200, máximo 4 fotos aprobadas propias. Título derivado de primera oración hasta 60 caracteres. Problema/tiempo no se exigen: sus handlers son residuales, sin controles en el compositor actual. Ubicación del trabajo privada; devolver zona aproximada. Borrado lógico y retiro de medios sin referencias.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: corregir contenido de trabajo. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Complemento CRUD
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-035 DELETE /posts/{id}

- **Servicio propietario:** S03
- **Descripción en español:** Retirar trabajo
- **Actor autorizado:** Autor o moderador
- **Entrada:** id, If-Match
- **Respuesta esperada:** 204
- **Reglas de negocio:** Ocultar feed e invalidar caché; purgar medios que queden sin referencias
- **Entidad / base:** posts / nl_community
- **Diseño del documento o estado:** _id UUID, authorId, providerId, categoryId, title derivado del texto, workDone de 10 a 200 caracteres, publicZone, privateWorkLocation opcional, mediaIds (0..4), moderationRef, status, createdAt, version.
- **Llaves e índices:** PK _id; providerId+status+createdAt+_id; categoryId+status+createdAt+_id.
- **Integridad y privacidad:** Solo prestador propietario, categoría ofrecida, texto 10..200, máximo 4 fotos aprobadas propias. Título derivado de primera oración hasta 60 caracteres. Problema/tiempo no se exigen: sus handlers son residuales, sin controles en el compositor actual. Ubicación del trabajo privada; devolver zona aproximada. Borrado lógico y retiro de medios sin referencias.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: retirar trabajo. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Complemento CRUD
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-036 PUT /reactions/{type}/{id}

- **Servicio propietario:** S03
- **Descripción en español:** Recomendar trabajo o perfil
- **Actor autorizado:** Cuenta
- **Entrada:** type, id
- **Respuesta esperada:** 200 estado recomendado
- **Reglas de negocio:** Una reacción por cuenta/objetivo; tipo validado; no contador libre
- **Entidad / base:** reactions / nl_community
- **Diseño del documento o estado:** Colección reactions en nl_community: _id, userId, targetType, targetId y createdAt. Una recomendación por usuario y objetivo.
- **Llaves e índices:** PK _id; UQ userId+targetType+targetId; userId+targetType+createdAt+_id.
- **Integridad y privacidad:** Solo dueño lista guardados. PUT crea o conserva; DELETE retira idempotentemente. Agregados derivados, nunca contador alterable libremente por cliente.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: recomendar trabajo o perfil. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** rec
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-037 DELETE /reactions/{type}/{id}

- **Servicio propietario:** S03
- **Descripción en español:** Retirar recomendación
- **Actor autorizado:** Autor de reacción
- **Entrada:** type, id
- **Respuesta esperada:** 204
- **Reglas de negocio:** Idempotente; recalcular agregados por evento
- **Entidad / base:** reactions / nl_community
- **Diseño del documento o estado:** Colección reactions en nl_community: _id, userId, targetType, targetId y createdAt. Una recomendación por usuario y objetivo.
- **Llaves e índices:** PK _id; UQ userId+targetType+targetId; userId+targetType+createdAt+_id.
- **Integridad y privacidad:** Solo dueño lista guardados. PUT crea o conserva; DELETE retira idempotentemente. Agregados derivados, nunca contador alterable libremente por cliente.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: retirar recomendación. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** rec
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-038 GET /me/saved

- **Servicio propietario:** S03
- **Descripción en español:** Consultar prestadores, trabajos o solicitudes guardados
- **Actor autorizado:** Propietario
- **Entrada:** type, cursor, limit
- **Respuesta esperada:** 200 lista
- **Reglas de negocio:** Autorización al hidratar cada recurso; mostrar retirado cuando aplique
- **Entidad / base:** saved / nl_community
- **Diseño del documento o estado:** _id UUID, userId, targetType provider/post/request, targetId, createdAt. Reacciones usan colección reactions: userId, targetType, targetId, createdAt.
- **Llaves e índices:** PK _id; UQ userId+targetType+targetId; userId+targetType+createdAt+_id.
- **Integridad y privacidad:** Solo dueño lista guardados. PUT crea o conserva; DELETE retira idempotentemente. Agregados derivados, nunca contador alterable libremente por cliente.
- **Paginación y filtros:** Cursor estable + limit 1-50 si devuelve lista. Orden por fecha/secuencia e identificador; no aplicar offset ilimitado.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: consultar prestadores, trabajos o solicitudes guardados. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** V.saved
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-039 PUT /me/saved/{type}/{id}

- **Servicio propietario:** S03
- **Descripción en español:** Guardar objetivo
- **Actor autorizado:** Propietario
- **Entrada:** type provider/post/request, id
- **Respuesta esperada:** 201 o 200
- **Reglas de negocio:** Restricción única; verificar visibilidad del objetivo
- **Entidad / base:** saved / nl_community
- **Diseño del documento o estado:** _id UUID, userId, targetType provider/post/request, targetId, createdAt. Reacciones usan colección reactions: userId, targetType, targetId, createdAt.
- **Llaves e índices:** PK _id; UQ userId+targetType+targetId; userId+targetType+createdAt+_id.
- **Integridad y privacidad:** Solo dueño lista guardados. PUT crea o conserva; DELETE retira idempotentemente. Agregados derivados, nunca contador alterable libremente por cliente.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: guardar objetivo. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** savep, savew, saver
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-040 DELETE /me/saved/{type}/{id}

- **Servicio propietario:** S03
- **Descripción en español:** Quitar guardado
- **Actor autorizado:** Propietario
- **Entrada:** type, id
- **Respuesta esperada:** 204
- **Reglas de negocio:** Idempotente y sincronizable offline
- **Entidad / base:** saved / nl_community
- **Diseño del documento o estado:** _id UUID, userId, targetType provider/post/request, targetId, createdAt. Reacciones usan colección reactions: userId, targetType, targetId, createdAt.
- **Llaves e índices:** PK _id; UQ userId+targetType+targetId; userId+targetType+createdAt+_id.
- **Integridad y privacidad:** Solo dueño lista guardados. PUT crea o conserva; DELETE retira idempotentemente. Agregados derivados, nunca contador alterable libremente por cliente.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: quitar guardado. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** savep, savew, saver
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-041 POST /reviews

- **Servicio propietario:** S03
- **Descripción en español:** Publicar experiencia o calificación
- **Actor autorizado:** Cuenta
- **Entrada:** providerId obligatorio, text 10..280, recommends booleano, stars entero 1..5, orderId opcional
- **Respuesta esperada:** 201 experiencia con tipo de evidencia
- **Reglas de negocio:** Pedido done propio para registeredOrder; no autoevaluación; verificar prestador activo, un solo destinatario y campos obligatorios también en servidor; outbox review.upserted con versión.
- **Entidad / base:** reviews / nl_community
- **Diseño del documento o estado:** _id UUID, authorId, providerId obligatorio (una mención estructurada), orderId opcional, kind declared/registeredOrder, text de 10 a 280 caracteres, recommends booleano, stars entero obligatorio 1..5, moderationRef, status, createdAt, version.
- **Llaves e índices:** PK _id; UQ parcial orderId cuando existe; providerId+status+createdAt+_id; authorId+createdAt+_id.
- **Integridad y privacidad:** No autoevaluación. Selección por providerId, nunca por texto @nombre. Si orderId existe, validar dueño y done en S04 y mantener su providerId. Una opinión por pedido. Para experiencia declarada se permite corregir providerId validado; emitir retiro de la relación anterior y nueva relación en un evento versionado. No certificar experiencias declaradas.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: publicar experiencia o calificación. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** publishexp, mreview
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-042 GET /providers/{id}/reviews

- **Servicio propietario:** S03
- **Descripción en español:** Consultar opiniones y resumen
- **Actor autorizado:** Público
- **Entrada:** id, kind opcional, cursor, limit
- **Respuesta esperada:** 200 experiencias y agregados
- **Reglas de negocio:** Distinguir declarado de pedido registrado; no inflar contadores
- **Entidad / base:** reviews / nl_community
- **Diseño del documento o estado:** _id UUID, authorId, providerId obligatorio (una mención estructurada), orderId opcional, kind declared/registeredOrder, text de 10 a 280 caracteres, recommends booleano, stars entero obligatorio 1..5, moderationRef, status, createdAt, version.
- **Llaves e índices:** PK _id; UQ parcial orderId cuando existe; providerId+status+createdAt+_id; authorId+createdAt+_id.
- **Integridad y privacidad:** No autoevaluación. Selección por providerId, nunca por texto @nombre. Si orderId existe, validar dueño y done en S04 y mantener su providerId. Una opinión por pedido. Para experiencia declarada se permite corregir providerId validado; emitir retiro de la relación anterior y nueva relación en un evento versionado. No certificar experiencias declaradas.
- **Paginación y filtros:** Cursor estable + limit 1-50 si devuelve lista. Orden por fecha/secuencia e identificador; no aplicar offset ilimitado.
- **Caché:** Caché solo de DTO público. Catálogo 24 h, perfil 60 s, búsqueda 30 s; invalidación por versión/evento. Geo sin ubicación privada en caché público.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: consultar opiniones y resumen. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** V.profile trust
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-043 PATCH /reviews/{id}

- **Servicio propietario:** S03
- **Descripción en español:** Corregir experiencia
- **Actor autorizado:** Autor
- **Entrada:** text 10..280, recommends, stars 1..5, providerId solo para declared, If-Match
- **Respuesta esperada:** 200 experiencia
- **Reglas de negocio:** Moderar de nuevo y recalcular agregados; no cambiar autor/pedido; en registeredOrder providerId queda ligado al pedido; snapshot reemplaza relaciones de mención/recomendación anteriores.
- **Entidad / base:** reviews / nl_community
- **Diseño del documento o estado:** _id UUID, authorId, providerId obligatorio (una mención estructurada), orderId opcional, kind declared/registeredOrder, text de 10 a 280 caracteres, recommends booleano, stars entero obligatorio 1..5, moderationRef, status, createdAt, version.
- **Llaves e índices:** PK _id; UQ parcial orderId cuando existe; providerId+status+createdAt+_id; authorId+createdAt+_id.
- **Integridad y privacidad:** No autoevaluación. Selección por providerId, nunca por texto @nombre. Si orderId existe, validar dueño y done en S04 y mantener su providerId. Una opinión por pedido. Para experiencia declarada se permite corregir providerId validado; emitir retiro de la relación anterior y nueva relación en un evento versionado. No certificar experiencias declaradas.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: corregir experiencia. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Complemento CRUD
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-044 DELETE /reviews/{id}

- **Servicio propietario:** S03
- **Descripción en español:** Retirar experiencia
- **Actor autorizado:** Autor o moderador
- **Entrada:** id, If-Match
- **Respuesta esperada:** 204
- **Reglas de negocio:** Actualizar promedio y recomendaciones; auditar retiro administrativo
- **Entidad / base:** reviews / nl_community
- **Diseño del documento o estado:** _id UUID, authorId, providerId obligatorio (una mención estructurada), orderId opcional, kind declared/registeredOrder, text de 10 a 280 caracteres, recommends booleano, stars entero obligatorio 1..5, moderationRef, status, createdAt, version.
- **Llaves e índices:** PK _id; UQ parcial orderId cuando existe; providerId+status+createdAt+_id; authorId+createdAt+_id.
- **Integridad y privacidad:** No autoevaluación. Selección por providerId, nunca por texto @nombre. Si orderId existe, validar dueño y done en S04 y mantener su providerId. Una opinión por pedido. Para experiencia declarada se permite corregir providerId validado; emitir retiro de la relación anterior y nueva relación en un evento versionado. No certificar experiencias declaradas.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: retirar experiencia. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Complemento CRUD
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-045 POST /interactions

- **Servicio propietario:** S03
- **Descripción en español:** Registrar vista, compartir o intención de contacto
- **Actor autorizado:** Público limitado o cuenta
- **Entrada:** eventId, providerId, kind
- **Respuesta esperada:** 202
- **Reglas de negocio:** Minimizar datos; idempotente; no equiparar clic con servicio realizado
- **Entidad / base:** metrics / nl_community
- **Diseño del documento o estado:** _id UUID para evento mínimo, providerId, kind view/contact/share, actorPseudonym opcional, occurredAt; agregados diarios con counts.
- **Llaves e índices:** PK _id; TTL de eventos crudos según política; UQ providerId+day en agregado.
- **Integridad y privacidad:** Registrar intención y visitas, no contratación ni ingreso. Minimizar identificadores y evitar doble conteo por reintentos.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: registrar vista, compartir o intención de contacto. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** share, contact, stats
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-046 GET /me/provider/metrics

- **Servicio propietario:** S03
- **Descripción en español:** Consultar actividad de su perfil
- **Actor autorizado:** Prestador propietario
- **Entrada:** from, to, máximo 90 días
- **Respuesta esperada:** 200 agregados
- **Reglas de negocio:** Sin identidad de visitantes ni datos privados
- **Entidad / base:** metrics / nl_community
- **Diseño del documento o estado:** _id UUID para evento mínimo, providerId, kind view/contact/share, actorPseudonym opcional, occurredAt; agregados diarios con counts.
- **Llaves e índices:** PK _id; TTL de eventos crudos según política; UQ providerId+day en agregado.
- **Integridad y privacidad:** Registrar intención y visitas, no contratación ni ingreso. Minimizar identificadores y evitar doble conteo por reintentos.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: consultar actividad de su perfil. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** V.account stats
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-047 POST /requests

- **Servicio propietario:** S04
- **Descripción en español:** Publicar necesidad de servicio
- **Actor autorizado:** Solicitante
- **Entrada:** categoryId, description, privateLocation, publicZone, urgency, contactPreference
- **Respuesta esperada:** 201 solicitud
- **Reglas de negocio:** Texto moderado mínimo diez caracteres; no mostrar teléfono público; máximo 280 caracteres; contactPreference chat/both.
- **Entidad / base:** requests / nl_orders
- **Diseño del documento o estado:** _id UUID, ownerId, categoryId, description, publicZone, privateLocation, urgency, contactPreference, status open/assigned/closed, selectedProviderId, activeOrderId, createdAt, version. Filtros separados: ownerOnly (propias), matchMyServices (coincidencia de categoría), withinMyCoverage y urgency=Hoy. No interpretar urgente hoy como createdAt de hoy.
- **Llaves e índices:** PK _id; 2dsphere privateLocation; categoryId+status+createdAt+_id; ownerId+createdAt+_id.
- **Integridad y privacidad:** Consulta pública entrega solo zona aproximada. Publicar exige cuenta, categoría y diez caracteres. Solicitud cerrada no admite interés ni nuevos pedidos. Asignación se modifica dentro de S04. Texto máximo 280. contactPreference chat/both; no divulgar número con chat. S04 mantiene la preferencia vigente del pedido; cambios en una solicitud vinculada se propagan en la misma transacción local.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: publicar necesidad de servicio. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** publishreq
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-048 GET /requests

- **Servicio propietario:** S04
- **Descripción en español:** Consultar solicitudes de zona y capacidad
- **Actor autorizado:** Prestador o visitante público limitado
- **Entrada:** categoryId, zone, ownerOnly, matchMyServices, withinMyCoverage, urgency=Hoy, includeOutsideCoverage explícito, cursor, limit
- **Respuesta esperada:** 200 DTO sin domicilio/teléfono
- **Reglas de negocio:** ownerOnly requiere sesión; matchMyServices compara categorías del perfil sin confundir propiedad. urgency=Hoy filtra urgencia, no antigüedad. Respuesta fuera de cobertura etiquetada y por ampliación explícita. Nunca domicilio ni teléfono público.
- **Entidad / base:** requests / nl_orders
- **Diseño del documento o estado:** _id UUID, ownerId, categoryId, description, publicZone, privateLocation, urgency, contactPreference, status open/assigned/closed, selectedProviderId, activeOrderId, createdAt, version. Filtros separados: ownerOnly (propias), matchMyServices (coincidencia de categoría), withinMyCoverage y urgency=Hoy. No interpretar urgente hoy como createdAt de hoy.
- **Llaves e índices:** PK _id; 2dsphere privateLocation; categoryId+status+createdAt+_id; ownerId+createdAt+_id.
- **Integridad y privacidad:** Consulta pública entrega solo zona aproximada. Publicar exige cuenta, categoría y diez caracteres. Solicitud cerrada no admite interés ni nuevos pedidos. Asignación se modifica dentro de S04. Texto máximo 280. contactPreference chat/both; no divulgar número con chat. S04 mantiene la preferencia vigente del pedido; cambios en una solicitud vinculada se propagan en la misma transacción local.
- **Paginación y filtros:** Cursor estable + limit 1-50 si devuelve lista. Orden por fecha/secuencia e identificador; no aplicar offset ilimitado.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: consultar solicitudes de zona y capacidad. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** V.search pro, rfilt
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-049 GET /requests/{id}

- **Servicio propietario:** S04
- **Descripción en español:** Abrir solicitud
- **Actor autorizado:** Público o propietario según campos
- **Entrada:** id
- **Respuesta esperada:** 200 versión pública o propia
- **Reglas de negocio:** Propietario obtiene sus datos privados; otros solo zona
- **Entidad / base:** requests / nl_orders
- **Diseño del documento o estado:** _id UUID, ownerId, categoryId, description, publicZone, privateLocation, urgency, contactPreference, status open/assigned/closed, selectedProviderId, activeOrderId, createdAt, version. Filtros separados: ownerOnly (propias), matchMyServices (coincidencia de categoría), withinMyCoverage y urgency=Hoy. No interpretar urgente hoy como createdAt de hoy.
- **Llaves e índices:** PK _id; 2dsphere privateLocation; categoryId+status+createdAt+_id; ownerId+createdAt+_id.
- **Integridad y privacidad:** Consulta pública entrega solo zona aproximada. Publicar exige cuenta, categoría y diez caracteres. Solicitud cerrada no admite interés ni nuevos pedidos. Asignación se modifica dentro de S04. Texto máximo 280. contactPreference chat/both; no divulgar número con chat. S04 mantiene la preferencia vigente del pedido; cambios en una solicitud vinculada se propagan en la misma transacción local.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** Caché solo de DTO público. Catálogo 24 h, perfil 60 s, búsqueda 30 s; invalidación por versión/evento. Geo sin ubicación privada en caché público.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: abrir solicitud. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** reqopen, reqHTML
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-050 PATCH /requests/{id}

- **Servicio propietario:** S04
- **Descripción en español:** Corregir necesidad abierta
- **Actor autorizado:** Propietario
- **Entrada:** description, urgency, categoryId, location, If-Match, contactPreference chat/both
- **Respuesta esperada:** 200 solicitud
- **Reglas de negocio:** Solo abierta sin asignación; moderación de texto modificado; nunca ampliar acceso a teléfono de pedido fuera de la autorización del cliente.
- **Entidad / base:** requests / nl_orders
- **Diseño del documento o estado:** _id UUID, ownerId, categoryId, description, publicZone, privateLocation, urgency, contactPreference, status open/assigned/closed, selectedProviderId, activeOrderId, createdAt, version. Filtros separados: ownerOnly (propias), matchMyServices (coincidencia de categoría), withinMyCoverage y urgency=Hoy. No interpretar urgente hoy como createdAt de hoy.
- **Llaves e índices:** PK _id; 2dsphere privateLocation; categoryId+status+createdAt+_id; ownerId+createdAt+_id.
- **Integridad y privacidad:** Consulta pública entrega solo zona aproximada. Publicar exige cuenta, categoría y diez caracteres. Solicitud cerrada no admite interés ni nuevos pedidos. Asignación se modifica dentro de S04. Texto máximo 280. contactPreference chat/both; no divulgar número con chat. S04 mantiene la preferencia vigente del pedido; cambios en una solicitud vinculada se propagan en la misma transacción local.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: corregir necesidad abierta. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Complemento CRUD
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-051 POST /requests/{id}/close

- **Servicio propietario:** S04
- **Descripción en español:** Cerrar necesidad ya resuelta
- **Actor autorizado:** Propietario
- **Entrada:** If-Match
- **Respuesta esperada:** 200 estado closed
- **Reglas de negocio:** Si hay pedido ok, exigir resolver/cancelar antes para no contradecirlo
- **Entidad / base:** requests / nl_orders
- **Diseño del documento o estado:** _id UUID, ownerId, categoryId, description, publicZone, privateLocation, urgency, contactPreference, status open/assigned/closed, selectedProviderId, activeOrderId, createdAt, version. Filtros separados: ownerOnly (propias), matchMyServices (coincidencia de categoría), withinMyCoverage y urgency=Hoy. No interpretar urgente hoy como createdAt de hoy.
- **Llaves e índices:** PK _id; 2dsphere privateLocation; categoryId+status+createdAt+_id; ownerId+createdAt+_id.
- **Integridad y privacidad:** Consulta pública entrega solo zona aproximada. Publicar exige cuenta, categoría y diez caracteres. Solicitud cerrada no admite interés ni nuevos pedidos. Asignación se modifica dentro de S04. Texto máximo 280. contactPreference chat/both; no divulgar número con chat. S04 mantiene la preferencia vigente del pedido; cambios en una solicitud vinculada se propagan en la misma transacción local.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: cerrar necesidad ya resuelta. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** closereq
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-052 DELETE /requests/{id}

- **Servicio propietario:** S04
- **Descripción en español:** Retirar solicitud
- **Actor autorizado:** Propietario
- **Entrada:** id, If-Match
- **Respuesta esperada:** 204
- **Reglas de negocio:** No borrar un pedido activo en cascada; ocultar y auditar
- **Entidad / base:** requests / nl_orders
- **Diseño del documento o estado:** _id UUID, ownerId, categoryId, description, publicZone, privateLocation, urgency, contactPreference, status open/assigned/closed, selectedProviderId, activeOrderId, createdAt, version. Filtros separados: ownerOnly (propias), matchMyServices (coincidencia de categoría), withinMyCoverage y urgency=Hoy. No interpretar urgente hoy como createdAt de hoy.
- **Llaves e índices:** PK _id; 2dsphere privateLocation; categoryId+status+createdAt+_id; ownerId+createdAt+_id.
- **Integridad y privacidad:** Consulta pública entrega solo zona aproximada. Publicar exige cuenta, categoría y diez caracteres. Solicitud cerrada no admite interés ni nuevos pedidos. Asignación se modifica dentro de S04. Texto máximo 280. contactPreference chat/both; no divulgar número con chat. S04 mantiene la preferencia vigente del pedido; cambios en una solicitud vinculada se propagan en la misma transacción local.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: retirar solicitud. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Complemento CRUD
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-053 PUT /requests/{id}/interest

- **Servicio propietario:** S04
- **Descripción en español:** Expresar interés
- **Actor autorizado:** Prestador
- **Entrada:** id
- **Respuesta esperada:** 200 interés
- **Reglas de negocio:** Solicitud abierta ajena y perfil activo; una relación única; no impedir por categoría no coincidente: la maqueta permite esa acción; mantener visibilidad y estado como restricciones.
- **Entidad / base:** interests / nl_orders
- **Diseño del documento o estado:** _id UUID, requestId, providerId, createdAt, shortlisted. La propiedad shortlisted se modifica únicamente por dueño de solicitud.
- **Llaves e índices:** PK _id; UQ requestId+providerId; requestId+createdAt; providerId+createdAt.
- **Integridad y privacidad:** Solo perfil activo puede interesarse en solicitud ajena abierta. Retirar no cancela automáticamente pedido existente. La preselección no confirma contratación. Coincidencia de categoría prioriza/filtra resultados, no es un bloqueo de autorización en el alcance visible. Solicitud debe ser abierta, ajena y visible para el prestador; fuera de radio requiere ampliación explícita etiquetada. Mantener UUID real de prestador por cuenta.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: expresar interés. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** reqint
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-054 DELETE /requests/{id}/interest

- **Servicio propietario:** S04
- **Descripción en español:** Retirar interés
- **Actor autorizado:** Prestador interesado
- **Entrada:** id
- **Respuesta esperada:** 204
- **Reglas de negocio:** No alterar asignación existente; retirar relación propia
- **Entidad / base:** interests / nl_orders
- **Diseño del documento o estado:** _id UUID, requestId, providerId, createdAt, shortlisted. La propiedad shortlisted se modifica únicamente por dueño de solicitud.
- **Llaves e índices:** PK _id; UQ requestId+providerId; requestId+createdAt; providerId+createdAt.
- **Integridad y privacidad:** Solo perfil activo puede interesarse en solicitud ajena abierta. Retirar no cancela automáticamente pedido existente. La preselección no confirma contratación. Coincidencia de categoría prioriza/filtra resultados, no es un bloqueo de autorización en el alcance visible. Solicitud debe ser abierta, ajena y visible para el prestador; fuera de radio requiere ampliación explícita etiquetada. Mantener UUID real de prestador por cuenta.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: retirar interés. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** reqint
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-055 GET /requests/{id}/interests

- **Servicio propietario:** S04
- **Descripción en español:** Consultar interesados y ordenar
- **Actor autorizado:** Dueño de solicitud
- **Entrada:** sort rating/recommendations/open, cursor, limit
- **Respuesta esperada:** 200 candidatos
- **Reglas de negocio:** Enriquecer por lote con S02/S03 y mantener cursor estable
- **Entidad / base:** interests / nl_orders
- **Diseño del documento o estado:** _id UUID, requestId, providerId, createdAt, shortlisted. La propiedad shortlisted se modifica únicamente por dueño de solicitud.
- **Llaves e índices:** PK _id; UQ requestId+providerId; requestId+createdAt; providerId+createdAt.
- **Integridad y privacidad:** Solo perfil activo puede interesarse en solicitud ajena abierta. Retirar no cancela automáticamente pedido existente. La preselección no confirma contratación. Coincidencia de categoría prioriza/filtra resultados, no es un bloqueo de autorización en el alcance visible. Solicitud debe ser abierta, ajena y visible para el prestador; fuera de radio requiere ampliación explícita etiquetada. Mantener UUID real de prestador por cuenta.
- **Paginación y filtros:** Cursor estable + limit 1-50 si devuelve lista. Orden por fecha/secuencia e identificador; no aplicar offset ilimitado.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: consultar interesados y ordenar. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** V.ints, intsort
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-056 PUT /requests/{id}/shortlist/{providerId}

- **Servicio propietario:** S04
- **Descripción en español:** [Ampliación opcional] Preseleccionar candidato
- **Actor autorizado:** Dueño de solicitud
- **Entrada:** id, providerId
- **Respuesta esperada:** 200 preselección
- **Reglas de negocio:** Requiere interés existente; no equivale a aceptación
- **Entidad / base:** interests / nl_orders
- **Diseño del documento o estado:** _id UUID, requestId, providerId, createdAt, shortlisted. La propiedad shortlisted se modifica únicamente por dueño de solicitud.
- **Llaves e índices:** PK _id; UQ requestId+providerId; requestId+createdAt; providerId+createdAt.
- **Integridad y privacidad:** Solo perfil activo puede interesarse en solicitud ajena abierta. Retirar no cancela automáticamente pedido existente. La preselección no confirma contratación. Coincidencia de categoría prioriza/filtra resultados, no es un bloqueo de autorización en el alcance visible. Solicitud debe ser abierta, ajena y visible para el prestador; fuera de radio requiere ampliación explícita etiquetada. Mantener UUID real de prestador por cuenta.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: [ampliación opcional] preseleccionar candidato. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Ampliación opcional: reqshort residual, sin control visible en T31
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-057 DELETE /requests/{id}/shortlist/{providerId}

- **Servicio propietario:** S04
- **Descripción en español:** [Ampliación opcional] Quitar preselección
- **Actor autorizado:** Dueño de solicitud
- **Entrada:** id, providerId
- **Respuesta esperada:** 204
- **Reglas de negocio:** Solo dueño; operación idempotente
- **Entidad / base:** interests / nl_orders
- **Diseño del documento o estado:** _id UUID, requestId, providerId, createdAt, shortlisted. La propiedad shortlisted se modifica únicamente por dueño de solicitud.
- **Llaves e índices:** PK _id; UQ requestId+providerId; requestId+createdAt; providerId+createdAt.
- **Integridad y privacidad:** Solo perfil activo puede interesarse en solicitud ajena abierta. Retirar no cancela automáticamente pedido existente. La preselección no confirma contratación. Coincidencia de categoría prioriza/filtra resultados, no es un bloqueo de autorización en el alcance visible. Solicitud debe ser abierta, ajena y visible para el prestador; fuera de radio requiere ampliación explícita etiquetada. Mantener UUID real de prestador por cuenta.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: [ampliación opcional] quitar preselección. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Ampliación opcional: reqshort residual, sin control visible en T31
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-058 POST /orders

- **Servicio propietario:** S04
- **Descripción en español:** Enviar pedido desde perfil, chat o interesado
- **Actor autorizado:** Solicitante
- **Entrada:** providerId, requestId opcional, categoryId, description, mode, privatePlace, clientContactPreference opcional
- **Respuesta esperada:** 201 pedido pend
- **Reglas de negocio:** Idempotency-Key; impedir activos duplicados; verificar interés si origin=post; heredar de solicitud; directo chat por defecto y both solo por consentimiento explícito.
- **Entidad / base:** orders / nl_orders
- **Diseño del documento o estado:** _id UUID, requestId opcional, clientId, providerId, categoryId, description, origin, mode, privatePlace, publicZone, status pend/ok/done/cancel, active bool, quote {amountMinor,currency,note}, history limitada o colección separada, version, createdAt. clientContactPreference chat/both y contactConsentVersion, heredados de la solicitud o explícitos en pedido directo (chat por defecto).
- **Llaves e índices:** PK _id; clientId+status+createdAt+_id; providerId+status+createdAt+_id; UQ parcial requestId con active=true y requestId existente; UQ parcial clientId+providerId con active=true.
- **Integridad y privacidad:** Cambios condicionales por version. Aceptar y asignar solicitud en transacción local. active=true solo pend/ok. Precio opcional, positivo, en centavos. Domicilio filtrado por actor y estado. Teléfono exige estado ok/done, participante autorizado y consentimiento vigente both; cancelación/revocación lo retira inmediatamente. No depender de una proyección eventual para este permiso.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: enviar pedido desde perfil, chat o interesado. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** agok, reqpick, chatag
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-059 GET /me/orders

- **Servicio propietario:** S04
- **Descripción en español:** Consultar pedidos por modo y estado
- **Actor autorizado:** Participante
- **Entrada:** mode, status, cursor, limit
- **Respuesta esperada:** 200 lista propia
- **Reglas de negocio:** Filtrar clientId o providerId derivado de sesión
- **Entidad / base:** orders / nl_orders
- **Diseño del documento o estado:** _id UUID, requestId opcional, clientId, providerId, categoryId, description, origin, mode, privatePlace, publicZone, status pend/ok/done/cancel, active bool, quote {amountMinor,currency,note}, history limitada o colección separada, version, createdAt. clientContactPreference chat/both y contactConsentVersion, heredados de la solicitud o explícitos en pedido directo (chat por defecto).
- **Llaves e índices:** PK _id; clientId+status+createdAt+_id; providerId+status+createdAt+_id; UQ parcial requestId con active=true y requestId existente; UQ parcial clientId+providerId con active=true.
- **Integridad y privacidad:** Cambios condicionales por version. Aceptar y asignar solicitud en transacción local. active=true solo pend/ok. Precio opcional, positivo, en centavos. Domicilio filtrado por actor y estado. Teléfono exige estado ok/done, participante autorizado y consentimiento vigente both; cancelación/revocación lo retira inmediatamente. No depender de una proyección eventual para este permiso.
- **Paginación y filtros:** Cursor estable + limit 1-50 si devuelve lista. Orden por fecha/secuencia e identificador; no aplicar offset ilimitado.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: consultar pedidos por modo y estado. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** matchCard, V.home
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-060 GET /orders/{id}

- **Servicio propietario:** S04
- **Descripción en español:** Consultar estado y logística autorizada
- **Actor autorizado:** Participante
- **Entrada:** id
- **Respuesta esperada:** 200 pedido filtrado por actor
- **Reglas de negocio:** Domicilio solo según estado y actor; no basta ocultarlo en Flutter
- **Entidad / base:** orders / nl_orders
- **Diseño del documento o estado:** _id UUID, requestId opcional, clientId, providerId, categoryId, description, origin, mode, privatePlace, publicZone, status pend/ok/done/cancel, active bool, quote {amountMinor,currency,note}, history limitada o colección separada, version, createdAt. clientContactPreference chat/both y contactConsentVersion, heredados de la solicitud o explícitos en pedido directo (chat por defecto).
- **Llaves e índices:** PK _id; clientId+status+createdAt+_id; providerId+status+createdAt+_id; UQ parcial requestId con active=true y requestId existente; UQ parcial clientId+providerId con active=true.
- **Integridad y privacidad:** Cambios condicionales por version. Aceptar y asignar solicitud en transacción local. active=true solo pend/ok. Precio opcional, positivo, en centavos. Domicilio filtrado por actor y estado. Teléfono exige estado ok/done, participante autorizado y consentimiento vigente both; cancelación/revocación lo retira inmediatamente. No depender de una proyección eventual para este permiso.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: consultar estado y logística autorizada. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** V.match
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-061 POST /orders/{id}/accept

- **Servicio propietario:** S04
- **Descripción en español:** Aceptar y opcionalmente fijar precio
- **Actor autorizado:** Prestador destinatario
- **Entrada:** quote opcional, If-Match, Idempotency-Key
- **Respuesta esperada:** 200 pedido ok
- **Reglas de negocio:** Transacción pedido+solicitud+outbox; solo pend; dirección después de commit
- **Entidad / base:** orders / nl_orders
- **Diseño del documento o estado:** _id UUID, requestId opcional, clientId, providerId, categoryId, description, origin, mode, privatePlace, publicZone, status pend/ok/done/cancel, active bool, quote {amountMinor,currency,note}, history limitada o colección separada, version, createdAt. clientContactPreference chat/both y contactConsentVersion, heredados de la solicitud o explícitos en pedido directo (chat por defecto).
- **Llaves e índices:** PK _id; clientId+status+createdAt+_id; providerId+status+createdAt+_id; UQ parcial requestId con active=true y requestId existente; UQ parcial clientId+providerId con active=true.
- **Integridad y privacidad:** Cambios condicionales por version. Aceptar y asignar solicitud en transacción local. active=true solo pend/ok. Precio opcional, positivo, en centavos. Domicilio filtrado por actor y estado. Teléfono exige estado ok/done, participante autorizado y consentimiento vigente both; cancelación/revocación lo retira inmediatamente. No depender de una proyección eventual para este permiso.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: aceptar y opcionalmente fijar precio. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** mquoteok, mAccept
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-062 POST /orders/{id}/reject

- **Servicio propietario:** S04
- **Descripción en español:** Rechazar pedido pendiente
- **Actor autorizado:** Prestador destinatario
- **Entrada:** If-Match
- **Respuesta esperada:** 200 pedido cancel
- **Reglas de negocio:** Liberar referencia de solicitud y retirar acceso privado
- **Entidad / base:** orders / nl_orders
- **Diseño del documento o estado:** _id UUID, requestId opcional, clientId, providerId, categoryId, description, origin, mode, privatePlace, publicZone, status pend/ok/done/cancel, active bool, quote {amountMinor,currency,note}, history limitada o colección separada, version, createdAt. clientContactPreference chat/both y contactConsentVersion, heredados de la solicitud o explícitos en pedido directo (chat por defecto).
- **Llaves e índices:** PK _id; clientId+status+createdAt+_id; providerId+status+createdAt+_id; UQ parcial requestId con active=true y requestId existente; UQ parcial clientId+providerId con active=true.
- **Integridad y privacidad:** Cambios condicionales por version. Aceptar y asignar solicitud en transacción local. active=true solo pend/ok. Precio opcional, positivo, en centavos. Domicilio filtrado por actor y estado. Teléfono exige estado ok/done, participante autorizado y consentimiento vigente both; cancelación/revocación lo retira inmediatamente. No depender de una proyección eventual para este permiso.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: rechazar pedido pendiente. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** mrejectok
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-063 POST /orders/{id}/cancel

- **Servicio propietario:** S04
- **Descripción en español:** Cancelar servicio activo
- **Actor autorizado:** Cliente o prestador participante
- **Entrada:** reason opcional, If-Match
- **Respuesta esperada:** 200 pedido cancel
- **Reglas de negocio:** Solo pend/ok; invalidar autorización de domicilio y emitir evento
- **Entidad / base:** orders / nl_orders
- **Diseño del documento o estado:** _id UUID, requestId opcional, clientId, providerId, categoryId, description, origin, mode, privatePlace, publicZone, status pend/ok/done/cancel, active bool, quote {amountMinor,currency,note}, history limitada o colección separada, version, createdAt. clientContactPreference chat/both y contactConsentVersion, heredados de la solicitud o explícitos en pedido directo (chat por defecto).
- **Llaves e índices:** PK _id; clientId+status+createdAt+_id; providerId+status+createdAt+_id; UQ parcial requestId con active=true y requestId existente; UQ parcial clientId+providerId con active=true.
- **Integridad y privacidad:** Cambios condicionales por version. Aceptar y asignar solicitud en transacción local. active=true solo pend/ok. Precio opcional, positivo, en centavos. Domicilio filtrado por actor y estado. Teléfono exige estado ok/done, participante autorizado y consentimiento vigente both; cancelación/revocación lo retira inmediatamente. No depender de una proyección eventual para este permiso.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: cancelar servicio activo. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** mcancelok
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-064 POST /orders/{id}/complete

- **Servicio propietario:** S04
- **Descripción en español:** Declarar servicio resuelto
- **Actor autorizado:** Prestador destinatario
- **Entrada:** If-Match
- **Respuesta esperada:** 200 pedido done
- **Reglas de negocio:** Solo ok; cerrar solicitud y habilitar calificación del cliente
- **Entidad / base:** orders / nl_orders
- **Diseño del documento o estado:** _id UUID, requestId opcional, clientId, providerId, categoryId, description, origin, mode, privatePlace, publicZone, status pend/ok/done/cancel, active bool, quote {amountMinor,currency,note}, history limitada o colección separada, version, createdAt. clientContactPreference chat/both y contactConsentVersion, heredados de la solicitud o explícitos en pedido directo (chat por defecto).
- **Llaves e índices:** PK _id; clientId+status+createdAt+_id; providerId+status+createdAt+_id; UQ parcial requestId con active=true y requestId existente; UQ parcial clientId+providerId con active=true.
- **Integridad y privacidad:** Cambios condicionales por version. Aceptar y asignar solicitud en transacción local. active=true solo pend/ok. Precio opcional, positivo, en centavos. Domicilio filtrado por actor y estado. Teléfono exige estado ok/done, participante autorizado y consentimiento vigente both; cancelación/revocación lo retira inmediatamente. No depender de una proyección eventual para este permiso.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: declarar servicio resuelto. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** mdoneok
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-065 PATCH /orders/{id}/address

- **Servicio propietario:** S04
- **Descripción en español:** Cambiar punto y referencias del servicio
- **Actor autorizado:** Cliente del pedido
- **Entrada:** privatePlace, If-Match
- **Respuesta esperada:** 200 pedido
- **Reglas de negocio:** Solo pend/ok; notificar cambio; no aceptar direcciones ajenas en evento público
- **Entidad / base:** orders / nl_orders
- **Diseño del documento o estado:** _id UUID, requestId opcional, clientId, providerId, categoryId, description, origin, mode, privatePlace, publicZone, status pend/ok/done/cancel, active bool, quote {amountMinor,currency,note}, history limitada o colección separada, version, createdAt. clientContactPreference chat/both y contactConsentVersion, heredados de la solicitud o explícitos en pedido directo (chat por defecto).
- **Llaves e índices:** PK _id; clientId+status+createdAt+_id; providerId+status+createdAt+_id; UQ parcial requestId con active=true y requestId existente; UQ parcial clientId+providerId con active=true.
- **Integridad y privacidad:** Cambios condicionales por version. Aceptar y asignar solicitud en transacción local. active=true solo pend/ok. Precio opcional, positivo, en centavos. Domicilio filtrado por actor y estado. Teléfono exige estado ok/done, participante autorizado y consentimiento vigente both; cancelación/revocación lo retira inmediatamente. No depender de una proyección eventual para este permiso.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: cambiar punto y referencias del servicio. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** maddr
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-066 POST /conversations

- **Servicio propietario:** S05
- **Descripción en español:** Abrir o recuperar conversación por pareja
- **Actor autorizado:** Cliente o prestador habilitado
- **Entrada:** providerId o orderId, requestId opcional
- **Respuesta esperada:** 201 nueva o 200 existente
- **Reglas de negocio:** Prestador inicia solo tras asignación; comprobar bloques y membresía; consultar chatEnabled actual para nueva conversación; acceso por rol/contexto autorizado.
- **Entidad / base:** conversations / nl_messaging
- **Diseño del documento o estado:** _id UUID, clientId, providerId, contextRequestId opcional, lastSequence, lastMessageAt, readState por miembro, createdAt, version. activeOrderId opcional derivado de S04 y contextHistoryRefs acotada/paginada; nunca reemplazar contexto de mensajes anteriores por el último pedido.
- **Llaves e índices:** PK _id; UQ clientId+providerId; clientId+lastMessageAt+_id; providerId+lastMessageAt+_id.
- **Integridad y privacidad:** La pareja conserva orientación cliente/prestador. Un usuario puede participar en ambos papeles sin mezclar conversaciones. No usar nombre como llave.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: abrir o recuperar conversación por pareja. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** msgto, msgreq, mchat
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-067 GET /me/conversations

- **Servicio propietario:** S05
- **Descripción en español:** Listar bandeja y no leídos por modo
- **Actor autorizado:** Participante
- **Entrada:** mode, unreadOnly, cursor, limit
- **Respuesta esperada:** 200 conversaciones propias
- **Reglas de negocio:** No exponer conversaciones de otro modo/miembro
- **Entidad / base:** conversations / nl_messaging
- **Diseño del documento o estado:** _id UUID, clientId, providerId, contextRequestId opcional, lastSequence, lastMessageAt, readState por miembro, createdAt, version. activeOrderId opcional derivado de S04 y contextHistoryRefs acotada/paginada; nunca reemplazar contexto de mensajes anteriores por el último pedido.
- **Llaves e índices:** PK _id; UQ clientId+providerId; clientId+lastMessageAt+_id; providerId+lastMessageAt+_id.
- **Integridad y privacidad:** La pareja conserva orientación cliente/prestador. Un usuario puede participar en ambos papeles sin mezclar conversaciones. No usar nombre como llave.
- **Paginación y filtros:** Cursor estable + limit 1-50 si devuelve lista. Orden por fecha/secuencia e identificador; no aplicar offset ilimitado.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: listar bandeja y no leídos por modo. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** V.inbox, inf
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-068 GET /conversations/{id}/messages

- **Servicio propietario:** S05
- **Descripción en español:** Recuperar historial o mensajes tras desconexión
- **Actor autorizado:** Miembro
- **Entrada:** before/after cursor, limit
- **Respuesta esperada:** 200 mensajes y secuencia
- **Reglas de negocio:** Autorización en cada página; adjuntos privados bajo control
- **Entidad / base:** messages / nl_messaging
- **Diseño del documento o estado:** _id UUID, conversationId, senderId, clientMessageId UUID, sequence, kind text/image/system, text o mediaId, moderationRef, eventId opcional, createdAt. Contexto opcional autorizado: requestId, orderId y contextVersion; el mensaje conserva su contexto aunque cambie el pedido activo de la pareja. Texto 1..600 caracteres tras trim.
- **Llaves e índices:** PK _id; UQ conversationId+clientMessageId; UQ conversationId+sequence; UQ parcial eventId para avisos; conversationId+sequence para cursor.
- **Integridad y privacidad:** Solo miembros sin bloqueo efectivo. Persistir después de moderación. Secuencia asignada atómicamente y confirmación con id real. No arreglos ilimitados de mensajes en conversación.
- **Paginación y filtros:** Cursor estable + limit 1-50 si devuelve lista. Orden por fecha/secuencia e identificador; no aplicar offset ilimitado.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: recuperar historial o mensajes tras desconexión. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** V.chat
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-069 POST /conversations/{id}/messages

- **Servicio propietario:** S05
- **Descripción en español:** Enviar texto o foto aprobados
- **Actor autorizado:** Miembro sin bloqueo
- **Entrada:** clientMessageId, text o mediaId, requestId/orderId opcionales autorizados
- **Respuesta esperada:** 201 mensaje con id/sequence
- **Reglas de negocio:** Moderar antes de persistir; retry devuelve mismo mensaje; no respuesta simulada; texto 1..600; respuesta rápida y manual comparten SendMessage sin sobrescribir el texto seleccionado.
- **Entidad / base:** messages / nl_messaging
- **Diseño del documento o estado:** _id UUID, conversationId, senderId, clientMessageId UUID, sequence, kind text/image/system, text o mediaId, moderationRef, eventId opcional, createdAt. Contexto opcional autorizado: requestId, orderId y contextVersion; el mensaje conserva su contexto aunque cambie el pedido activo de la pareja. Texto 1..600 caracteres tras trim.
- **Llaves e índices:** PK _id; UQ conversationId+clientMessageId; UQ conversationId+sequence; UQ parcial eventId para avisos; conversationId+sequence para cursor.
- **Integridad y privacidad:** Solo miembros sin bloqueo efectivo. Persistir después de moderación. Secuencia asignada atómicamente y confirmación con id real. No arreglos ilimitados de mensajes en conversación.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: enviar texto o foto aprobados. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** msgsend, msgquick, chatfile
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-070 PUT /conversations/{id}/read

- **Servicio propietario:** S05
- **Descripción en español:** Marcar lectura hasta secuencia
- **Actor autorizado:** Miembro
- **Entrada:** lastReadSequence
- **Respuesta esperada:** 204
- **Reglas de negocio:** Monótono; no avanzar más allá de mensaje disponible
- **Entidad / base:** conversations / nl_messaging
- **Diseño del documento o estado:** _id UUID, clientId, providerId, contextRequestId opcional, lastSequence, lastMessageAt, readState por miembro, createdAt, version. activeOrderId opcional derivado de S04 y contextHistoryRefs acotada/paginada; nunca reemplazar contexto de mensajes anteriores por el último pedido.
- **Llaves e índices:** PK _id; UQ clientId+providerId; clientId+lastMessageAt+_id; providerId+lastMessageAt+_id.
- **Integridad y privacidad:** La pareja conserva orientación cliente/prestador. Un usuario puede participar en ambos papeles sin mezclar conversaciones. No usar nombre como llave.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: marcar lectura hasta secuencia. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** chatOpen, unreadAll
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-071 PUT /conversations/{id}/block

- **Servicio propietario:** S05
- **Descripción en español:** Bloquear a contraparte
- **Actor autorizado:** Miembro
- **Entrada:** id
- **Respuesta esperada:** 204
- **Reglas de negocio:** Revalidar bloqueo al enviar; no solo silenciar UI
- **Entidad / base:** blocks / nl_messaging
- **Diseño del documento o estado:** _id UUID, blockerId, blockedId, conversationId, createdAt.
- **Llaves e índices:** PK _id; UQ blockerId+blockedId; blockedId+createdAt.
- **Integridad y privacidad:** Solo quien bloqueó puede desbloquear. Cualquiera de las dos direcciones bloquea nuevos envíos; conservar historial autorizado.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: bloquear a contraparte. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** chatblock
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-072 DELETE /conversations/{id}/block

- **Servicio propietario:** S05
- **Descripción en español:** Desbloquear contraparte
- **Actor autorizado:** Autor del bloqueo
- **Entrada:** id
- **Respuesta esperada:** 204
- **Reglas de negocio:** No retirar bloqueo impuesto por la otra persona
- **Entidad / base:** blocks / nl_messaging
- **Diseño del documento o estado:** _id UUID, blockerId, blockedId, conversationId, createdAt.
- **Llaves e índices:** PK _id; UQ blockerId+blockedId; blockedId+createdAt.
- **Integridad y privacidad:** Solo quien bloqueó puede desbloquear. Cualquiera de las dos direcciones bloquea nuevos envíos; conservar historial autorizado.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: desbloquear contraparte. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** chatblock
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-073 POST /realtime/ticket

- **Servicio propietario:** S01
- **Descripción en español:** Emitir ticket de conexión WebSocket
- **Actor autorizado:** Cuenta autenticada
- **Entrada:** deviceId
- **Respuesta esperada:** 200 ticket de un uso, 30 segundos
- **Reglas de negocio:** Guardar hash/TTL en Redis de seguridad; no JWT en URL duradera
- **Entidad / base:** sessions / nl_identity
- **Diseño del documento o estado:** _id sid, userId, deviceId, refreshHash, familyId, generation, status, expiresAt, revokedAt, version. Historial de hashes gastados para detectar reutilización.
- **Llaves e índices:** PK sid; UQ refreshHash; userId+status; TTL expiresAt con retención acordada.
- **Integridad y privacidad:** Rotación atómica y detección de replay. Redis conserva revocación/ticket/contador con TTL; MongoDB mantiene verdad durable.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: emitir ticket de conexión websocket. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Requisito tiempo real
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-074 WS /ws/v1/chat

- **Servicio propietario:** S05
- **Descripción en español:** Recibir avisos de mensajes y pedidos
- **Actor autorizado:** Ticket y membresía vigentes
- **Entrada:** ticket, suscripciones autorizadas, typing/read
- **Respuesta esperada:** Eventos versionados con cursor y acuse
- **Reglas de negocio:** Validar membresía, sesión y bloqueos durante conexión; reanudar por REST
- **Entidad / base:** messages / nl_messaging
- **Diseño del documento o estado:** _id UUID, conversationId, senderId, clientMessageId UUID, sequence, kind text/image/system, text o mediaId, moderationRef, eventId opcional, createdAt. Contexto opcional autorizado: requestId, orderId y contextVersion; el mensaje conserva su contexto aunque cambie el pedido activo de la pareja. Texto 1..600 caracteres tras trim.
- **Llaves e índices:** PK _id; UQ conversationId+clientMessageId; UQ conversationId+sequence; UQ parcial eventId para avisos; conversationId+sequence para cursor.
- **Integridad y privacidad:** Solo miembros sin bloqueo efectivo. Persistir después de moderación. Secuencia asignada atómicamente y confirmación con id real. No arreglos ilimitados de mensajes en conversación.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: recibir avisos de mensajes y pedidos. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** V.chat, navBadge
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-075 POST /media

- **Servicio propietario:** S06
- **Descripción en español:** Moderar y registrar imagen
- **Actor autorizado:** Cuenta
- **Entrada:** multipart bytes, purpose, MIME
- **Respuesta esperada:** 201 mediaId aprobado
- **Reglas de negocio:** Sin almacenamiento persistente previo; máximo 3 MB; validar contenido real
- **Entidad / base:** media / nl_trust
- **Diseño del documento o estado:** _id UUID, ownerId, sha256, purpose, mime, size, decisionRef, objectKey, visibility public/private, boundResource, status, createdAt, expiresAt de huérfano.
- **Llaves e índices:** PK _id; ownerId+createdAt; status+expiresAt; hash+purpose como índice no necesariamente único.
- **Integridad y privacidad:** Guardar bytes solo después de aprobación. Autorizar antes de vincular, leer o borrar. Medio de chat privado; sin enlace público permanente. Retirar huérfanos y purgar CDN al eliminar contenido público.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: moderar y registrar imagen. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** obfiles, pfile, myphoto, chatfile
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-076 GET /media/{id}/access

- **Servicio propietario:** S06
- **Descripción en español:** Resolver acceso autorizado a medio
- **Actor autorizado:** Público o miembro según recurso
- **Entrada:** id
- **Respuesta esperada:** 200 URL pública o privada de corta duración
- **Reglas de negocio:** Revalidar boundResource; no entregar URL privada a visitante
- **Entidad / base:** media / nl_trust
- **Diseño del documento o estado:** _id UUID, ownerId, sha256, purpose, mime, size, decisionRef, objectKey, visibility public/private, boundResource, status, createdAt, expiresAt de huérfano.
- **Llaves e índices:** PK _id; ownerId+createdAt; status+expiresAt; hash+purpose como índice no necesariamente único.
- **Integridad y privacidad:** Guardar bytes solo después de aprobación. Autorizar antes de vincular, leer o borrar. Medio de chat privado; sin enlace público permanente. Retirar huérfanos y purgar CDN al eliminar contenido público.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** Caché solo de DTO público. Catálogo 24 h, perfil 60 s, búsqueda 30 s; invalidación por versión/evento. Geo sin ubicación privada en caché público.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: resolver acceso autorizado a medio. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Fotos de perfil/trabajos/chat
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-077 DELETE /media/{id}

- **Servicio propietario:** S06
- **Descripción en español:** Retirar archivo autorizado
- **Actor autorizado:** Propietario o proceso de eliminación
- **Entrada:** id
- **Respuesta esperada:** 204 o 409 si vínculo activo requiere editar recurso
- **Reglas de negocio:** Comprobar referencias y purgar CDN; no borrar medio ajeno
- **Entidad / base:** media / nl_trust
- **Diseño del documento o estado:** _id UUID, ownerId, sha256, purpose, mime, size, decisionRef, objectKey, visibility public/private, boundResource, status, createdAt, expiresAt de huérfano.
- **Llaves e índices:** PK _id; ownerId+createdAt; status+expiresAt; hash+purpose como índice no necesariamente único.
- **Integridad y privacidad:** Guardar bytes solo después de aprobación. Autorizar antes de vincular, leer o borrar. Medio de chat privado; sin enlace público permanente. Retirar huérfanos y purgar CDN al eliminar contenido público.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: retirar archivo autorizado. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** pubimgdel, eliminación
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-078 POST /reports

- **Servicio propietario:** S06
- **Descripción en español:** Reportar perfil, trabajo, experiencia o chat
- **Actor autorizado:** Cuenta
- **Entrada:** targetType, targetId, reasonCode
- **Respuesta esperada:** 201 reportId
- **Reglas de negocio:** Validar acceso al objetivo; no copiar conversación completa a logs
- **Entidad / base:** reports / nl_trust
- **Diseño del documento o estado:** _id UUID, reporterId, targetType, targetId, reasonCode, status open/reviewing/closed, decision, reviewerId, createdAt, version; moderation_decisions almacena metadatos sin contenido rechazado.
- **Llaves e índices:** PK _id; status+createdAt+_id; targetType+targetId+createdAt; reporterId+createdAt.
- **Integridad y privacidad:** Motivo obligatorio y catálogo controlado. Solo moderadores autorizados deciden con auditoría. La ocultación se comunica al propietario por evento.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: reportar perfil, trabajo, experiencia o chat. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** sendreport
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-079 GET /me/reports

- **Servicio propietario:** S06
- **Descripción en español:** Consultar estado de sus reportes
- **Actor autorizado:** Reportante
- **Entrada:** cursor, limit
- **Respuesta esperada:** 200 estado y resolución visible
- **Reglas de negocio:** No exponer identidad del moderador ni datos de terceros innecesarios
- **Entidad / base:** reports / nl_trust
- **Diseño del documento o estado:** _id UUID, reporterId, targetType, targetId, reasonCode, status open/reviewing/closed, decision, reviewerId, createdAt, version; moderation_decisions almacena metadatos sin contenido rechazado.
- **Llaves e índices:** PK _id; status+createdAt+_id; targetType+targetId+createdAt; reporterId+createdAt.
- **Integridad y privacidad:** Motivo obligatorio y catálogo controlado. Solo moderadores autorizados deciden con auditoría. La ocultación se comunica al propietario por evento.
- **Paginación y filtros:** Cursor estable + limit 1-50 si devuelve lista. Orden por fecha/secuencia e identificador; no aplicar offset ilimitado.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: consultar estado de sus reportes. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Complemento de seguimiento
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-080 GET /admin/reports

- **Servicio propietario:** S06
- **Descripción en español:** Listar cola de revisión
- **Actor autorizado:** Moderador
- **Entrada:** status, type, cursor, limit
- **Respuesta esperada:** 200 expedientes autorizados
- **Reglas de negocio:** Acceso administrativo separado; auditoría de consulta sensible
- **Entidad / base:** reports / nl_trust
- **Diseño del documento o estado:** _id UUID, reporterId, targetType, targetId, reasonCode, status open/reviewing/closed, decision, reviewerId, createdAt, version; moderation_decisions almacena metadatos sin contenido rechazado.
- **Llaves e índices:** PK _id; status+createdAt+_id; targetType+targetId+createdAt; reporterId+createdAt.
- **Integridad y privacidad:** Motivo obligatorio y catálogo controlado. Solo moderadores autorizados deciden con auditoría. La ocultación se comunica al propietario por evento.
- **Paginación y filtros:** Cursor estable + limit 1-50 si devuelve lista. Orden por fecha/secuencia e identificador; no aplicar offset ilimitado.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: listar cola de revisión. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Operación de moderación
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-081 POST /admin/reports/{id}/decision

- **Servicio propietario:** S06
- **Descripción en español:** Resolver y ordenar ocultación o restauración
- **Actor autorizado:** Moderador
- **Entrada:** decision, rationale, If-Match
- **Respuesta esperada:** 200 decisión y evento
- **Reglas de negocio:** No escribir base ajena; propietario aplica evento idempotente
- **Entidad / base:** reports / nl_trust
- **Diseño del documento o estado:** _id UUID, reporterId, targetType, targetId, reasonCode, status open/reviewing/closed, decision, reviewerId, createdAt, version; moderation_decisions almacena metadatos sin contenido rechazado.
- **Llaves e índices:** PK _id; status+createdAt+_id; targetType+targetId+createdAt; reporterId+createdAt.
- **Integridad y privacidad:** Motivo obligatorio y catálogo controlado. Solo moderadores autorizados deciden con auditoría. La ocultación se comunica al propietario por evento.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: resolver y ordenar ocultación o restauración. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Operación de moderación
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-082 POST /assist/draft

- **Servicio propietario:** S06
- **Descripción en español:** Generar borrador editable de solicitud o trabajo
- **Actor autorizado:** Cuenta limitada
- **Entrada:** kind, categoryId, userText, lengthLimit
- **Respuesta esperada:** 200 draft y modelVersion
- **Reglas de negocio:** No persistir texto por defecto; sin datos precisos; moderar salida
- **Entidad / base:** Sin colección de borradores; Redis de cuota y telemetría mínima
- **Diseño del documento o estado:** No se guarda el texto de entrada/salida por defecto. Solo métricas mínimas de operación: traceId, modelo, tokens, latencia y resultado. Redis lleva contador por usuario/día.
- **Llaves e índices:** Redis: quota:assist:{userId}:{date}, TTL acotado. Sin colección CRUD de borradores en el servidor.
- **Integridad y privacidad:** El usuario revisa y edita la salida. La publicación es otra operación con moderación y autorización.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: generar borrador editable de solicitud o trabajo. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Adición obligatoria IA generativa
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-083 PUT /me/devices/{id}

- **Servicio propietario:** S07
- **Descripción en español:** Registrar token push y preferencias
- **Actor autorizado:** Propietario
- **Entrada:** token, platform, preferences
- **Respuesta esperada:** 200 dispositivo
- **Reglas de negocio:** Asociado a sid actual; token único; rotación
- **Entidad / base:** devices / nl_notifications
- **Diseño del documento o estado:** _id UUID, userId, sessionId, token, platform, preferences, updatedAt, status.
- **Llaves e índices:** PK _id; UQ token; userId+status; sessionId.
- **Integridad y privacidad:** Asociar a sesión actual, invalidar token anterior y eliminar al logout. No exponer tokens en cliente ajeno o logs.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: registrar token push y preferencias. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Requisito push
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-084 DELETE /me/devices/{id}

- **Servicio propietario:** S07
- **Descripción en español:** Desvincular push del dispositivo
- **Actor autorizado:** Propietario
- **Entrada:** id
- **Respuesta esperada:** 204
- **Reglas de negocio:** Idempotente; no afectar otro usuario
- **Entidad / base:** devices / nl_notifications
- **Diseño del documento o estado:** _id UUID, userId, sessionId, token, platform, preferences, updatedAt, status.
- **Llaves e índices:** PK _id; UQ token; userId+status; sessionId.
- **Integridad y privacidad:** Asociar a sesión actual, invalidar token anterior y eliminar al logout. No exponer tokens en cliente ajeno o logs.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: desvincular push del dispositivo. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Logout/push
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-085 GET /me/notifications

- **Servicio propietario:** S07
- **Descripción en español:** Consultar notificaciones persistentes
- **Actor autorizado:** Propietario
- **Entrada:** cursor, limit, unreadOnly
- **Respuesta esperada:** 200 lista
- **Reglas de negocio:** Payload mínimo, acceso al destino se revalida al abrir
- **Entidad / base:** notifications / nl_notifications
- **Diseño del documento o estado:** _id UUID, userId, eventId, kind, resourceId, readAt, createdAt; deliveries registra intento, resultado y próximo reintento.
- **Llaves e índices:** PK _id; UQ userId+eventId; userId+createdAt+_id; deliveries.status+nextAttemptAt.
- **Integridad y privacidad:** Consultar propiedad y revalidar recurso al abrir. Push es aviso; la bandeja persistente refleja el evento. No prometer entrega exactamente una vez.
- **Paginación y filtros:** Cursor estable + limit 1-50 si devuelve lista. Orden por fecha/secuencia e identificador; no aplicar offset ilimitado.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: consultar notificaciones persistentes. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** notifSheet, bell
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-086 PUT /me/notifications/{id}/read

- **Servicio propietario:** S07
- **Descripción en español:** Marcar aviso leído
- **Actor autorizado:** Propietario
- **Entrada:** id
- **Respuesta esperada:** 204
- **Reglas de negocio:** Solo aviso propio, idempotente
- **Entidad / base:** notifications / nl_notifications
- **Diseño del documento o estado:** _id UUID, userId, eventId, kind, resourceId, readAt, createdAt; deliveries registra intento, resultado y próximo reintento.
- **Llaves e índices:** PK _id; UQ userId+eventId; userId+createdAt+_id; deliveries.status+nextAttemptAt.
- **Integridad y privacidad:** Consultar propiedad y revalidar recurso al abrir. Push es aviso; la bandeja persistente refleja el evento. No prometer entrega exactamente una vez.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: marcar aviso leído. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** seenotif
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-087 POST /internal/moderation/check

- **Servicio propietario:** S06
- **Descripción en español:** Moderar texto de una operación de negocio
- **Actor autorizado:** Identidad de servicio autorizada
- **Entrada:** content, hash, purpose, userId
- **Respuesta esperada:** 200 decisión/proof o 422 rechazo
- **Reglas de negocio:** API interna, sin persistir contenido rechazado ni log de cuerpo
- **Entidad / base:** moderation_decisions / nl_trust
- **Diseño del documento o estado:** moderation_decisions: _id, hash, purpose, policyVersion, decision, occurredAt. No almacenar contenido rechazado. Comprobante ligado a bytes, usuario y propósito.
- **Llaves e índices:** PK _id; status+createdAt+_id; targetType+targetId+createdAt; reporterId+createdAt.
- **Integridad y privacidad:** Motivo obligatorio y catálogo controlado. Solo moderadores autorizados deciden con auditoría. La ocultación se comunica al propietario por evento.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: moderar texto de una operación de negocio. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Requisito 16
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-088 GET /internal/orders/{id}/review-eligibility

- **Servicio propietario:** S04
- **Descripción en español:** Verificar opinión vinculada a pedido
- **Actor autorizado:** Identidad S03
- **Entrada:** id, actorId
- **Respuesta esperada:** 200 elegibilidad y versión
- **Reglas de negocio:** Devuelve solo pertenencia/done/providerId, nunca domicilio
- **Entidad / base:** orders / nl_orders
- **Diseño del documento o estado:** _id UUID, requestId opcional, clientId, providerId, categoryId, description, origin, mode, privatePlace, publicZone, status pend/ok/done/cancel, active bool, quote {amountMinor,currency,note}, history limitada o colección separada, version, createdAt. clientContactPreference chat/both y contactConsentVersion, heredados de la solicitud o explícitos en pedido directo (chat por defecto).
- **Llaves e índices:** PK _id; clientId+status+createdAt+_id; providerId+status+createdAt+_id; UQ parcial requestId con active=true y requestId existente; UQ parcial clientId+providerId con active=true.
- **Integridad y privacidad:** Cambios condicionales por version. Aceptar y asignar solicitud en transacción local. active=true solo pend/ok. Precio opcional, positivo, en centavos. Domicilio filtrado por actor y estado. Teléfono exige estado ok/done, participante autorizado y consentimiento vigente both; cancelación/revocación lo retira inmediatamente. No depender de una proyección eventual para este permiso.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: verificar opinión vinculada a pedido. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** publishexp con pedido
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-089 GET /health/live

- **Servicio propietario:** Transversal
- **Descripción en español:** Comprobar proceso vivo
- **Actor autorizado:** Infraestructura interna
- **Entrada:** Ninguna
- **Respuesta esperada:** 200 sin detalles sensibles
- **Reglas de negocio:** No consultar todas las dependencias en liveness
- **Entidad / base:** Sin datos de negocio persistentes
- **Diseño del documento o estado:** Sin entidad persistente de negocio. Se consulta estado del proceso y, para readiness, dependencias indispensables.
- **Llaves e índices:** No aplica.
- **Integridad y privacidad:** Restringir a infraestructura; no exponer cadenas de conexión, versiones privadas ni secretos.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: comprobar proceso vivo. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Operación
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-090 GET /health/ready

- **Servicio propietario:** Transversal
- **Descripción en español:** Comprobar capacidad de servir tráfico
- **Actor autorizado:** Infraestructura interna
- **Entrada:** Ninguna
- **Respuesta esperada:** 200 o 503
- **Reglas de negocio:** Comprobar dependencias indispensables del servicio, no datos de usuario
- **Entidad / base:** Sin datos de negocio persistentes
- **Diseño del documento o estado:** Sin entidad persistente de negocio. Se consulta estado del proceso y, para readiness, dependencias indispensables.
- **Llaves e índices:** No aplica.
- **Integridad y privacidad:** Restringir a infraestructura; no exponer cadenas de conexión, versiones privadas ni secretos.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: comprobar capacidad de servir tráfico. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Operación
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-091 GET /providers/{id}/contact

- **Servicio propietario:** S02
- **Descripción en español:** Obtener número del prestador para copiar
- **Actor autorizado:** Cuenta autenticada
- **Entrada:** id
- **Respuesta esperada:** 200 teléfono y canales autorizados
- **Reglas de negocio:** Respuesta privada sin caché compartida; número validado por identidad; no mezclar en DTO público cacheable; exigir showPhone=true vigente; no confiar solo en canal visible en Flutter.
- **Entidad / base:** providers / nl_directory
- **Diseño del documento o estado:** _id UUID, userId, type persona/negocio, name, bio, categoryIds, specialties, serviceLabels, mode dom/local/ambos, privateOrigin GeoJSON, publicZone, publicBusinessLocation opcional, radiusKm, schedule, timeZone, visitPrice, prices, paymentMethods, warrantyText, responseText, urgent, mediaIds, confirmedPhone, status, version. Campos visibles adicionales: ownerDisplayName, experienceLabel (declarada), sectorId/otherSector, activity, otherCategoryLabel, otherSpecialtyLabel, team, crew, materialsPolicy, invoiceDeclared, website, portfolioMediaIds (hasta seis fotos en registro), avatarMediaId, coverMediaId; contactPreferences {chatEnabled, showPhone}. priceItems: hasta tres filas visibles iniciales con serviceKey opcional de catálogo, label, amountMinor, currency, pricingMode from/fixed/quote, unit y includesMaterials; no inferir unidad ausente. Respuesta propia: completeness {policyVersion,percent,missingFields}; opportunitySummary {matchingOpen,allVisibleOpen,withMyInterest}. Respuesta pública: portfolioPhotoCount, publishedPostCount, completedOrderCount, recommendationsCount separados.
- **Llaves e índices:** PK _id; UQ userId; 2dsphere privateOrigin; categoryIds+status+updatedAt; tokens normalizados; status+_id. Medir planes con multikey.
- **Integridad y privacidad:** No publicar privateOrigin. La dirección comercial exacta requiere intención explícita. Condiciones y experiencia son declaradas. Actualizaciones con If-Match y moderación. Responsable visible no sustituye a userId. Facturación es declaración comercial, no emisión de facturas. radio=0 permitido para modalidad solo local; dom/ambos exigen radio positivo. URLs HTTP(S) validadas. Completitud derivada, no editable. Una política propuesta de completitud: siete criterios con igual peso (teléfono confirmado, nombre/categoría/bio válidos, cobertura/modalidad válida, horario, precio/visita, foto de perfil, al menos tres publicaciones activas). percent=round(100*n/7). Condiciones y portada no alteran esa primera política; registrar su versión y ratificar criterio con producto. Las fotos del registro no cuentan como publicaciones ni como pedidos completados.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: obtener número del prestador para copiar. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** contactSheet, copy
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-092 GET /orders/{id}/contact

- **Servicio propietario:** S04
- **Descripción en español:** Obtener contacto privado de la contraparte
- **Actor autorizado:** Participante habilitado
- **Entrada:** id
- **Respuesta esperada:** 200 teléfono autorizado
- **Reglas de negocio:** Cliente: teléfono del prestador solo con showPhone vigente. Prestador: teléfono del cliente solo asignado en ok/done y clientContactPreference=both vigente. Cancelado o revocado: 403/404. No caché de contacto; comprobación autoritativa.
- **Entidad / base:** orders / nl_orders
- **Diseño del documento o estado:** _id UUID, requestId opcional, clientId, providerId, categoryId, description, origin, mode, privatePlace, publicZone, status pend/ok/done/cancel, active bool, quote {amountMinor,currency,note}, history limitada o colección separada, version, createdAt. clientContactPreference chat/both y contactConsentVersion, heredados de la solicitud o explícitos en pedido directo (chat por defecto).
- **Llaves e índices:** PK _id; clientId+status+createdAt+_id; providerId+status+createdAt+_id; UQ parcial requestId con active=true y requestId existente; UQ parcial clientId+providerId con active=true.
- **Integridad y privacidad:** Cambios condicionales por version. Aceptar y asignar solicitud en transacción local. active=true solo pend/ok. Precio opcional, positivo, en centavos. Domicilio filtrado por actor y estado. Teléfono exige estado ok/done, participante autorizado y consentimiento vigente both; cancelación/revocación lo retira inmediatamente. No depender de una proyección eventual para este permiso.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: obtener contacto privado de la contraparte. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** chatmenu, V.match, copy
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-093 GET /mentions/suggestions

- **Servicio propietario:** S02
- **Descripción en español:** Buscar prestador para mencionar en una experiencia
- **Actor autorizado:** Cuenta autenticada
- **Entrada:** q opcional normalizado sin @, lat/lng para vacío, limit 1..5
- **Respuesta esperada:** 200 id, nombre, avatar, oficio y zona aproximada
- **Reglas de negocio:** Excluir perfil propio/inactivo; sin q sugerir cobertura cercana; con q buscar nombre/oficio sin imponer cercanía, como mresHTML. Sin teléfono ni coordenadas privadas. Búsqueda infija debe preservar resultados mediante índice/adaptador medido; no sustituirla silenciosamente por solo prefijo.
- **Entidad / base:** providers / nl_directory
- **Diseño del documento o estado:** _id UUID, userId, type persona/negocio, name, bio, categoryIds, specialties, serviceLabels, mode dom/local/ambos, privateOrigin GeoJSON, publicZone, publicBusinessLocation opcional, radiusKm, schedule, timeZone, visitPrice, prices, paymentMethods, warrantyText, responseText, urgent, mediaIds, confirmedPhone, status, version. Campos visibles adicionales: ownerDisplayName, experienceLabel (declarada), sectorId/otherSector, activity, otherCategoryLabel, otherSpecialtyLabel, team, crew, materialsPolicy, invoiceDeclared, website, portfolioMediaIds (hasta seis fotos en registro), avatarMediaId, coverMediaId; contactPreferences {chatEnabled, showPhone}. priceItems: hasta tres filas visibles iniciales con serviceKey opcional de catálogo, label, amountMinor, currency, pricingMode from/fixed/quote, unit y includesMaterials; no inferir unidad ausente. Respuesta propia: completeness {policyVersion,percent,missingFields}; opportunitySummary {matchingOpen,allVisibleOpen,withMyInterest}. Respuesta pública: portfolioPhotoCount, publishedPostCount, completedOrderCount, recommendationsCount separados.
- **Llaves e índices:** PK _id; UQ userId; 2dsphere privateOrigin; categoryIds+status+updatedAt; tokens normalizados; status+_id. Medir planes con multikey.
- **Integridad y privacidad:** No publicar privateOrigin. La dirección comercial exacta requiere intención explícita. Condiciones y experiencia son declaradas. Actualizaciones con If-Match y moderación. Responsable visible no sustituye a userId. Facturación es declaración comercial, no emisión de facturas. radio=0 permitido para modalidad solo local; dom/ambos exigen radio positivo. URLs HTTP(S) validadas. Completitud derivada, no editable. Una política propuesta de completitud: siete criterios con igual peso (teléfono confirmado, nombre/categoría/bio válidos, cobertura/modalidad válida, horario, precio/visita, foto de perfil, al menos tres publicaciones activas). percent=round(100*n/7). Condiciones y portada no alteran esa primera política; registrar su versión y ratificar criterio con producto. Las fotos del registro no cuentan como publicaciones ni como pedidos completados.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: buscar prestador para mencionar en una experiencia. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** mresHTML, mentionHTML, exptag
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-094 GET /me/reviews

- **Servicio propietario:** S03
- **Descripción en español:** Listar experiencias propias
- **Actor autorizado:** Autor autenticado
- **Entrada:** cursor, limit, status opcional
- **Respuesta esperada:** 200 experiencias propias y nextCursor
- **Reglas de negocio:** Filtrar authorId del JWT; incluir prestador y estado visible al autor; sin depender del nombre Tú.; caso de aceptación obligatorio: Ana publica, logout, Carlos entra y no la obtiene como propia.
- **Entidad / base:** reviews / nl_community
- **Diseño del documento o estado:** _id UUID, authorId, providerId obligatorio (una mención estructurada), orderId opcional, kind declared/registeredOrder, text de 10 a 280 caracteres, recommends booleano, stars entero obligatorio 1..5, moderationRef, status, createdAt, version.
- **Llaves e índices:** PK _id; UQ parcial orderId cuando existe; providerId+status+createdAt+_id; authorId+createdAt+_id.
- **Integridad y privacidad:** No autoevaluación. Selección por providerId, nunca por texto @nombre. Si orderId existe, validar dueño y done en S04 y mantener su providerId. Una opinión por pedido. Para experiencia declarada se permite corregir providerId validado; emitir retiro de la relación anterior y nueva relación en un evento versionado. No certificar experiencias declaradas.
- **Paginación y filtros:** Cursor estable + limit 1-50 si devuelve lista. Orden por fecha/secuencia e identificador; no aplicar offset ilimitado.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: listar experiencias propias. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** V.myprofile, mtab
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-095 GET /reviews/{id}

- **Servicio propietario:** S03
- **Descripción en español:** Abrir experiencia individual y su prestador
- **Actor autorizado:** Público o autor según estado
- **Entrada:** id
- **Respuesta esperada:** 200 DTO público o propio; 404 si no visible
- **Reglas de negocio:** Complemento de navegación: necesario para enlace estable/notificación propuesta, no pantalla individual confirmada en maqueta.
- **Entidad / base:** reviews / nl_community
- **Diseño del documento o estado:** _id UUID, authorId, providerId obligatorio (una mención estructurada), orderId opcional, kind declared/registeredOrder, text de 10 a 280 caracteres, recommends booleano, stars entero obligatorio 1..5, moderationRef, status, createdAt, version.
- **Llaves e índices:** PK _id; UQ parcial orderId cuando existe; providerId+status+createdAt+_id; authorId+createdAt+_id.
- **Integridad y privacidad:** No autoevaluación. Selección por providerId, nunca por texto @nombre. Si orderId existe, validar dueño y done en S04 y mantener su providerId. Una opinión por pedido. Para experiencia declarada se permite corregir providerId validado; emitir retiro de la relación anterior y nueva relación en un evento versionado. No certificar experiencias declaradas.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** Caché solo de DTO público. Catálogo 24 h, perfil 60 s, búsqueda 30 s; invalidación por versión/evento. Geo sin ubicación privada en caché público.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: abrir experiencia individual y su prestador. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Complemento de contrato para referencias y enlaces
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-096 PATCH /me/provider/contact-preferences

- **Servicio propietario:** S02
- **Descripción en español:** Configurar chat y visibilidad del número
- **Actor autorizado:** Prestador propietario
- **Entrada:** chatEnabled, showPhone, If-Match
- **Respuesta esperada:** 200 preferencias y version
- **Reglas de negocio:** showPhone=false revoca lectura de teléfono inmediatamente. chatEnabled=false impide nuevas conversaciones; propuesta: historial y pedidos activos conservan chat. S05 consulta regla vigente. Alias local wa significa chat interno, no WhatsApp.
- **Entidad / base:** providers / nl_directory
- **Diseño del documento o estado:** _id UUID, userId, type persona/negocio, name, bio, categoryIds, specialties, serviceLabels, mode dom/local/ambos, privateOrigin GeoJSON, publicZone, publicBusinessLocation opcional, radiusKm, schedule, timeZone, visitPrice, prices, paymentMethods, warrantyText, responseText, urgent, mediaIds, confirmedPhone, status, version. Campos visibles adicionales: ownerDisplayName, experienceLabel (declarada), sectorId/otherSector, activity, otherCategoryLabel, otherSpecialtyLabel, team, crew, materialsPolicy, invoiceDeclared, website, portfolioMediaIds (hasta seis fotos en registro), avatarMediaId, coverMediaId; contactPreferences {chatEnabled, showPhone}. priceItems: hasta tres filas visibles iniciales con serviceKey opcional de catálogo, label, amountMinor, currency, pricingMode from/fixed/quote, unit y includesMaterials; no inferir unidad ausente. Respuesta propia: completeness {policyVersion,percent,missingFields}; opportunitySummary {matchingOpen,allVisibleOpen,withMyInterest}. Respuesta pública: portfolioPhotoCount, publishedPostCount, completedOrderCount, recommendationsCount separados.
- **Llaves e índices:** PK _id; UQ userId; 2dsphere privateOrigin; categoryIds+status+updatedAt; tokens normalizados; status+_id. Medir planes con multikey.
- **Integridad y privacidad:** No publicar privateOrigin. La dirección comercial exacta requiere intención explícita. Condiciones y experiencia son declaradas. Actualizaciones con If-Match y moderación. Responsable visible no sustituye a userId. Facturación es declaración comercial, no emisión de facturas. radio=0 permitido para modalidad solo local; dom/ambos exigen radio positivo. URLs HTTP(S) validadas. Completitud derivada, no editable. Una política propuesta de completitud: siete criterios con igual peso (teléfono confirmado, nombre/categoría/bio válidos, cobertura/modalidad válida, horario, precio/visita, foto de perfil, al menos tres publicaciones activas). percent=round(100*n/7). Condiciones y portada no alteran esa primera política; registrar su versión y ratificar criterio con producto. Las fotos del registro no cuentan como publicaciones ni como pedidos completados.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: configurar chat y visibilidad del número. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** V.account, ACT.chan
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-097 PATCH /orders/{id}/contact-preference

- **Servicio propietario:** S04
- **Descripción en español:** Dar o retirar permiso para compartir su teléfono
- **Actor autorizado:** Cliente propietario del pedido
- **Entrada:** contactPreference chat/both, If-Match
- **Respuesta esperada:** 200 preferencia y version
- **Reglas de negocio:** Ampliación de privacidad: en pend/ok/done permite revocar; cancel no admite conceder. Cambiar a both no revela teléfono antes de ok. S04 es autoridad y retira cachés de contacto.
- **Entidad / base:** orders / nl_orders
- **Diseño del documento o estado:** _id UUID, requestId opcional, clientId, providerId, categoryId, description, origin, mode, privatePlace, publicZone, status pend/ok/done/cancel, active bool, quote {amountMinor,currency,note}, history limitada o colección separada, version, createdAt. clientContactPreference chat/both y contactConsentVersion, heredados de la solicitud o explícitos en pedido directo (chat por defecto).
- **Llaves e índices:** PK _id; clientId+status+createdAt+_id; providerId+status+createdAt+_id; UQ parcial requestId con active=true y requestId existente; UQ parcial clientId+providerId con active=true.
- **Integridad y privacidad:** Cambios condicionales por version. Aceptar y asignar solicitud en transacción local. active=true solo pend/ok. Precio opcional, positivo, en centavos. Domicilio filtrado por actor y estado. Teléfono exige estado ok/done, participante autorizado y consentimiento vigente both; cancelación/revocación lo retira inmediatamente. No depender de una proyección eventual para este permiso.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: dar o retirar permiso para compartir su teléfono. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** CH_OPT y corrección de ACT.chatmenu
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-098 POST /graphql/social/v1

- **Servicio propietario:** S08
- **Descripción en español:** Consultar contexto y candidatos relacionados del grafo
- **Actor autorizado:** Cuenta autenticada; consultas acotadas
- **Entrada:** operationName permitido, variables tipadas, hash de operación registrada; first 1..20
- **Respuesta esperada:** 200 data/errors, generatedAt, stale; error explícito o fallback REST disponible
- **Reglas de negocio:** Extensión opcional de lectura, sin mutations ni Cypher arbitrario. Authorization por recurso/campo, dos saltos y profundidad propuesta 4; máximo 100 objetos, una operación y timeout 2 s. Coste y rate limit por usuario. No caché compartida de datos personalizados.
- **Entidad / base:** social_graph / nl_social_graph (Neo4j)
- **Diseño del documento o estado:** Nodos AccountRef, Provider, WorkPost, Experience, Category con id estable, sourceService, sourceVersion y status público. AccountRef contiene identificador seudónimo, nunca teléfono, dirección o credenciales. Relaciones AUTHORED (AccountRef→Experience), PUBLISHED (Provider→WorkPost), ABOUT_PROVIDER (Experience→Provider), RECOMMENDS (Experience→Provider solo recommends=true), OFFERS (Provider→Category), IN_CATEGORY (WorkPost→Category) y REACTED_TO (AccountRef→WorkPost, restringida al procesamiento interno). No inferir amistades por una mención.
- **Llaves e índices:** Unicidad id por etiqueta, índices Provider.status y Category.id según consultas medidas. Relaciones con id lógico determinista (origen,tipo,destino,sourceId), creadas con MERGE dentro de transacciones y consumidor serializado por agregado; no asumir que MERGE solo impide carreras. Ledger SourceState: clave sourceService:aggregateId única y última versión; ProcessedEvent id único. Restricciones exactas según edición elegida.
- **Integridad y privacidad:** Solo S08 escribe la proyección. Cada snapshot versionado reemplaza relaciones salientes administradas por ese agregado; elimina aristas obsoletas al cambiar prestador/recomendación. Transacción incluye efecto, SourceState e inbox. Tombstones rechazan eventos antiguos después del borrado. Autorización y visibilidad se revalidan en S01/S02/S03 antes de devolver datos; nunca revelar identidades de co-recomendadores ni usar conexiones privadas para inferir confianza.
- **Paginación y filtros:** first 1..20 y after cursor opaco ligado a consulta/snapshot; nextCursor en respuesta. Snapshot vencido exige reiniciar. Máximo 100 objetos y dos saltos por consulta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Lectura sin mutation ni efecto de negocio. Reintento acotado con el mismo cursor/snapshot. La ingestión de eventos tiene su propia transacción inbox + proyección.
- **Errores previstos:** 400 documento/variables inválidos; 401/403 acceso; 413 tamaño; 429 cuota; 503 dependencia. Respuesta GraphQL puede contener data y errors con codes RESOURCE_UNAVAILABLE, SNAPSHOT_EXPIRED o QUERY_LIMIT; nunca confundir error con lista vacía.
- **Prueba de aceptación:** Ejecutar operaciones registradas, paginar sin duplicados, rechazar profundidad/costo excedidos y consultas no registradas. Eliminar un proveedor durante lectura y verificar exclusión; simular caída del grafo y comprobar fallback explícito sin impedir menciones REST.
- **Referencia funcional:** Propuesta S08; operaciones SocialProviderContext y RelatedProviders
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-099 GET /catalog/report-reasons

- **Servicio propietario:** S06
- **Descripción en español:** Obtener motivos y política vigente de reporte
- **Actor autorizado:** Cuenta autenticada
- **Entrada:** locale es-MX, version opcional
- **Respuesta esperada:** 200 reasonCodes activos y policyVersion, ETag
- **Reglas de negocio:** Complemento de contrato: frontend y backend comparten catálogo versionado de motivos; no recopilar datos privados en etiquetas.
- **Entidad / base:** reports / nl_trust
- **Diseño del documento o estado:** _id UUID, reporterId, targetType, targetId, reasonCode, status open/reviewing/closed, decision, reviewerId, createdAt, version; moderation_decisions almacena metadatos sin contenido rechazado.
- **Llaves e índices:** PK _id; status+createdAt+_id; targetType+targetId+createdAt; reporterId+createdAt.
- **Integridad y privacidad:** Motivo obligatorio y catálogo controlado. Solo moderadores autorizados deciden con auditoría. La ocultación se comunica al propietario por evento.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: obtener motivos y política vigente de reporte. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Reportar: seis motivos visibles; normalización de catálogo
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-100 GET /internal/providers/{id}/contact-policy

- **Servicio propietario:** S02
- **Descripción en español:** Comprobar política actual de contacto del prestador
- **Actor autorizado:** Identidad S04/S05 autorizada
- **Entrada:** providerId y contexto autenticado de servicio
- **Respuesta esperada:** 200 chatEnabled, showPhone, status, policyVersion; sin teléfono
- **Reglas de negocio:** Solo servicios permitidos; S05 verifica antes de nueva conversación y S04 antes de contacto. No conceder por caché obsoleta; dependencia caída niega divulgación.
- **Entidad / base:** providers / nl_directory
- **Diseño del documento o estado:** _id UUID, userId, type persona/negocio, name, bio, categoryIds, specialties, serviceLabels, mode dom/local/ambos, privateOrigin GeoJSON, publicZone, publicBusinessLocation opcional, radiusKm, schedule, timeZone, visitPrice, prices, paymentMethods, warrantyText, responseText, urgent, mediaIds, confirmedPhone, status, version. Campos visibles adicionales: ownerDisplayName, experienceLabel (declarada), sectorId/otherSector, activity, otherCategoryLabel, otherSpecialtyLabel, team, crew, materialsPolicy, invoiceDeclared, website, portfolioMediaIds (hasta seis fotos en registro), avatarMediaId, coverMediaId; contactPreferences {chatEnabled, showPhone}. priceItems: hasta tres filas visibles iniciales con serviceKey opcional de catálogo, label, amountMinor, currency, pricingMode from/fixed/quote, unit y includesMaterials; no inferir unidad ausente. Respuesta propia: completeness {policyVersion,percent,missingFields}; opportunitySummary {matchingOpen,allVisibleOpen,withMyInterest}. Respuesta pública: portfolioPhotoCount, publishedPostCount, completedOrderCount, recommendationsCount separados.
- **Llaves e índices:** PK _id; UQ userId; 2dsphere privateOrigin; categoryIds+status+updatedAt; tokens normalizados; status+_id. Medir planes con multikey.
- **Integridad y privacidad:** No publicar privateOrigin. La dirección comercial exacta requiere intención explícita. Condiciones y experiencia son declaradas. Actualizaciones con If-Match y moderación. Responsable visible no sustituye a userId. Facturación es declaración comercial, no emisión de facturas. radio=0 permitido para modalidad solo local; dom/ambos exigen radio positivo. URLs HTTP(S) validadas. Completitud derivada, no editable. Una política propuesta de completitud: siete criterios con igual peso (teléfono confirmado, nombre/categoría/bio válidos, cobertura/modalidad válida, horario, precio/visita, foto de perfil, al menos tres publicaciones activas). percent=round(100*n/7). Condiciones y portada no alteran esa primera política; registrar su versión y ratificar criterio con producto. Las fotos del registro no cuentan como publicaciones ni como pedidos completados.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: comprobar política actual de contacto del prestador. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Regla autoritativa para EP-066/091/092/096
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

### EP-101 POST /internal/accounts/visibility-batch

- **Servicio propietario:** S01
- **Descripción en español:** Revalidar visibilidad de autores antes de publicar resultados derivados
- **Actor autorizado:** Identidad S02/S03/S08 autorizada
- **Entrada:** Hasta 50 accountIds y purpose permitido
- **Respuesta esperada:** 200 id, canAppearPublicly y statusVersion; sin PII
- **Reglas de negocio:** Consulta interna de lectura, no mutation. Si hay borrado/suspensión, excluir autor y recursos según política del propietario; no devolver teléfono, secreto o ubicación. No log del cuerpo.
- **Entidad / base:** accounts / nl_identity
- **Diseño del documento o estado:** Una cuenta por persona responsable: _id UUID, phoneE164, passwordHash, displayName, requesterProfile, providerId opcional, preferences, consentVersions, status, createdAt, updatedAt, version. El hash de contraseña usa un algoritmo adaptativo y sal aleatoria, nunca cifrado reversible. Perfil solicitante: photoMediaId, coverMediaId, privateHomeLocation y publicZone. Resúmenes propios de solicitudes/experiencias/guardados se componen por API; no se alteran desde el cliente.
- **Llaves e índices:** PK _id; UQ phoneE164; status+updatedAt. No devolver passwordHash en DTO.
- **Integridad y privacidad:** Cuenta única con modo solicitante y prestador si tiene perfil. Campos públicos pasan moderación. Datos privados solo al propietario. authorId y namespace de caché siempre se derivan de la identidad autenticada; displayName=Tú o providerId=me nunca son claves reales. Cambio de cuenta purga cachés privados y borradores de otro usuario.
- **Paginación y filtros:** No requiere paginación; conservar límites específicos de entrada y respuesta.
- **Caché:** No cachear respuesta privada ni operaciones de escritura.
- **Concurrencia y reintento:** Idempotency-Key para altas/comandos repetibles, ligada al hash del cuerpo; If-Match donde se indica. PUT/DELETE idempotentes. Eventos con outbox/inbox para cambios distribuidos.
- **Errores previstos:** 400 formato; 401 sesión; 403/404 acceso; 409 duplicado/version/estado; 413 tamaño; 422 validación/moderación; 429 límite; 503 dependencia. Aplicar solo los pertinentes.
- **Prueba de aceptación:** Ejecutar el caso permitido: revalidar visibilidad de autores antes de publicar resultados derivados. Verificar resultado y persistencia indicados. Intentar desde otro usuario, repetir la operación y provocar la condición inválida descrita en reglas; comprobar ausencia de filtración o duplicación.
- **Referencia funcional:** Revalidación del grafo y prevención de mezcla entre cuentas
- **Origen del diseño:** Maqueta V1.00.002-Aprovada.html y lineamientos Móvil v2. Rutas y contratos son propuesta; ampliaciones se señalan explícitamente.
- **Estado:** Diseñado; pendiente de implementación y prueba real.

## Fuentes oficiales

- F01: [Arquitectura de aplicaciones Flutter](https://docs.flutter.dev/app-architecture/guide)
- F02: [Política de soporte .NET](https://dotnet.microsoft.com/en-us/platform/support/policy/dotnet-core)
- F03: [Índices geoespaciales MongoDB 2dsphere](https://www.mongodb.com/docs/manual/core/indexes/index-types/geospatial/2dsphere/)
- F04: [Pruebas de nuevas cuentas personales de Google Play](https://support.google.com/googleplay/android-developer/answer/14151465)
- F05: [Facturación de Azure Container Apps](https://learn.microsoft.com/en-us/azure/container-apps/billing)
- F06: [Precios de Azure Front Door](https://azure.microsoft.com/en-us/pricing/details/frontdoor/)
- F07: [Azure Managed Redis](https://learn.microsoft.com/en-us/azure/redis/overview)
- F08: [Azure AI Content Safety: texto e imagen](https://learn.microsoft.com/en-us/azure/ai-services/content-safety/overview)
- F09: [Firebase Cloud Messaging para Flutter](https://firebase.google.com/docs/cloud-messaging/flutter/get-started)
- F10: [Eliminación de cuenta en Google Play](https://support.google.com/googleplay/android-developer/answer/13327111)
- F11: [Clasificación de imágenes con ML Kit](https://developers.google.com/ml-kit/vision/image-labeling)
- F12: [Modelos hospedados por Azure y disponibilidad](https://learn.microsoft.com/en-us/azure/foundry/foundry-models/concepts/models-sold-directly-by-azure)
- F13: [Azure Queue Storage](https://learn.microsoft.com/en-us/azure/storage/queues/storage-queues-introduction)
- F14: [Servicios de Azure Maps](https://learn.microsoft.com/en-us/azure/azure-maps/about-azure-maps)
- F15: [Configuración de Google Analytics](https://support.google.com/analytics/answer/9304153)
- F16: [Ingress de Azure Container Apps](https://learn.microsoft.com/en-us/azure/container-apps/ingress-overview)
- F17: [Transacciones MongoDB](https://www.mongodb.com/docs/manual/core/transactions/)
- F18: [Semántica de Redis Pub/Sub](https://redis.io/docs/latest/develop/pubsub/)
- F19: [Permiso de notificaciones Android](https://developer.android.com/develop/ui/compose/notifications/notification-permission)
- F20: [Neo4j: modelo de nodos, relaciones y propiedades](https://neo4j.com/docs/getting-started/appendix/graphdb-concepts/)
- F21: [GraphQL: consultas y sistema de tipos](https://graphql.org/learn/)
- F22: [Azure Cosmos DB for Apache Gremlin: visión general](https://learn.microsoft.com/en-us/azure/cosmos-db/gremlin/overview)
- F23: [MongoDB: recorridos con $graphLookup](https://www.mongodb.com/docs/manual/reference/operator/aggregation/graphlookup/)
- F24: [GraphQL: seguridad, operaciones confiables y límites](https://graphql.org/learn/security/)
- F25: [Neo4j GraphQL Library: capa de API sobre el grafo](https://neo4j.com/docs/graphql/current/)