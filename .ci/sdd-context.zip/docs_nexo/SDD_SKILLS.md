# Skills recomendadas para Nexo Local

Investigación: 2026-11-02. Prioridad backend; catálogo de adopción, sin instalaciones ni activación de agentes. No es necesario cargar todas las skills en cada tarea.

## Fuentes y disponibilidad

Se examinó el catálogo local ECC 2.2.3 disponible para esta sesión de Codex, sus SKILL.md y las dependencias/ejemplos que podrían contradecir Nexo. El [repositorio del autor](https://github.com/affaan-m/ECC) es la fuente de distribución; su rama principal puede diferir de la copia local. No se declara que Claude Code tenga instalado ECC: su disponibilidad debe comprobarse por separado.

La [especificación Agent Skills](https://agentskills.io/specification) define un directorio con SKILL.md y metadatos name/description. [Codex](https://learn.chatgpt.com/docs/customization/overview#skills) documenta skills de proyecto en .agents/skills; [Claude Code](https://code.claude.com/docs/en/skills) documenta .claude/skills. Compartir formato no garantiza compatibilidad de comandos, herramientas, frontmatter adicional o scripts. Fuentes oficiales consultadas el 02/11/2026.

## Selección priorizada

Los enlaces abren el SKILL.md del autor. Revisar el contenido de la revisión que se vaya a adoptar, no instalar toda la colección por esta tabla.

| Prioridad | Skill / fuente | Aplicación | Adaptación o límite Nexo |
|---|---|---|---|
| Ahora | [docs-governance](https://github.com/affaan-m/ECC/blob/main/skills/docs-governance/SKILL.md) | Conciliar SDD y docs vivos en ambos contextos | Es un enrutador; cargar solo la rama pertinente. No crear otros archivos de gobierno que dupliquen la constitución |
| Ahora | [architecture-decision-records](https://github.com/affaan-m/ECC/blob/main/skills/architecture-decision-records/SKILL.md) | Registrar decisiones técnicas y alternativas | Distinguir propuesta/aceptada con revisor real. Sus ejemplos PostgreSQL no son decisiones Nexo |
| Ahora | [contract-first](https://github.com/affaan-m/ECC/blob/main/skills/contract-first/SKILL.md) | Frontera API–Flutter y eventos | Una autoridad en API; no generar modelos ni instalar generadores todavía |
| Ahora | [api-design](https://github.com/affaan-m/ECC/blob/main/skills/api-design/SKILL.md) | Revisar recursos, errores, filtros y paginación | No renombrar las 101 rutas automáticamente ni inventar operaciones por botón |
| Ahora y por dominio | [security-review](https://github.com/affaan-m/ECC/blob/main/skills/security-review/SKILL.md) | Amenazas, permisos, sesiones, medios y H01–H12 | Traducir ejemplos JS/SQL/cookies a superficie real; sin pagos ni npm audit por defecto |
| Tras ratificar .NET | [dotnet-patterns](https://github.com/affaan-m/ECC/blob/main/skills/dotnet-patterns/SKILL.md) | Diseño interno de servicios y revisión C# | .NET sigue propuesto; ejemplos SqlOrderRepository/EF no autorizan SQL |
| Al encargar pruebas .NET | [csharp-testing](https://github.com/affaan-m/ECC/blob/main/skills/csharp-testing/SKILL.md) | Unitarias e integración backend | Sustituir ejemplos PostgreSQL/EF por adaptadores NoSQL reales; doble no acredita integración |
| Diseño y futura app | [dart-flutter-patterns](https://github.com/affaan-m/ECC/blob/main/skills/dart-flutter-patterns/SKILL.md) | Estado, async, separación de capas y UI | Flutter confirmado; no ratifica Riverpod/go_router ni versiones; no introduce acceso a BD remota |
| Revisión móvil | [flutter-dart-code-review](https://github.com/affaan-m/ECC/blob/main/skills/flutter-dart-code-review/SKILL.md) | Revisar ciclo de vida, errores, concurrencia y pruebas | Sin código, usar solo criterios de diseño; al implementar revisar almacenamiento y permisos también |
| Diseño de entrega; ejecución posterior | [deployment-patterns](https://github.com/affaan-m/ECC/blob/main/skills/deployment-patterns/SKILL.md) | CI/CD, health/readiness, compatibilidad y rollback | Ejemplos Docker/Node no son pipeline Nexo; dos réplicas, Redis, CDN y costo se verifican con cuenta real |

## Cómo adoptarlas sin duplicar el gobierno

1. Seleccionar solo la skill requerida por la tarea. Para esta fase bastan gobierno, ADR, contratos, API y seguridad; Flutter usa sus criterios de diseño cuando corresponde.
2. Fijar origen, licencia y revisión/commit del contenido elegido; revisar SKILL.md completo y recursos referenciados. Registrar fecha, responsable, permisos, dependencias y motivo. La presencia en un marketplace no acredita seguridad.
3. Comprobar compatibilidad con PowerShell y cada cliente. No ejecutar ejemplos bash/npm contra un proyecto .NET/Flutter inexistente ni asumir que ambos exponen las mismas herramientas.
4. Al autorizar su incorporación, mantener una copia controlada del contenido común y entradas compatibles para cada cliente; validar que cada uno la descubre. Documentar cómo actualizar ambas sin divergencia. No activar hooks, MCP o subagentes implícitos.
5. La constitución y el alcance solicitado prevalecen sobre defaults de la skill. No trasladar umbrales de cobertura, proveedores, SQL/EF o despliegues de sus ejemplos como requisitos.

## Necesidades sin skill especializada seleccionada

MongoDB geoespacial/transaccional, Redis de seguridad, outbox/inbox y moderación previa se definen en planes/contratos con documentación oficial del proveedor cuando se ratifique el stack. No se recomienda una skill de nombre parecido sin revisar su contenido. Neo4j/GraphQL solo se evalúa si S08 se habilita. Una skill personalizada para el flujo Nexo puede valorarse después de usar las existentes; esta revisión no la crea ni instala.

El catálogo cubre procedimientos, no demuestra que el sistema cumpla seguridad, CI/CD o pruebas. Versiones del cliente, instalación en Claude Code y revisión exacta que se adoptará permanecen pendientes.
