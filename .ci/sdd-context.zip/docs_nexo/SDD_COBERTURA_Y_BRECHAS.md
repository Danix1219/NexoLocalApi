# Cobertura y brechas SDD

Revisión: 2026-11-02. Documentación propuesta, sin aprobación humana ni pruebas de producto. Lectura junto con [acuerdo común](SDD_ALINEACION.md).

## Fuentes examinadas y límites

Se consultaron los dos Markdown 1.2.0, el texto extraíble de los tres PDF (propuesta: 43 páginas; arquitectura: 77; lineamientos: 4) y las 116 hojas del XLSX, incluidas sus 101 fichas EP. La extracción de PDF y celdas no acredita fidelidad visual, fórmulas recalculadas, enlaces externos ni una nueva ejecución de la maqueta. Los recorridos de 29/10 son evidencia histórica citada por la auditoría, no pruebas repetidas en esta revisión.

No se inspeccionó código nuevo de aplicación, nube ni Android. El estado inicial contiene 16 fases API y 15 móviles, sin proyectos compilables. Los enlaces históricos al análisis previo no sustituyen las fuentes de docs_nexo ni los documentos vivos actuales.

## Los 19 puntos académicos

Toda fila es cobertura de diseño; aceptación pendiente. Las referencias nv/NNN son IDs de las carpetas respectivas, no estados aprobados.

| Punto | Obligación y criterio de cierre | API | App / coordinación |
|---|---|---|---|
| 01 | Instalar versión firmada desde Play y registrar versión/dispositivo | nv-14 compatibilidad API | 014 canal de prueba, instalación real |
| 02 | Reconstruir requisito→tarea→prueba→resultado por prompts | nv-00/nv-03 | 002/014 evidencia reproducible |
| 03 | Inventariar nube, datos, backend, móvil y landing | nv-01/nv-14 | 001/014; landing es artefacto separado |
| 04 | Conservar funciones visibles y corregir defectos | nv-04..12 | 004..012, M01–M27, prueba por rol |
| 05 | Aplicar SDD y DevSecOps desde cada incremento | nv-00..03 | 001..003, revisión y gates continuos |
| 06 | Desarrollo con agentes y revisión humana | nv-00, protocolo Codex/Claude | 001; registro de herramienta y decisiones |
| 07 | Unitarias, seguridad e integración | nv-03 y cada dominio | 002, unit/widget/integration y dispositivo |
| 08 | CI/CD de ambas partes con artefactos trazables | nv-03/nv-14 | 002/014; preparar desde primera vertical |
| 09 | Caché DB/backend/frontend con TTL e invalidación comprobados | nv-06/nv-07, read_cache/Redis | 003/007/008; SQLite por cuenta |
| 10 | Logout local y remoto entre réplicas | nv-04 | 004; offline no afirma revocación confirmada |
| 11 | Matriz de versiones antes de desarrollar y manifiesto por despliegue | nv-00/nv-02/nv-14 | 001/003/014 |
| 12 | MCP opcional, origen/permisos documentados si se adopta | nv-00/nv-14 | 001/014; ausencia no bloquea |
| 13 | Nube, balanceo y HTTPS; IaC recomendada | nv-01/nv-14 | 003/014 consume TLS; no administra backend |
| 14 | NoSQL, scripts/índices/validadores y restauración | nv-01/nv-06/nv-14 | 003; SQLite local no reemplaza NoSQL remoto |
| 15 | Dos réplicas, JWT/Redis, rendimiento, CDN, observabilidad y costo cero verificado | nv-01/03/04/07/14 | 003/014 evidencia del consumidor |
| 16 | Moderación, push, privacidad/borrado, permisos, sesión, offline aplicable, ML y GenAI | nv-04/05/12/13 | 001/004/005/007/008/012/013 |
| 17 | Landing, Play, aviso/manejo de datos y Analytics | nv-14 coordinación | 014, W01; no convertir landing en Flutter |
| 18 | Cuenta GitHub única y carpeta compartida; correo de proyecto sugerido | nv-00/nv-14 | 001/014; responsables/accesos pendientes |
| 19 | Paquete .rar, scripts DB, reproducción y evaluación 02/12/2026 | nv-14 | 014; no incluir secretos ni datos reales |

## Seis tareas previas

| Tarea académica | Entregable y deuda | Preparación / cierre |
|---|---|---|
| 1 | Entrevistas reales, consentimiento y síntesis; faltan evidencias | nv-00 / nv-14 y app 014 |
| 2 | Descripciones backend/móvil separadas en fuente 1.2.0; conciliar con specs | nv-00 / app 001 |
| 3 | Componentes_Backend y Componentes_Movil en XLSX; mantener IDs | nv-01 / app 001 |
| 4 | Entidades, endpoints, filtros, llaves e índices del XLSX; formalizar por historia | nv-02 / app 003 |
| 5 | Análisis docente; faltan enlaces/commit verificables para repetir comparación | nv-00; no afirmar auditoría nueva de API_SDD/WebSDD |
| 6 | Estructura SDD en ambos contextos y responsables | nv-00..03 / app 001..003 |

## Hallazgos H01–H12

| ID | Corrección exigida | API / App | Evidencia futura |
|---|---|---|---|
| H01 | No teléfono cliente pendiente; participante+ok/done+both | nv-10 / 010 | Negativo DTO y UI/copia |
| H02 | Rechazo/cancelación no devuelve dirección/ruta | nv-10 / 010 | Estado cancel, purga caché y deep link |
| H03 | Autoría y aislamiento por ID, nunca Tú/me | nv-04/08/12/15 / 004/008/012/015 | Cambio de cuenta, sincronización y borrado |
| H04 | Quitar mención actualiza todas las vistas | nv-08 / 008 | DTO válido y diálogo reactivo |
| H05 | Respuesta rápida comparte envío manual | nv-11 / 011 | Confirmación remota una sola vez |
| H06 | Completitud única versionada | nv-06 / 006 | Mismos datos en alta/perfil/cuenta |
| H07 | Fotos no equivalen a trabajos realizados | nv-06/08 / 006/008 | Contadores independientes |
| H08 | Comparar precio solo de conceptos equivalentes | nv-07 / 007 | comparable=false con razón |
| H09 | Edición permanente de horario/precio/contacto | nv-06 / 006 | Edición antes/después de completar |
| H10 | Solo local admite radio cero; texto específico | nv-06/07 / 006/007 | Búsqueda y UI de modalidad |
| H11 | Contexto por mensaje y pedido activo explícito | nv-11 / 011 | Dos pedidos sin reescribir historial |
| H12 | Tres precios, seis fotos portafolio/cuatro por trabajo; Hoy es urgencia | nv-06/08/09 / 006/008/009 | Límites/filtros y shortlist opcional |

## Brechas encontradas y tratamiento

| Brecha | Ajuste documental | Lo que sigue abierto |
|---|---|---|
| OpenCode figuraba como referencia activa | AGENTS/CLAUDE/protocolo para Codex y Claude Code; README legado archivado | Versiones reales de herramientas y demostración de carga en ambos clientes |
| Planes/tareas repetidos y fases iniciales genéricas | Refinamiento específico de cada fase y sus cuatro artefactos | Descomponer tareas de código por historia con rutas reales al encargar implementación |
| Modelo de datos genérico por fase | Responsabilidad, invariantes y consultas del propietario; local/servidor separados | Esquemas formales, índices medidos y políticas de retención ratificadas |
| Requisitos de backend copiados como trabajo móvil | API aplica reglas; app presenta, consume y prueba | Integración real de ambos y evidencia por superficie |
| Entrega concentrada al final | Versionamiento/CI/canal Play desde fundamentos; entrega como cierre global | Cuentas, presupuesto, pipeline y artefactos reales |
| Dependencias ambiguas y ciclos aparentes | Dependencias explícitas, subincrementos comunidad/pedidos/chat y cierre final | Elegir primera historia y sus contratos antes de Ready |
| Contratos solo inventariados | Autoridad API, mapeo bilateral, contrato formal por subset | OpenAPI/AsyncAPI/SDL, errores y pruebas consumidor/provider |
| Funciones móviles compartidas sin dueño claro | 001 cubre M05/M26 y cada recorrido aplica accesibilidad/estados | Contraste, lector, texto escalado y Android real |
| Validadores podían dar confianza excesiva | Reportar exactamente alcance del lint; revisión semántica adicional | No certifican aceptación ni seguridad |

## Propuestas y decisiones

La estructura conserva diferencias del patrón docente para no generar migración de nombres innecesaria. Los documentos comunes son autoridad de coordinación; contratos API y especificaciones siguen siendo autoridad de su contenido. Skills recomendadas se documentan en [catálogo](SDD_SKILLS.md); no se instalan por esta revisión.

El cierre documental significa que cada brecha tiene tratamiento o decisión abierta identificada. No significa que todas estén resueltas por producto ni que las specs estén listas para desarrollar. Revisores humanos y ratificaciones permanecen pendientes en [decisiones](SDD_ALINEACION.md).

## Revisión estructural 0.3.0

El [informe de aplicación constitucional](SDD_CIERRE_ESTRUCTURA.md) corrige referencias a tareas no definidas que el lint previo no detectó. Las matrices de cada spec ahora enlazan requisitos, tareas reales y criterios. App 016 asigna dueño verificable a SQLite/offline/migraciones/conflictos, y 001 concreta M05/M26. Los puntos académicos 09/16 incluyen app 016 y el cierre de 014 depende también de esta capacidad. El total vigente es 16 specs API y 16 móviles; los conteos iniciales de este documento son históricos.

## Revisión funcional 0.4.0 — vigente

La revisión 0.3 comprobó integridad, pero no acreditaba cobertura individual de cada operación/función. El [mapa 0.4.0](SDD_COBERTURA_FUNCIONAL.md) registra el desglose vigente: 26 specs API/25 app, 101 operaciones con FR/T/AC en API y 92 consumos móviles; 9 superficies quedan excluidas explícitamente de Flutter. Cada componente/obligación/H01–H12 tiene ahora tarea y criterio propios, no solo una fila temática agregada. Las tablas de asignación anteriores se conservan como historial; usar mapa e índices actuales para implementar.

Las brechas de formalización, decisión humana y evidencia real siguen abiertas antes de Ready/aceptación. Más specs y tareas no equivalen a funcionamiento validado. No se añadieron endpoints, bases, servicios ni pantallas para aumentar conteos.

## Integracion estructural backend 0.4.1

Se incorporan preparacion previa a Ready en las 26 specs y tareas propietarias de consolidacion/referencias, transicion CI y activacion Jira/Confluence. No nuevas funcionalidades ni endpoints. [Brechas, trazabilidad y evidencia](SDD_INTEGRACION_ESTRUCTURA_BACKEND.md); ratificacion, contratos, producto y publicacion siguen pendientes.
