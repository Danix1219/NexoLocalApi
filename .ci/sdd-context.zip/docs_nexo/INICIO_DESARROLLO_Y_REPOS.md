# Inicio del desarrollo y configuración de repositorios

Fecha: 2026-11-02. Preparación para revisión; no repositorios remotos, workflows ni despliegues configurados por este documento.

## Estado real y posibilidad de iniciar

Se puede comenzar la preparación técnica y el refinamiento de la primera historia. La cobertura SDD 0.4.0 permite elegir trabajo, pero no convierte todas las specs en Ready. Falta ratificación técnica/revisor y contrato formal de cada historia que se vaya a implementar; no hace falta formalizar los 101 contratos antes del primer incremento.

Inspección de esta sesión: API_NexoLocal y App_NexoLocal no son repositorios Git y contienen documentación/validadores/plantilla PR, sin workflows. La carpeta separada C:/Users/kevin/source/repos/nexolocal.Api tampoco es Git; contiene una plantilla ASP.NET Core net10.0 con WeatherForecast, solución y Dockerfile. Ese proyecto no está integrado con el SDD ni acredita funcionalidad Nexo. No se modificó ni se compiló. dotnet y Flutter están localizados en el entorno; no se verificaron versiones/compatibilidad en esta sesión. gh no apareció en PATH.

## Primeros pasos, en orden

1. Elegir titular GitHub, nombres/URLs, visibilidad y plan; definir raíz de código+SDD en cada repositorio. Decidir cómo integrar o reemplazar la plantilla .NET existente, sin moverla ni publicarla automáticamente.
2. Ratificar solo decisiones de fundamento necesarias: .NET/YARP y NoSQL/eventos backend, SDK Flutter/Android, estado/navegación y almacenamiento seguro/local. Fijar versiones reales y registrar motivo/responsable; otras tecnologías siguen propuestas.
3. Integrar la documentación con una estructura reproducible desde clon limpio. Resolver enlaces compartidos y referencias históricas antes del primer pipeline remoto.
4. Preparar CI de documentación y controles de repositorio. Con proyecto creado, añadir compilación/análisis/pruebas reales y seguridad; un lint documental no aprueba producto.
5. Refinar identidad mínima API nv-04 / app 004: EP-001/002/003/004/005/007/008. Formalizar sus contratos, permisos, errores, límites y pruebas; identificar revisor. Recuperación/sesiones extra quedan en nv-16/app 017.
6. Encargar implementación de una historia pequeña: servidor/caso de uso y consumidor móvil con contrato compartido, pruebas negativas y estados de error. Dobles sirven en unitarias; SMS/moderación reales permanecen necesarios para aceptación integrada.
7. Entregar primera vertical a entorno de prueba y preparar canal Play temprano. Provisionamiento requiere nube/región/costo acordados, permisos y secretos/identidades seguros; no esperar a terminar todos los dominios.

## Bloqueos por momento

| Momento | Debe estar decidido/verificable | Puede quedar después |
|---|---|---|
| Preparar repositorios y CI documental | Titular, URLs/visibilidad/plan, permisos, raíz y tratamiento de fuentes compartidas | Proveedor SMS, modelos IA y todos los contratos de negocio |
| Crear fundamento ejecutable | Stack/SDK versionados, arquitectura mínima, estructura de código, revisor y encargo | S08/grafo y funciones posteriores |
| Implementar una historia | Ready de esa historia, contrato formal, criterios, datos/seguridad y pruebas definidas | Los contratos del resto de las 101 operaciones |
| Aceptar identidad real | SMS/moderación que aplique, Redis/estado durable, aislamiento/refresh/revocación y consumo móvil comprobados | Resto de dominios |
| Desplegar y publicar | Nube/región/costo, cuentas/identidades, manifiesto, gates reales, TLS/réplicas y canal Play/firma | Nada obligatorio de la historia liberada; opcionales solo si no se habilitan |

No hay necesidad de aumentar de nuevo el número de specs para iniciar: lo siguiente es refinar y ejecutar una historia, no seguir agregando documentación general.

## Organización propuesta de Git

Dos repositorios de producto bajo el mismo titular, cada uno con su SDD y código: backend y app. Esto no exige un repositorio por microservicio. La landing conserva su artefacto/dueño aparte. Los nombres definitivos quedan pendientes de URLs; no se inicializaron repositorios o remotos.

main será rama de integración protegida; ramas breves ligadas a spec/tarea, por ejemplo feature/nv-04-otp y feature/004-login. PR pequeño, validaciones obligatorias, revisión humana y squash merge como propuesta. No hace falta introducir develop/release permanentes mientras no exista necesidad del equipo. Tener CI correcto no autoriza desplegar producción en cada merge.

Configurar en ambos, según capacidades del plan: PR obligatorio, revisión humana por persona distinta del autor cuando el equipo lo permita, resolver conversaciones, invalidar aprobación obsoleta, checks requeridos y bloqueo de force-push/borrado de main. CODEOWNERS debe contener cuentas reales; no crear una falsa aprobación ni un archivo de responsables inventados. Si trabaja una sola persona, documentar el límite y elegir revisor humano real antes de aceptar, sin permitir autorrevisión ficticia.

La disponibilidad de rulesets/protección depende de visibilidad y plan: GitHub documenta rulesets en repos públicos con Free y públicos/privados con Pro/Team/Enterprise. Comprobar la cuenta antes de prometer enforcement en un repositorio privado gratuito. [Fuente oficial](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/managing-rulesets-for-a-repository).

## Dependencias documentales entre repositorios

El validador actual recorre enlaces a carpetas hermanas API_NexoLocal, App_NexoLocal, docs_nexo y algunas referencias históricas a requerimientos_nexolocal. Un checkout aislado en un runner no contiene esas carpetas: copiar el YAML del profesor fallaría o tentaría a omitir verificaciones.

Antes de activar CI elegir una solución reproducible: checkout de fuentes/contraparte con revisiones fijadas y rutas explícitas, o documentación de referencia versionada/empacada con enlaces adecuados. Un repositorio común de documentos bajo el mismo titular es una opción si se elige checkout múltiple. Las referencias históricas deben sustituirse por una fuente vigente o publicarse como referencia resoluble, sin depender del disco del profesor.

No duplicar contratos autoritativos en la app. Registrar la revisión de contrato consumida y compatibilidad. Para repos privados, el acceso entre repos requiere identidad/permiso explícito; no asumir que GITHUB_TOKEN de un repo abre cualquier otro. No entregar credenciales de despliegue a un PR para validar enlaces.

## CI por producto

| Momento | Backend | Móvil |
|---|---|---|
| Hoy, solo documentación | Validar SDD, enlaces/fuentes y trazabilidad con checkout completo | Mismos controles del contexto móvil y contrato/revisión referenciada |
| Fundamento creado | SDK fijado, restore/build, unitarias, análisis y control de dependencias/secretos | SDK Flutter/Android/JDK fijados, restore, analyze, unit/widget, dependencias/secretos |
| Primera historia | Contrato y tests de permisos/validación; NoSQL/Redis reales para integración cuando aplique | Consumo del contrato, almacenamiento seguro, estados/limpieza y prueba de integración real |
| Entrega | Imagen inmutable, SBOM/análisis de imagen/IaC aplicables, manifiesto y smoke test | AAB/versionCode/hash, pruebas de dispositivo pertinentes, manifiesto y validación de firma |

Rutas de .slnx/.csproj y pubspec se fijan con el repositorio definitivo. No usar comandos apuntando a proyectos inexistentes. Un job de pruebas sin pruebas, un job omitido o un mock no cuentan como aceptación real. Proponer un check agregado API/gate y App/gate con nombres estables; convertirlos en requeridos después de una ejecución real correcta, evitando filtros que dejen checks esperados pendientes.

## Seguridad de GitHub Actions y DevSecOps

PR ejecuta validación con permisos mínimos y sin credenciales de producción. Separar jobs de CI y despliegue; contents:read como base y permisos adicionales solo donde corresponda. Fijar acciones a SHA completo verificado, revisar actualizaciones y no ejecutar código no confiable con secretos mediante pull_request_target. Dependabot/escáneres y controles disponibles se seleccionan según lenguajes, visibilidad y plan; no se da por incluido todo GitHub Advanced Security. [Guía oficial de uso seguro](https://docs.github.com/en/actions/reference/security/secure-use).

Para la nube, preferir OIDC cuando el proveedor lo soporte, con confianza limitada a repo/rama/entorno y rol mínimo; sustituye credenciales permanentes de nube, no todas las claves de firma o credenciales de cualquier proveedor. [OIDC oficial](https://docs.github.com/en/actions/concepts/security/openid-connect).

Los bloqueos de seguridad incluyen secretos expuestos, autorización/aislamiento roto, contrato incompatible y fallos críticos de casos de la historia. Umbrales de cobertura y excepciones deben ratificarse; no copiar valores de skills como reglas nuevas. Excepción con motivo, responsable, vencimiento y mitigación; hallazgo no silenciado para poner verde el pipeline.

## CD por producto

Backend: tras CI y merge autorizado, publicar imagen inmutable; promover el mismo digest a prueba y después producción, con aprobaciones/permisos adecuados. Migración compatible, smoke test/health, trazas y rollback; eliminación de infraestructura en flujo separado con revisión de entorno, no como limpieza de cada PR. Activación depende de nube/costo ratificados.

App: generar y conservar artefacto firmado/versionCode creciente; publicación a canal interno de Play tras controles y permisos, seguida de verificación de instalación; promoción posterior controlada. Custodiar clave de carga y credenciales Play fuera del repo/logs y comprobar compatibilidad con APIs ya distribuidas. Flutter documenta opciones de CI/CD y aconseja probar el proceso local antes de automatizarlo. [Guía oficial Flutter](https://docs.flutter.dev/deployment/cd).

Los entornos y aprobaciones de GitHub también dependen del plan/visibilidad; comprobar disponibilidad antes de basar el control de producción en una función no habilitada. No se crean workflows de CD ficticios con secretos/nubes o cuentas Play pendientes.

## Datos necesarios para aplicar configuración remota

Titular y URLs/nombres de backend/app; visibilidad y plan; personas revisoras; raíz definitiva de código+SDD y decisión sobre carpeta .NET existente. Después, para CD: nube/región/entornos y presupuesto, identidad federada/roles, cuenta Play/ID de aplicación/canal y custodia de firma. No enviar tokens, contraseñas o keystores al chat; usar configuración segura del proveedor cuando corresponda.

Estado de esta entrega: diagnóstico y propuesta concreta preparados, sin git init/commit/push, cambios de rama/protección remota, aplicación nueva, workflows ejecutables, secretos, instalación o despliegue. La información faltante de repositorios impide aplicar configuración a un destino inequívoco.

## Actualización tras recibir URLs y preparar configuración

Los destinos son NexoLocalApi/NexoLocalApp de Danix1219, públicos y vacíos. Se verificaron permisos admin/push con autenticación Git existente, sin mostrar ni guardar credenciales. Se aplicaron y verificaron permisos de Actions, SHA obligatorio, token de lectura, sin aprobación automática de PR y squash merge. Se preparó y probó CI documental desde copias aisladas con referencias congeladas/hasheadas; el código de producto será bloqueado por este gate hasta añadir CI real.

Git local está inicializado con origin y contenido en staging; no hay commit ni push. La revisión automática rechazó publicación del payload completo en público sin autorización explícita. Revisar [payload concreto](PUBLICACION_INICIAL_REVISABLE.md) antes de autorizar exposición de Memoria/SDD/instrucciones/snapshots y metadatos de autor Git. Ruleset preparado pero no aplicado hasta verificar primer check remoto y disponer de revisión humana real. El GitHub plugin está disponible en catálogo pero no instalado; la configuración administrativa se hizo con Git/API y autenticación existente.

Los apartados iniciales de este plan describen el diagnóstico antes de preparar repositorios. Esta actualización es el estado vigente. No hay CI remoto ejecutado ni CD/DevSecOps de producto completo.

## Estado vigente: publicacion autorizada y CI remoto (2026-11-02)

El usuario autorizo publicar el contenido revisable completo. Publicacion inicial realizada en ambos repositorios publicos; no se creo aplicacion ni se traslado la plantilla .NET separada. Los apartados anteriores sobre ausencia de autorizacion, staging sin push o repositorios vacios son estados historicos, sustituidos por esta actualizacion.

- API: https://github.com/Danix1219/NexoLocalApi; primer CI documental correcto: https://github.com/Danix1219/NexoLocalApi/actions/runs/41548573146.
- App: https://github.com/Danix1219/NexoLocalApp; primer CI documental correcto: https://github.com/Danix1219/NexoLocalApp/actions/runs/41548583415.
- Commits con evidencia y politica individual: API dffa25a14939be09cda6c3faf0468de3286173ea; app 2c2d53dd8a96e007a7fef55adaabf7ac2cff0e83. Su CI se verifica antes de activar protecciones.
- Danix1219 trabaja solo por decision expresa. PR y check siguen siendo obligatorios; cero aprobaciones requeridas. No hay revision independiente ni se considera ratificada la constitucion o aceptadas las specs por publicar.

Primeros pasos de desarrollo: resolver decisiones pertinentes D01-D08 y fijar stack/SDK; cerrar contrato formal de identidad/sesion y estados de consumo movil; revisar y pasar la spec objetivo a Ready; crear proyectos en sus repositorios con CI real (build/test/seguridad) en ese mismo PR; desarrollar un incremento vertical API/app con pruebas de contrato, autorizacion y aislamiento. La cantidad de specs no sustituye estos gates.

CD queda pendiente de proveedor/regiones/presupuesto, entornos/roles y cuentas/firma/canal Play. No se crearon secretos, infraestructura ni despliegues. CI actual es exclusivamente documental y rechazo de producto sin CI real; DevSecOps completo requiere los controles de producto descritos arriba.

## Cierre remoto verificado (2026-11-02)

- API main: dffa25a14939be09cda6c3faf0468de3286173ea. CI success: https://github.com/Danix1219/NexoLocalApi/actions/runs/41548693176. Ruleset 26409789 activo.
- App main: 2c2d53dd8a96e007a7fef55adaabf7ac2cff0e83. CI success: https://github.com/Danix1219/NexoLocalApp/actions/runs/41548701333. Ruleset 26409790 activo.
- Lectura posterior por API confirma reglas efectivas sobre main en ambos: PR obligatorio, conversaciones resueltas, check SDD / docs de GitHub Actions (integration_id 15368), rama actualizada, bloqueo de borrado y force-push. Sin bypass; cero aprobaciones por trabajo individual. Merge permitido por configuracion de repositorio: squash.
- La publicacion inicial y el commit de evidencia ocurrieron antes de activar reglas; siguientes cambios a main requieren rama y PR con CI. No crear ni usar bypass para cambios ordinarios.
- Actions: SHA obligatorio, acciones oficiales seleccionadas, token de lectura, sin aprobacion automatica de PR. Dependabot revisa Actions. No se configura CI de producto o CD mientras falten proyectos, contratos y destinos reales.
- Memoria de ambos repositorios registra publicacion y primer CI. Este informe registra la activacion administrativa posterior sin modificar main directamente despues de protegerla.

## Acuerdo posterior de equipo (2026-11-02)
El usuario define feature/* → develop → release/* → main, con reintegracion main/release→develop y equipo a incorporar. Sustituye los apartados provisionales de trabajo individual y merge solo squash. Procedimiento y evidencia vigente: [flujo del equipo](FLUJO_GIT_EQUIPO.md). No se declara revision independiente hasta incorporar un segundo revisor; subir a una aprobacion obligatoria antes de integrar trabajo de equipo.


Flujo de equipo aplicado y probado: PR 2→3→4 en ambos repositorios, checks de cada PR correctos y reintegracion completada; reglas de main/develop/release activas sin bypass. Carpetas locales en develop sincronizada. Detalle de commits, reglas y CI en [evidencia del flujo](FLUJO_GIT_EQUIPO.md).


## Punto de entrada concreto de la primera spec (2026-11-03)
Empezar por [paquete nv-00](../API_NexoLocal/docs/inicio-backend/README.md): registro de decisiones, flujo de cambios y evidencia por tarea. Preparacion local disponible y validada; Ready formal/cierre global pendientes. Danix1219 es revisor provisional ya designado, sin revision independiente. Jira/Confluence siguen pospuestos; no se publica ni crea scaffold por este paquete.


## Correccion del proyecto existente (2026-11-03)

Usar nexolocal.Api.slnx, la solucion original. G01 es el proyecto nexolocal.Api existente y S01 es un servicio con host propio bajo services/identity/src; la solucion paralela generada antes se retiro. [Mapa vigente](../API_NexoLocal/docs/estructura-backend.md) y [validacion actual](../API_NexoLocal/docs/inicio-backend/correccion-base-microservicios.md). Los informes anteriores se conservan como fases historicas, no como ruta activa. No publicacion o CI remoto nuevo.
