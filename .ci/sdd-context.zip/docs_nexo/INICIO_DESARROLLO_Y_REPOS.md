# Inicio del desarrollo y configuración de repositorios

Fecha: 2026-11-02. Preparación para revisión; no repositorios remotos, workflows ni despliegues configurados por este documento.

## Estado real y posibilidad de iniciar

Se puede comenzar la preparación técnica y el refinamiento de la primera historia. La cobertura SDD 0.4.0 permite elegir trabajo, pero no convierte todas las specs en Ready. Falta ratificación técnica/revisor y contrato formal de cada historia que se vaya a implementar; no hace falta formalizar los 101 contratos antes del primer incremento.

Inspección de esta sesión: API_NexoLocal y App_NexoLocal no son repositorios Git y contienen documentación/validadores/plantilla PR, sin workflows. La carpeta separada C:/Users/kevin/source/repos/nexolocal.Api tampoco es Git; contiene una plantilla ASP.NET Core net10.0 con WeatherForecast, solución y Dockerfile. Ese proyecto no está integrado con el SDD ni acredita funcionalidad Nexo. No se modificó ni se compiló. dotnet y Flutter están localizados en el entorno; no se verificaron versiones/compatibilidad en esta sesión. gh no apareció en PATH.

## Primeros pasos, en orden

1. Elegir titular GitHub, nombres/URLs, visibilidad y plan; definir raíz de código+SDD en cada repositorio. Decidir cómo integrar o reemplazar la plantilla .NET existente, sin moverla ni publicarla automáticamente.
2. Ratificar solo decisiones de fundamento necesarias: .NET/YARP y NoSQL/eventos backend, SDK Flutter/Android, estado/navegación y almacenamiento seguro/local. Fijar versiones reales y registrar motivo/responsable; otras tecnologías siguen propuestas.
3. Integrar la documentación con una estructura reproducible desde clon limpio. Resolver enlaces compartidos y referencias históricas antes del primer pipeline remoto.
4. Preparar CI de documentación y controles de repositorio. Con proyecto creado, añadir compilación/análisis/pruebas reales y seguridad; un lint documental no aprueba producto.
5. Refinar identidad mínima API nv-04 / app 004: EP-001/002/003/004/005/007/008. Formalizar sus contratos, permisos, errores, límites y pruebas; identificar revisor. Recuperación/sesiones extra quedan en nv-16/app 017.
6. Encargar implementación de una historia pequeña: servidor/caso de uso y consumidor móvil con contrato compartido, pruebas negativas y estados de error. Dobles sirven en unitarias; SMS/moderación reales permanecen necesarios para aceptación integrada.
7. Entregar primera vertical a entorno de prueba y preparar canal Play temprano. Provisionamiento requiere nube/región/costo acordados, permisos y secretos/identidades seguros; no esperar a terminar todos los dominios.

## Bloqueos por momento

| Momento | Debe estar decidido/verificable | Puede quedar después |
|---|---|---|
| Preparar repositorios y CI documental | Titular, URLs/visibilidad/plan, permisos, raíz y tratamiento de fuentes compartidas | Proveedor SMS, modelos IA y todos los contratos de negocio |
| Crear fundamento ejecutable | Stack/SDK versionados, arquitectura mínima, estructura de código, revisor y encargo | S08/grafo y funciones posteriores |
| Implementar una historia | Ready de esa historia, contrato formal, criterios, datos/seguridad y pruebas definidas | Los contratos del resto de las 101 operaciones |
| Aceptar identidad real | SMS/moderación que aplique, Redis/estado durable, aislamiento/refresh/revocación y consumo móvil comprobados | Resto de dominios |
| Desplegar y publicar | Nube/región/costo, cuentas/identidades, manifiesto, gates reales, TLS/réplicas y canal Play/firma | Nada obligatorio de la historia liberada; opcionales solo si no se habilitan |

No hay necesidad de aumentar de nuevo el número de specs para iniciar: lo siguiente es refinar y ejecutar una historia, no seguir agregando documentación general.

## Organización propuesta de Git

Dos repositorios de producto bajo el mismo titular, cada uno con su SDD y código: backend y app. Esto no exige un repositorio por microservicio. La landing conserva su artefacto/dueño aparte. Los nombres definitivos quedan pendientes de URLs; no se inicializaron repositorios o remotos.

main será rama de integración protegida; ramas breves ligadas a spec/tarea, por ejemplo feature/nv-04-otp y feature/004-login. PR pequeño, validaciones obligatorias, revisión humana y squash merge como propuesta. No hace falta introducir develop/release permanentes mientras no exista necesidad del equipo. Tener CI correcto no autoriza desplegar producción en cada merge.

Configurar en ambos, según capacidades del plan: PR obligatorio, revisión humana por persona distinta del autor cuando el equipo lo permita, resolver conversaciones, invalidar aprobación obsoleta, checks requeridos y bloqueo de force-push/borrado de main. CODEOWNERS debe contener cuentas reales; no crear una falsa aprobación ni un archivo de responsables inventados. Si trabaja una sola persona, documentar el límite y elegir revisor humano real antes de aceptar, sin permitir autorrevisión ficticia.

La disponibilidad de rulesets/protección depende de visibilidad y plan: GitHub documenta rulesets en repos públicos con Free y públicos/privados con Pro/Team/Enterprise. Comprobar la cuenta antes de prometer enforcement en un repositorio privado gratuito. [Fuente oficial](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/managing-rulesets-for-a-repository).

## Dependencias documentales entre repositorios

El validador actual recorre enlaces a carpetas hermanas API_NexoLocal, App_NexoLocal, docs_nexo y algunas referencias históricas a requerimientos_nexolocal. Un checkout aislado en un runner no contiene esas carpetas: copiar el YAML del profesor fallaría o tentaría a omitir verificaciones.

Antes de activar CI elegir una solución reproducible: checkout de fuentes/contraparte con revisiones fijadas y rutas explícitas, o documentación de referencia versionada/empacada con enlaces adecuados. Un repositorio común de documentos bajo el mismo titular es una opción si se elige checkout múltiple. Las referencias históricas deben sustituirse por una fuente vigente o publicarse como referencia resoluble, sin depender del disco del profesor.

No duplicar contratos autoritativos en la app. Registrar la revisión de contrato consumida y compatibilidad. Para repos privados, el acceso entre repos requiere identidad/permiso explícito; no asumir que GITHUB_TOKEN de un repo abre cualquier otro. No entregar credenciales de despliegue a un PR para validar enlaces.

## CI por producto

| Momento | Backend | Móvil |
|---|---|---|
| Hoy, solo documentación | Validar SDD, enlaces/fuentes y trazabilidad con checkout completo | Mismos controles del contexto móvil y contrato/revisión referenciada |
| Fundamento creado | SDK fijado, restore/build, unitarias, análisis y control de dependencias/secretos | SDK Flutter/Android/JDK fijados, restore, analyze, unit/widget, dependencias/secretos |
| Primera historia | Contrato y tests de permisos/validación; NoSQL/Redis reales para integración cuando aplique | Consumo del contrato, almacenamiento seguro, estados/limpieza y prueba de integración real |
| Entrega | Imagen inmutable, SBOM/análisis de imagen/IaC aplicables, manifiesto y smoke test | AAB/versionCode/hash, pruebas de dispositivo pertinentes, manifiesto y validación de firma |

Rutas de .slnx/.csproj y pubspec se fijan con el repositorio definitivo. No usar comandos apuntando a proyectos inexistentes. Un job de pruebas sin pruebas, un job omitido o un mock no cuentan como aceptación real. Proponer un check agregado API/gate y App/gate con nombres estables; convertirlos en requeridos después de una ejecución real correcta, evitando filtros que dejen checks esperados pendientes.

## Seguridad de GitHub Actions y DevSecOps

PR ejecuta validación con permisos mínimos y sin credenciales de producción. Separar jobs de CI y despliegue; contents:read como base y permisos adicionales solo donde corresponda. Fijar acciones a SHA completo verificado, revisar actualizaciones y no ejecutar código no confiable con secretos mediante pull_request_target. Dependabot/escáneres y controles disponibles se seleccionan según lenguajes, visibilidad y plan; no se da por incluido todo GitHub Advanced Security. [Guía oficial de uso seguro](https://docs.github.com/en/actions/reference/security/secure-use).

Para la nube, preferir OIDC cuando el proveedor lo soporte, con confianza limitada a repo/rama/entorno y rol mínimo; sustituye credenciales permanentes de nube, no todas las claves de firma o credenciales de cualquier proveedor. [OIDC oficial](https://docs.github.com/en/actions/concepts/security/openid-connect).

Los bloqueos de seguridad incluyen secretos expuestos, autorización/aislamiento roto, contrato incompatible y fallos críticos de casos de la historia. Umbrales de cobertura y excepciones deben ratificarse; no copiar valores de skills como reglas nuevas. Excepción con motivo, responsable, vencimiento y mitigación; hallazgo no silenciado para poner verde el pipeline.

## CD por producto

Backend: tras CI y merge autorizado, publicar imagen inmutable; promover el mismo digest a prueba y después producción, con aprobaciones/permisos adecuados. Migración compatible, smoke test/health, trazas y rollback; eliminación de infraestructura en flujo separado con revisión de entorno, no como limpieza de cada PR. Activación depende de nube/costo ratificados.

App: generar y conservar artefacto firmado/versionCode creciente; publicación a canal interno de Play tras controles y permisos, seguida de verificación de instalación; promoción posterior controlada. Custodiar clave de carga y credenciales Play fuera del repo/logs y comprobar compatibilidad con APIs ya distribuidas. Flutter documenta opciones de CI/CD y aconseja probar el proceso local antes de automatizarlo. [Guía oficial Flutter](https://docs.flutter.dev/deployment/cd).

Los entornos y aprobaciones de GitHub también dependen del plan/visibilidad; comprobar disponibilidad antes de basar el control de producción en una función no habilitada. No se crean workflows de CD ficticios con secretos/nubes o cuentas Play pendientes.

## Datos necesarios para aplicar configuración remota

Titular y URLs/nombres de backend/app; visibilidad y plan; personas revisoras; raíz definitiva de código+SDD y decisión sobre carpeta .NET existente. Después, para CD: nube/región/entornos y presupuesto, identidad federada/roles, cuenta Play/ID de aplicación/canal y custodia de firma. No enviar tokens, contraseñas o keystores al chat; usar configuración segura del proveedor cuando corresponda.

Estado de esta entrega: diagnóstico y propuesta concreta preparados, sin git init/commit/push, cambios de rama/protección remota, aplicación nueva, workflows ejecutables, secretos, instalación o despliegue. La información faltante de repositorios impide aplicar configuración a un destino inequívoco.
